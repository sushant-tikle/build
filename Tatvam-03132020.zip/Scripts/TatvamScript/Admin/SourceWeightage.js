﻿
var readSorceWeightage_CallURL = '../Source/SourceWeightageGrid';
var updateWeightage_CallURL = "../Source/Update";

var lastsel;
var globalData;

$(document).ready(function () {
    readSourceWeightage();
});

function readSourceWeightage() {
    $.ajax({
        url: readSorceWeightage_CallURL,
        type: "POST",
        success: function (searchResults) {
            var jsonData = TatvamObjectToJsonConvert(searchResults);
            globalData = jsonData;
            loadSourceWeightage(jsonData);
            if (jsonData.length === 0)
                $("#SourceWeigtagegrid").append('<div class=\'nodata\' style="width: 200px;">No Data Available.</div>');
        },
        error: function (xhr, status, p3, p4) {
            hideLoadingCursor();
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function loadSourceWeightage(jsonData) {

    var sourceWeigtagegrid = $("#SourceWeigtagegrid");

    sourceWeigtagegrid.jqGrid({

        datatype: "local",
        data: jsonData,
        colNames: ['Customer Id', 'Source ID', 'Source Name', 'Review Count', 'Source Weightage'],
        colModel: [
           { label: 'Customer Id', name: 'CustomerId', hidden: true, editable: false },
           { label: 'Source ID', name: 'SourceId', key: true, hidden: true, editable: false },
           { label: 'Source Name', name: 'SourceName', width: 150, sortable: true, editable: false },
           { label: 'Review Count', name: 'ReviewCount', width: 100, align: "right", sortable: true, stype: 'int', editable: false },
           { label: 'Source Weightage', name: 'SourceWeightage', editable: true, width: 120, align: "right", sortable: true, stype: 'int' }
        ],
        width: 850,
        cmTemplate: { editable: true, searchoptions: { clearSearch: false } },
        toppager: false,
        cloneToTop: false,
        pgbuttons: false,
        pginput: false,
        gridview: true,
        rownumbers: false, // show row numbers
        rownumWidth: 25, // the width of the row numbers columns
        autoencode: true,
        ignoreCase: true,
        sortname: "SourceName",
        viewrecords: true,
        sortorder: "desc",
        //caption: "Source Weightage",
        editurl: "clientArray",
        altRows: true, //Enables alternate row colors
        hoverrows: true, // true by default, can be switched to ProductCategory/GetAllCompaniesfalse if highlight on hover is not needed
        multiSort: false, // Allows multiple column sorting
        loadComplete: function () {

            var width = $("#SourceWeigtagegrid").width();
            $(".ui-jqgrid-bdiv").css({ "width": width + 20 });
            $(".ui-jqgrid-hdiv").css({ "width": width + 20 });
            $(".ui-jqgrid-toppager").css({ "width": width + 22 });
            var height = $("#SourceWeigtagegrid").height();
            if (height > 150) {
                $(".ui-jqgrid-bdiv").css({ "height": height + 21 });
                //  //   $(".ui-jqgrid-hdiv").css({ "height": height + 25 });
                $(".ui-jqgrid-toppager").css({ "height": height + 22 });
            }
        },
        onSelectRow: function (rowid) {
            if (rowid && rowid !== lastsel) {
                jQuery("#SourceWeigtagegrid").jqGrid('setCell', lastsel, "SourceWeightage", "", { color: 'red' });
                jQuery("#SourceWeigtagegrid").saveRow(lastsel, false);
                lastsel = rowid;
            }
            jQuery('#SourceWeigtagegrid').editRow(rowid, true);
        }
    }).jqGrid("navGrid", "#SourceWeigtagegridpager", { edit: false, add: false, del: false, search: false, cloneToTop: false });


    jQuery('#SourceWeigtagegrid').jqGrid('clearGridData');
    jQuery('#SourceWeigtagegrid').jqGrid('setGridParam', { data: jsonData });
    jQuery('#SourceWeigtagegrid').trigger('reloadGrid');

}



function TatvamObjectToJsonConvert(searchResults) {

    var gidData = JSON.stringify(searchResults);
    var jsonData = jQuery.parseJSON(gidData);
    return jsonData;
}

function OnMenuClick(reportCategoryId, reportName) {
    showLoadingCursor();
    $('#hdn_reportid_page').val(reportCategoryId);
    sessionStorage.setItem("ReportId", reportCategoryId);
    sessionStorage.setItem("reportName", reportName);
    window.location.href = "../Home/Home";
    return false;
}

function OnSourceWeightdateCancel() {
    //location.reload();
    jQuery('#SourceWeigtagegrid').jqGrid('clearGridData');
    jQuery('#SourceWeigtagegrid').jqGrid('setGridParam', { data: globalData });
    jQuery('#SourceWeigtagegrid').trigger('reloadGrid');
}

function SaveSourceWeightage() {
    jQuery("#SourceWeigtagegrid").saveRow(lastsel, false);
    var rowCount = jQuery("#SourceWeigtagegrid").getGridParam("reccount");
    for (var i = 0; i <= rowCount; i++) {
        jQuery("#SourceWeigtagegrid").saveRow(i, false);
    }

    var rows = $('#SourceWeigtagegrid').jqGrid('getRowData');
    var paras = new Array();
    var srcWeightageTotal = 0;
    for (var j = 0; j < rowCount; j++) {
        var row = rows[j];
        srcWeightageTotal += parseFloat(row.SourceWeightage);
        if (row.SourceWeightage === '') {
            /*Tatvam Confirmation Message Box Starts*/
            bootbox.alert({
                message: "Source Weightage: Value cannot be blank.",
                title: "Error",
                size: "small"
            });
            return;
        }
        if (!$.isNumeric(row.SourceWeightage)) {
            /*Tatvam Confirmation Message Box Starts*/
            bootbox.alert({
                message: "Source Weightage: Value should be numeric.",
                title: "Error",
                size: "small"
            });
            return;
        }
        if (parseFloat(row.SourceWeightage) > 1) {
            /*Tatvam Confirmation Message Box Starts*/
            bootbox.alert({
                message: "Source Weightage: value must be less than or equal to 1",
                title: "Error",
                size: "small"
            });
            return;
        }
        paras.push({
            CustomerId: row.CustomerId,
            SourceId: row.SourceId,
            SourceName: row.SourceName,
            ReviewCount: row.ReviewCount,
            SourceWeightage: row.SourceWeightage
        });
    }

    if (srcWeightageTotal > 1) {
        /*Tatvam Confirmation Message Box Starts*/
        bootbox.alert({
            message: "Source Weightage: Sum of Weightage must be less than or equal to 1",
            title: "Error",
            size: "small"

        });
        return;
    }

    var gridData = $('#SourceWeigtagegrid').jqGrid('getRowData');
    $.ajax({
        url: updateWeightage_CallURL,
        type: "json",
        data: { lstsources: JSON.stringify(gridData) },
        reloadAfterSubmit: true,
        success: function (result) {
            if (result.indexOf("<title>SessionTimeOut</title>") > -1) {
                window.location.href = "../SessionTimeOut/SessionTimeOut";
            }
            else {
                /*Tatvam Confirmation Message Box Starts*/
                bootbox.alert({
                    message: "Source Successfully Updated",
                    title: "Alert Box",
                    size: "small"

                });
                readSourceWeightage();
            }
        },
        error: function (xhr, status, p3, p4) {
            hideLoadingCursor();
            var error = JSON.parse(xhr.responseText)
            TatvamAlert("Source Weightage: Error While Updating the Records.", "Error");
        }
    });
}

function getSourceWeightageData() {
    var rows = $('#SourceWeigtagegrid').jqGrid('getGridParam', 'data');
    var paras = new Array();
    for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        paras.push({
            CustomerID: row.CustomerID,
            SourceID: row.SourceID,
            SourceName: row.SourceName,
            ReviewCount: row.ReviewCount,
            SourceWeightage: $("#" + row.SourceID + "_SourceWeightage").val()
        });
        paras.push($.param(row));
    }
}
