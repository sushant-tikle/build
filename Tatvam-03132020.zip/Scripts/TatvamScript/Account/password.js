﻿
var totalNoofSubmit = 0;

$(document).ajaxStart(function () {
    $("div#spinner").fadeIn("fast");
});

$(document).ajaxComplete(function () {
    $("div#spinner").fadeOut("fast");
});

function SendPassword() {
    showLoadingCursor();
    var emailId = $("#EmailID").val();

    if (emailId.length > 0) {
        $("div#spinner").fadeIn("fast");
    }

    if ($("#fortgotForm").valid()) {
        if (totalNoofSubmit >= 1) {
            totalNoofSubmit++;
            alert('Your form has been submitted already. Please wait!!');
            return false;
        }
        else {
            totalNoofSubmit++;
        }
    }

    if ($("#fortgotForm").valid()) {
        $('#fortgotForm').submit(function () {
            $("div#spinner").fadeIn("fast");
        });
    }
    else {
        return false;
    }
    return true;
}

function ChangePassword() {

    if ($("#EmailID").val() === "")
        return false;

    if ($("#Password").val() === "")
        return false;

    if ($("#NewPassword").val() === "")
        return false;

    if ($("#ConfirmPassword").val() === "")
        return false;

    if ($("#Captcha").val() === "")
        return false;

    if ($("#changePasswordForm").valid()) {
        $("#changePasswordForm").submit();
    }
    else {
        return false;
    }
    return true;
}

function ResetPassword() {

    if ($("#EmailID").val() === "")
        return false;

    if ($("#Password").val() === "")
        return false;

    if ($("#NewPassword").val() === "")
        return false;

    if ($("#ConfirmPassword").val() === "")
        return false;

    if ($("#Captcha").val() === "")
        return false;

    if ($("#resetPasswordForm").valid()) {
        $("#resetPasswordForm").submit();
    }
    else {
        return false;
    }
    return true;
}

function getParamValuesByName(querystring) {
    var name = querystring.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.search);
    if (results === null) {
        return "";
    }
    else {
        return decodeURIComponent(results[1].replace(/\+/g, " "));
    }
}

function ReloadCaptchaImage() {
    var href = window.location.href.split('/');
    var contextPath = href[0] + '//' + href[2] + '/' + href[3];    
    $('#imgCaptcha').attr('src', contextPath + '/ShowCaptchaImage?time=' + new Date());
}


/*Wait Cursor Script Starts*/
var overlay = $('<div id="overlay"></div>');

function showLoadingCursor() {
    $("body").css("cursor", "none");
    overlay.show();
    overlay.appendTo(document.body);
    $('.popup').show();
}

function hideLoadingCursor() {
    $('.popup').hide();
    overlay.appendTo(document.body).remove();
    $("body").css("cursor", "auto");
}

/*Wait Cursor Script Ends*/

