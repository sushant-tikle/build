﻿

var updateRecordsCallURL = "../ClassifierManagement/UpdateRecords/";

var deleteid = "";
var retval = 1;
var count, Copiedtext, action, Parents, Parent, Childrens, Nodeid;

$(document).ready(function () {

    DisplayTreeView(data);
    disableButtons();
    $("#search_tree").click(function() {
        var value = document.getElementById("search_field").value;
        if (value.length === 0) {
            bootbox.alert({
                size: "small",
                title: "Alert Box",
                message: "Enter the Classifier to be searched.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                }
            })

        } else {
            var x = $("#treeview").jstree("search", value);
            if ($(x).find('.jstree-search').length === 0) {
                bootbox.alert({
                    size: "small",
                    title: "Alert Box",
                    message: "Search result not found.",
                    buttons: {
                        ok: {
                            label: 'Ok',
                            className: 'btn-primary'
                        }
                    }
                })

            }
        }
        document.getElementById("search_field").value = "";
    });

});

$("#treeview").click(function() {
    $(".jstree-contextmenu").css("display", "none");
});

function DisplayTreeView(treeData) {

    if (treeData.length === 0) {
        $("#treeview").empty();
        $("#treeview").append("  <h5>Classifier List not created for this Customer.</h5>");
        $("#DivButton").children().prop('disabled', true);
    } else {
        $("#DivButton").children().prop('disabled', false);
        $.getScript('../Scripts/jstree.min.js', function () {
            $('#treeview')
                .on('create_node.jstree', create_node)
                .on('rename_node.jstree', rename_node)
                .bind("select_node.jstree", bind_node)
                .jstree({
                    "core": {
                        strings: {
                            'New node': 'New Classifier '
                        },
                        "open_parents": true,
                        "force_text": true,
                        'data': treeData,
                        'error': function(err) {

                            if (err.plugin === "unique" || err.plugin === "core" || err.plugin === "types") {
                                if ((err.id === 'unique_01' || err.id === 'unique_03')) {
                                    var boxMessage = "Classifier '" + err.reason.split(' ')[3].fontcolor("red") + "' already available.Duplicate Classifiers not allowed";
                                  
                                } else if (err.id === 'types_03') {
                                    var boxMessage = "Classifiers can not be created for the next level."
                                } else {
                                    var boxMessage = "Duplicate Classifiers not allowed"
                                }
                                bootbox.alert({
                                    size: "small",
                                    title: "Alert Box",
                                    message: boxMessage,
                                    buttons : {
                                        ok: {
                                            label: 'Ok',
                                            className: 'btn-primary'
                                        }
                                    },
                                    callback: function () {
                                        $(this).modal('hide');
                                        $('#treeview').jstree("deselect_all");
                                        $("#treeview").jstree('select_node', "#" + Nodeid);
                                        $('#treeview').jstree().edit(Nodeid);
                                    }
                                })


                              
                            }
                        },
                        'check_callback': function(operation, node, nodeParent, node_position, more) {

                            if (operation === "move_node") {
                                return nodeParent.id !== "#"; //only allow dropping inside nodes of type 'Parent'                         
                            }

                            return true; //allow all other operations
                        }

                    },
                    "types": {
                        "#": {
                            //'icon': '../content/Images/like_icon.png',
                            "max_children": 1,
                            "max_depth": 3,
                            "valid_children": ["root"]
                        },
                        "root": {
                            //'icon': '../content/Images/like_icon.png',
                            "valid_children": ["default"]
                        },
                        "default": {
                            //'icon': '../content/Images/tree-icon.png',
                            "valid_children": ["default", "file"]
                        },
                        "file": {
                            //"icon": '../content/Images/leaf_icon.png',
                            "valid_children": []
                        }
                    },
                    'contextmenu': {
                        'items': function($node) {

                            var tree = $("#treeview").jstree(true);
                            return {
                                "create": {
                                    "separator_after": true,
                                    "label": "Create Sub Element",
                                    "action": function(data) {
                                        Classifier_create();
                                    }
                                },
                                "rename": {
                                    "label": "Rename",
                                    "shortcut_label": 'F2',
                                    "action": function(data) {

                                        Classifier_rename();
                                    }
                                },
                                "Delete": {
                                    "label": "Delete",
                                    "action": function(data) {
                                        Classifier_delete();
                                    }
                                },

                                "cut": {
                                    "separator_before": true,
                                    "label": "Cut",
                                    "action": function(data) {
                                        $("#btn_Cancel").prop('disabled', false);
                                        $("#btn_submit").prop('disabled', false);

                                        var inst = $.jstree.reference(data.reference),
                                            obj = inst.get_node(data.reference);
                                        Copiedtext = obj.text;
                                        Parent = obj.parents[obj.parents.length - 1];
                                        action = "X";
                                        if (obj.parent !== "#") {
                                            if (inst.is_selected(obj)) {
                                                inst.cut(inst.get_top_selected());
                                            } else {
                                                inst.cut(obj);
                                            }
                                        } else {
                                            bootbox.alert({
                                                size: "small",
                                                title: "Alert Box",
                                                message: "Categories are not allowed to Cut",
                                                buttons: {
                                                    ok: {
                                                        label: 'Ok',
                                                        className: 'btn-primary'
                                                    }
                                                },
                                                callback: function () {
                                                    $(this).modal('hide');
                                                }
                                            })

                                         
                                        }
                                    }
                                },
                                "copy": {
                                    "label": "Copy",
                                    "action": function(data) {

                                        $("#btn_Cancel").prop('disabled', false);
                                        $("#btn_submit").prop('disabled', false);
                                        var inst = $.jstree.reference(data.reference),
                                            obj = inst.get_node(data.reference);
                                        Copiedtext = obj.text;
                                        Parent = obj.parent;
                                        action = "C";
                                        if (obj.parent !== "#") {
                                            if (inst.is_selected(obj)) {
                                                inst.copy(inst.get_top_selected());
                                            } else {
                                                inst.copy(obj);
                                            }
                                        } else {
                                            bootbox.alert({
                                                title: "Alert Box",
                                                size:"small",
                                                message: "Categories are not allowed to be Copied",
                                                buttons: {
                                                    ok: {
                                                        label: 'Ok',
                                                        className: 'btn-primary'
                                                    }
                                                },
                                                callback: function () {
                                                    $(this).modal('hide');
                                                }
                                            })

                                            
                                        }
                                    }
                                },
                                "paste": {
                                    "_disabled": function(data) {
                                        return !$.jstree.reference(data.reference).can_paste();
                                    },
                                    "label": "Paste as sub Element",
                                    "action": function(data) {

                                        var inst = $.jstree.reference(data.reference),
                                            obj = inst.get_node(data.reference);
                                        Parents = obj.id;

                                        if (DuplicateCheck(Parents, Copiedtext)) {
                                            if ((count === 0) && (action === "C")) {
                                                inst.paste(obj);
                                            } else if ((count === 0) && (action === "X") && ($.inArray(Parent, Parents) !== 0)) {
                                                inst.paste(obj);
                                            } else if ((count === 1) && (action === "X") && ($.inArray(Parent, Parents) >= 0)) {
                                                inst.paste(obj);
                                            } else {
                                                var duplicate = [];
                                                duplicate = Copiedtext.split('[');
                                                bootbox.alert({
                                                    title: "Alert Box",
                                                    message: "Classifier '" + duplicate[0].fontcolor("red") + "' already available.Duplicate Classifiers not allowed",
                                                    buttons: {
                                                        ok: {
                                                            label: 'Ok',
                                                            className: 'btn-primary'
                                                        }
                                                    },
                                                    callback: function () {
                                                        $(this).modal('hide');
                                                    }
                                                })

                                                count = 0;
                                            }
                                        }
                                    }
                                }
                            };
                        }
                    },
                    "dnd": {
                        "is_draggable": function(node) {
                            if (node[0].parent === "#") {
                                return false;
                            } else {
                                enableButtons();
                                return true;
                            }
                        },
                        "drag_selection": true
                    },

                    "plugins": ['contextmenu', "dnd", "types", "search", "unique"]
                });
        });

    }

    function create_node(event, data) {
        data.node.data = "C";
        Nodeid = data.node.id;
        $("#treeview").jstree(true).get_node(Nodeid, true).children('.jstree-anchor').focus();
    }

    function rename_node(event, data) {
        Nodeid = data.node.id;
        create_node
        count = 0;
        retval = 1;
        var parent = [];
        parent = data.node.parent;
        if (data.text.trim() === "") {
            bootbox.alert({
                title: "Alert Box",
                size: "small",
                message: "Classifiers cannot be created/renamed with blank space",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $("#treeview").jstree().edit(Nodeid);
                }
            })

           

        } else if (!DuplicateCheck(parent, data.text)) {
            $("#treeview").jstree("delete_node", data.node.id);
        }
    }


    function bind_node(event, data) {
        Parents = data.node.parent;
        Childrens = data.node.children_d;
    }

    $('#treeview').data().jstree

}

function updateKeywords(displayedDataAsJSON, deletedid) {

    var arrparam = {};
    arrparam["Classifierlist"] = displayedDataAsJSON;
    arrparam["DeletedClassifier"] = deletedid;


    $.ajax({
        type: "POST",
        url: updateRecordsCallURL,
        data: JSON.stringify(arrparam),
        contentType: 'application/json',
        success: function(data) {

            if (data === false) {
                bootbox.alert({
                    title: "Alert Box",
                    size: "small",
                    message: "Data not Saved.",
                    buttons: {
                        ok: {
                            label: 'Ok',
                            className: 'btn-primary'
                        }
                    },
                    callback: function () {
                        $(this).modal('hide');
                    }
                })

                
            } else {
                bootbox.alert({
                    title: "Alert Box",
                    size: "small",
                    message: "Data Saved Succesfully.",
                    buttons: {
                        ok: {
                            label: 'Ok',
                            className: 'btn-primary'
                        }
                    },
                    callback: function () {
                        $(this).modal('hide');
                        window.location.reload(true);
                    }
                })
  
            }
            deleteid = "";
            $("#btn_Cancel").prop('disabled', true);
            $("#btn_submit").prop('disabled', true);


        },
        error: function (data) {
            hideLoadingCursor();
            bootbox.alert({
                title: "Alert Box",
                size: "small",
                message: "Data not Saved.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                }
            })
            $('#treeview').jstree(true).redraw(true);
            deleteid = "";
        }
    });
}

function createJSON() {

    var v = $('#treeview').jstree(true).get_json("#", { flat: true });
    var mytext = JSON.stringify(v);
    var deletedkeyword;
    if (deleteid !== '') {
        deleteid = trimChar(deleteid, ',');
        if (deleteid.indexOf('_') !== -1) {
            deleteid = "";
        }
        deletedkeyword = JSON.stringify(deleteid);
    } else {
        deletedkeyword = "";
    }
    updateKeywords(mytext, deletedkeyword);
}

function Classifier_create() {

    enableButtons();
    var ref = $('#treeview').jstree(true),
        sel = ref.get_selected();
    var index = sel[0].indexOf('j');
    if (!sel.length) {
        return false;
    }
    sel = sel[0];
    sel = ref.create_node(sel, { "type": "file" });
    if (sel) {
        ref.edit(sel);
    } else {
        if (index !== -1) {
            var boxMessage = "Save the newly created classifier before creating its child classifier.";
        } else {
            var boxMessage = "Classifiers can not be created for the next level.";
        }
        bootbox.alert({
            title: "Alert Box",
            size: "small",
            message: boxMessage,
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })

      


    }
}

function Classifier_rename() {

    enableButtons();
    var ref = $('#treeview').jstree(true),
        sel = ref.get_selected();
    if (!sel.length) {
        return false;
    }
    if ((Parents === "#") || (Parents === undefined)) {
        bootbox.alert({
            title: "Alert Box",
            size: "small",
            message: "Categories cannot be Renamed.",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })

    } else {
        sel = sel[0];
        ref.edit(sel);
    }
}

function Classifier_delete() {
    var ref = $('#treeview').jstree(true),
        sel = ref.get_selected();
    if (sel.length === 0) {
        bootbox.alert({
            title: "Alert Box",
            size: "small",
            message: "Select any keyword before proceeding with the deletion.",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })

       
    } else if ((Parents === "#") || (Parents === undefined)) {
        bootbox.alert({
            title: "Alert Box",
            size: "small",
            message: "Categories cannot be Deleted.",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })

        
    } else {
        var deletedkeywords = $('.jstree-clicked').text().split('[');
        bootbox.confirm({
            title: "Alert Box",
            message: "On Deletion of the '  " + deletedkeywords[0].fontcolor("red") + "  ' ,  selected record, all its associated records also gets deleted.Are you sure to continue the deletion ? ",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-default'
                }
            },
            callback: function (result) {
                if (result) {
                    $("#btn_Cancel").prop('disabled', false);
                    $("#btn_submit").prop('disabled', false);
                    deleteid = deleteid + ',' + sel;
                    if (Childrens !== undefined && Childrens.length !== 0) {
                        deleteid = deleteid + ',' + Childrens;
                    }
                    if (!sel.length) {
                        return false;
                    }
                    ref.delete_node(sel);
                    $(this).modal('hide');
                } else {
                    $(this).modal('hide');
                }
            }
        })

    }
}

function DuplicateCheck(parent, key) {

    var v = $('#treeview').jstree(true).get_json();
    var value = true;
    count = 0;
    var newword = '';
    newword = key.split('[')[0].trim();
    DuplicatecheckSubChild(parent, v[0].children, newword);
    if (retval === 0) {
        bootbox.alert({
            title: "Alert Box",
            size: "small",
            message: "Classifier '" + newword.fontcolor("red") + "' already available.Duplicate Classifiers not allowed",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })

    

        count = 0;
        retval = 1;
        value = false;

    }

    return value;

}

function DuplicatecheckSubChild(parent, childNode, newkeyword) {

    if (parent.indexOf('j') == -1) {
        $.each(childNode, function(i, value) {
            if (value.id === parent) {
                $.each(value.children, function(i, value) {
                    var word = '';
                    word = value.text.split('[')[0].trim();
                    if (word.toUpperCase().trim() === newkeyword.toUpperCase().trim()) {
                        count = parseInt(count) + 1;
                    } else {
                        count = count;
                    }

                });
                return;
            } else if (childNode[i].children.length > 0) {
                DuplicatecheckSubChild(parent, childNode[i].children, newkeyword);
            }
        });
    } else {
        $.each(childNode, function(i, value) {
            var word = '';
            word = value.text.split('[')[0].trim();
            if (word.toUpperCase().trim() === newkeyword.toUpperCase().trim()) {
                count = parseInt(count) + 1;
                return;
            } else {
                count = count;

            }

        });

    }

    if (count > 1) {
        retval = 0;
    }


}

function trimChar(string, charToRemove) {
    while (string.charAt(0) === charToRemove) {
        string = string.substring(1);
    }

    while (string.charAt(string.length - 1) === charToRemove) {
        string = string.substring(0, string.length - 1);
    }

    return string;
}

function disableButtons() {
    $("#btn_Cancel").prop('disabled', true);
    $("#btn_submit").prop('disabled', true);
    $("#btn_submit").prop('color', "#666");
}

function enableButtons() {
    $("#btn_Cancel").prop('disabled', false);
    $("#btn_submit").prop('disabled', false);

}

$("#btn_submit").click(function() {
    var result = 'Success';
    var errornode = new String();
    var v = $('#treeview').jstree(true).get_json("#", { flat: true });
    var i, j;
    for (i = 0; i < v.length; i++) {
        var nodevalue = v[i].text;
        var iChars = "!#$%^*()+={}:?~@&�";
        for (var k = 0; k < v[i].text.length; k++) {
            if ((iChars.indexOf(nodevalue.charAt(k)) > -1) || (nodevalue.trim().length === 0)) {
                errornode = errornode + ',' + nodevalue;
                result = 'failure';
                $('#treeview').jstree("deselect_all");
                $("#treeview").jstree('select_node', "#" + v[i].id);
                break;
            }
        }
    }
    if (result === 'Success') {
        bootbox.confirm({
            title: "Alert Box",
            message: "Are you sure to save the changes?",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-default'
                }
            },
            callback: function (result) {
                if (result) {
                    createJSON();
                    disableButtons();
                    retval = 1;
                    count = 0;
                    $(this).modal('hide');
                } else {
                    $(this).modal('hide');
                }
            }
        })

 


    } else {
        bootbox.alert({
            title: "Alert Box",
            message: "Keyword ' " + trimChar(errornode, ',').fontcolor("red") + " ' contains special characters or empty string and hence cannot proceed with the saving. Kindly remove the Special character and Try once again.",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })


    }
});

$("#btn_Cancel").click(function () {
    bootbox.confirm({
        title: "Confirm Box",
        message: "Are you sure to cancel the changes?",
        buttons: {
            confirm: {
                label: 'Ok',
                className: 'btn-primary'
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                $('#treeview').jstree(true).refresh();
                disableButtons();
                $('#treeview').jstree("deselect_all");
                $(this).modal('hide');
            } else {
                $(this).modal('hide');
            }
        }
    })


});
