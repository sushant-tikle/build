﻿var deleteid = new String();

/**
     * Disable Save and Cancel Buttons
     * @returns {} 
*/

function disableButtons() {
    $("#btn_Cancel").button("disable");
    $("#btn_submit").button("disable");
}

/**
 * Enable Save and Cancel Buttons
 * @returns {} 
 */
function enableButtons() {
    $("#btn_Cancel").button("enable");
    $("#btn_submit").button("enable");
}

$(document).ready(function () {
    $(".button").button();
    // disableButtons();

    DisplayTreeView(data);

});



function DisplayTreeView(treeData) {


    if (treeData.length === 0) {
        $('#treeview').append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }

    var columns = [];
    columns.push({
        //tree:, // boolean, whether the jstree should be placed in this column. Only the first true is accepted. If no column is set to tree:true, then the first column is used.
        //width: , //width of the column in pixels. If no width is given, the default is auto except for the last column. In the last column, if no width is given, it is treated as 'auto' and fills the entire rest of the table to the right.
        header: 'Classifiers', //string to use as a header for the column.
        //headerClass: , //a CSS class to add to the header cell in this column
        //columnClass: , //a CSS class to add to the header cell and the column cell
        //cellClass: , //a CSS class to add to each cell in this column (except for the header) - added to the
        //wideCellClass: , //a CSS class to add to each cell in this column (except for the header) - added to the
        //value: text, //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
        //format: , //a function to modify the displayed value e.g. date formatting.
        //valueClass: , //the attribute on the node to use as a class on this cell - added to the
        //valueClassPrefix: , //a prefix to add to the valueClass to use as a class on this cell
        //wideValueClass: , //the attribute on the node to use as a class on this cell - added to the
        //wideValueClassPrefix: , //a prefix to add to the wideValueClass to use as a class on this cell
    })
    
    for (var i = 0; i < Object.getOwnPropertyNames(treeData.data).length; i++) {

        columns.push({
            //tree:, // boolean, whether the jstree should be placed in this column. Only the first true is accepted. If no column is set to tree:true, then the first column is used.
            //width: , //width of the column in pixels. If no width is given, the default is auto except for the last column. In the last column, if no width is given, it is treated as 'auto' and fills the entire rest of the table to the right.
            header: Object.getOwnPropertyNames(treeData.data)[i], //string to use as a header for the column.
            //headerClass: , //a CSS class to add to the header cell in this column
            //columnClass: , //a CSS class to add to the header cell and the column cell
            //cellClass: , //a CSS class to add to each cell in this column (except for the header) - added to the
            //wideCellClass: , //a CSS class to add to each cell in this column (except for the header) - added to the
            value: Object.getOwnPropertyNames(treeData.data)[i], //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
            //format: , //a function to modify the displayed value e.g. date formatting.
            //valueClass: , //the attribute on the node to use as a class on this cell - added to the
            //valueClassPrefix: , //a prefix to add to the valueClass to use as a class on this cell
            //wideValueClass: , //the attribute on the node to use as a class on this cell - added to the
            //wideValueClassPrefix: , //a prefix to add to the wideValueClass to use as a class on this cell
        })
    }
    

    $('div#treeview')
       .jstree({
           plugins: ["table"],
           core: {
               "data": [treeData]
           },
           table: {
               columns: columns
              
           },
       });
}

/**
 * On Create of New node
 * @param {} event 
 * @param {} data 
 * @returns {} 
 */
function create_node(event, data) {
    enableButtons();
    data.node.data = { 'Created': "true" };
}

/**
 * On Copy of node
 * @param {} event 
 * @param {} data 
 * @returns {} 
 */
function copy_node(event, data) {
    enableButtons();
    data.node.data = { 'Copy': "true" };
}

/**
 * On Cut of node
 * @param {} event 
 * @param {} data 
 * @returns {} 
 */
function cut_node(event, data) {
    enableButtons();
    data.node.data = { 'Cut': "true" };
}

/**
 * On Rename of each node
 * @param {} event 
 * @param {} data 
 * @returns {} 
 */
function rename_node(event, data) {

    //Check the node is newly created if not make the data status as updated
    if (data.node.data !== null) {
        if (data.node.data.Created !== 'true' && data.text !== data.old) {
            enableButtons();
            data.node.data = { 'Updated': "true" };
        }
    } else if (data.text !== data.old) {
        enableButtons();
        data.node.data = { 'Updated': "true" };
    }

    var treeObject = $('#treeview').jstree(true).get_json("#", { flat: false });
    DuplicateCheck(data, treeObject);
}

/**
 * On Deletion of the node
 * @param {} event 
 * @param {} data 
 * @returns {} 
 */
function delete_node(event, data) {
    enableButtons();
    data.node.data = { 'Deleted': "true" };
}

/**
 * Display Tree View
 * @returns {} 
 */

/**
 * Create/Update/Delete a Node
 * @returns {} 
 */
function node_operation(operation) {
    var ref = $('#treeview').jstree(true),
        objsel = ref.get_selected('full', true);

    //if the node is not selected return false
    if (!objsel.length) {
        return false;
    }
    // enableButtons();
    //Get the selected Node Id
    var sel = objsel[0].id;


    if (operation === 'Create') {
        sel = ref.create_node(sel);
        if (sel) {
            ref.edit(sel);
        } else {
            Tatvam.messages.showInfo("Save the newly created classifier before creating its child classifier.");
        }
    } else if (operation === 'Update') {
        ref.edit(sel);
    } else if (operation === 'Delete') {
        if (objsel.length === 0) {
            Tatvam.messages.showInfo("Select any classifier before proceeding with the deletion.");
        } else if ((objsel[0].parent === "#") || (objsel[0].parent === undefined)) {
            Tatvam.messages.showInfo("Categories cannot be Deleted.");
        } else {
            Tatvam.messages.showConfirm("On Deletion of the '  " + $('.jstree-clicked').text().fontcolor("red") + "  ' ,  selected record, all its associated records also gets deleted.Are you sure to continue the deletion ?.", function (result) {
                if (result) {
                    deleteid = deleteid + ',' + sel;
                    if (!sel.length) {
                        return false;
                    }
                    ref.delete_node(sel);
                }
            });
        }
    }
}


function DuplicateCheck(searchvalue, treeObject) {
    $.each(treeObject, function (i, value) {
        if (value.children.length > 0) {
            DuplicateCheck(searchvalue, value.children);
        }
        if (value.text === searchvalue.text && value.id !== searchvalue.node.id) {
            Tatvam.messages.showInfo("Classifier '" + searchvalue.text.fontcolor("red") + "' already available.Duplicate Classifiers are not allowed");
            if (searchvalue.node.data.Created === "true") {
                $("#treeview").jstree("delete_node", searchvalue.node.id);
            } else if (searchvalue.node.data.Updated === "true") {
                $("#treeview").jstree('rename_node', searchvalue.node);
            }
        }
    });
}













