﻿

/*Create New Subscriber Starts*/

function getSelectedAvailableSubscriber() {
    var AvailableSubscriberList = $('#tbl_availableSubscriber tr:has(td)').map(function (i, v) {
        var $td = $('td', this), isSubscribed = false;
        if ($td.eq(0).find("#chk_availableSubscriber:checked").length > 0) {
            this.remove();
            return {
                RecipientFirstName: $td.eq(2).text(),
                RecipientLastName: $td.eq(3).text(),
                RecipientEmailId: $td.eq(4).text(),
                DirtyFlag: "Insert",
                ModifiedCount: 0
            }
        }
    }).get();
    return AvailableSubscriberList;
}

function addSelectedSubscriber() {
    var lstAvailableSubscriber = getSelectedAvailableSubscriber();
    $.each(lstAvailableSubscriber, function addRecpt() {
        addRecipientRow(this);
    });
    $("#selectUser").modal('hide');
}

/*Create New Subscriber Ends*/

function insertNewSubscriber() {
    objSubscription = new Object();
    objSubscription = getNewSubscriberData();

    obtainedSubscriptionDetails.ReportScheduledId = 0;
    objSubscription.ReportScheduledId = 0;

    if (objSubscription === null) {
        return false;
    }

    if (CheckSubscriptionExists() === true) {
        return false;
    }

    var rtn = TatvamAjaxCallWithReturn("POST", "../ReportSubscription/InsertSubscriptionData", objSubscription, null, {});
    if (rtn.responseText != 1) {
        TatvamAlert("error while inserting subscription details.", "error");
        return false;
    }

    lstReportRecipient = getRecipient();
    var rtn = TatvamAjaxCallWithReturn("POST", "../ReportSubscription/InsertReportRecipient", lstReportRecipient, null, {});
    if (rtn.responseText != 1) {
        TatvamAlert("Error while inserting recipient details.", "Error");
        return false;
    }

    resetNewSubscriber();
    resetSubscription();
    readExistingSubscriber();
    disableAllFrequencies();
    TatvamAlert("Subscription has been successfully inserted.", "Information");
    enableSaveButton();
}



function updateNewSubscriber() {
    objSubscription = new Object();
    objSubscription = getNewSubscriberData();
    if (objSubscription === null) {
        return false;
    }

    if (CheckSubscriptionExists() === true) {
        return false;
    }

    //to-do: verify and remove below commented code
    //lstReportRecipient = getRecipient();
    //var rtn = TatvamAjaxCallWithReturn("POST", "../ReportSubscription/InsertSubscriptionData", objSubscription, null, {});
    //if (rtn.responseText != 1) {
    //    TatvamAlert("Error while updating subscription.", "Error");
    //    return false;
    //}

    var rtn = TatvamAjaxCallWithReturn("POST", "../ReportSubscription/InsertSubscriptionData", objSubscription, null, {});
    //to-do: verify and remove below commented code
    //to-do: commented below code, need to identify and add appropriate condition for error checking during update
    //if (rtn.responseText != 1) {
    //    TatvamAlert("Error while inserting subscription details.", "Error");
    //    return false;
    //}
    
    lstReportRecipient = getRecipient();
    var rtn = TatvamAjaxCallWithReturn("POST", "../ReportSubscription/InsertReportRecipient", lstReportRecipient, null, {});
    //to-do: commented below code, need to identify and add appropriate condition for error checking during update
    //to-do: verify and remove below commented code
    //if (rtn.responseText != 1) {
    //    TatvamAlert("Error while inserting recipient details.", "Error");
    //    return false;
    //}

    resetNewSubscriber();
    resetSubscription();
    readExistingSubscriber();
    disableAllFrequencies();
    TatvamAlert("Subscription has been successfully updated.", "Information");
    enableSaveButton();
    $("#statusBlock").css({ 'display': 'none' });
}

function getNewSubscriberData() {
    objSubscription = new Object();
    if (!validateNewSubscription()) {
        return null;
    }

    objSubscription.SubscriptionName = $("#txt_SubscriptionName").val();
    objSubscription.ReportId = $("#ddl_ReportList").val();
    objSubscription.ReportPeriodicity = $("input[name='ReportPeriodicity']:checked").val();
    objSubscription.DataCoverageUnits = $("#txt_PeriousPeriod").val();
    objSubscription.DataCoverageUnitFrequency = $("#ddl_ReportPeriodicity").val();
    objSubscription.ReportScheduledId = obtainedSubscriptionDetails.ReportScheduledId;
    objSubscription.DeliveryFormat = $("input[name='ReportDeliveryFormat']:checked").val();
    objSubscription.Status = $("#ddl_State").val();
    //To-Do: Get Newly Applied UCD filter data for saving

    var appliedUcdFilters = retreiveSelectedSubscriptionFilters();
    if (appliedUcdFilters.length == 0) {
        objSubscription.ReportFilter = null;
    }
    else {
        objSubscription.ReportFilter = JSON.stringify(appliedUcdFilters);
    }
    return objSubscription;

}

function validateNewSubscription() {
    var subscriptionName = $("#txt_SubscriptionName").val();
    if (subscriptionName == "") {
        TatvamAlert("Subscription name cannot be blank.", "Error");
        return false;
    }

    var report_Name = $("#ddl_ReportList").val();
    if (report_Name == "") {
        TatvamAlert("Please select report name for the subscription.", "Error");
        return false;
    }

    var previousPeriod = $("#txt_PeriousPeriod").val();
    if (previousPeriod == "") {
        TatvamAlert("Please enter the previous period for the subscription periodicity.", "Error");
        return false;
    }

    var recipientData = getRecipient();
    if (recipientData.length <= 0) {
        TatvamAlert("Please add the recipient for subscription.", "Error");
        return false;
    }

    return true;
}

function resetSubscription(event) {
    $("#lbl_subscription_id").text("");
    $("#txt_SubscriptionName").val("");
    $("#ddl_ReportList").val("");
    $("#txt_PeriousPeriod").val("");
    $("#ddl_ReportPeriodicity").val("Days");
    $("#tbl_RecipientDetails > tbody").empty();
    $("#btn_addSelectedSubscriber").attr('disabled', 'disabled');
    $("#btn_newsubscription").attr('disabled', 'disabled');
    $("#ddl_ReportList").prop("disabled", false);
    $("#statusBlock").css("display", "none");
    $("#radio_HTML").attr('disabled', false);
    $("#radio_PDF").attr('disabled', false);
    disableAllFrequencies();
    clearReportFilters();
    enableSaveButton();
    //when user clicks on entire subscription reset . 
    if (event) {
        obtainedSubscriptionDetails = undefined;
    }
}

/*Add New Subscriber Functions */

$("#createNewUser").delegate("input[type='radio'],input[type='checkbox'],input[type='number'],input[type='text']", 'change input', function () {
    var subscriptionName = $("#txt_SubscriptionName").val();
    var report_Name = $("#ddl_ReportList").val();
    var DataCoverageUnits = $("#txt_PeriousPeriod").val();

    if (subscriptionName != "" && report_Name != "" && DataCoverageUnits != "") {
        $("#btn_newsubscription").removeAttr('disabled');
    }
});

/*Add New Subscriber Functions Ends*/
function bindDropDown(controlId, data, defaultSelection) {
    $.each(data, function (i, el) {
        if (defaultSelection == el.text) {
            $(controlId).append("<option selected value='" + el.value + "'>" + el.text + "</option>");
        } else {
            $(controlId).append("<option value='" + el.value + "'>" + el.text + "</option>");
        }
    });
}

/*Report Subscription Starts*/
function bindReportNameDropdown(data) {
    var dropdownData = $.map(data, function (val, i) {
        return { value: val.ReportId, text: val.ReportName };
    });
    bindDropDown("#ddl_ReportList", dropdownData);
}

function updateSubscriptionName() {
    var reportName = $("#ddl_ReportList  option:selected").text();
    if (reportName !== "--Select--") {
        var frequency = $("input[name='ReportPeriodicity']:checked").val();
        //var subscriptionName = reportName + " (" + frequency + ")";
        $("#txt_SubscriptionName").val("");
    }

}

function onReportNameChange($this) {
    //On Change of Report name update the subscription name based on the combination of Report name and 
    //updateSubscriptionName();
    clearReportFilters();

    enableSaveButton();

    //To Check whether it is in Edit Mode or Create Mode
    var isEditMode = false;

    //Get the Subscription Details for the Selected Report and the Frequency
    var retVal = getReportSubscriptionDetails();

    if (retVal == undefined) {
        return;
    }

    //Eidt Mode we are binding the existing subscribers(Recipients) of the subscription to the grid
    if (isEditMode) {
        //Bind all the available subscribers for the report
        bindRecipientList(retVal.lstReportRecipient);
        
        bindAvailableSubscriber(retVal.lstReportUsers);
        enableUpdateButton();
        LoadReportSubscriptionUCDFilter();
    }
    else {
        //If the logged in user is not an admin then by default based on the report selection default user will be displayed.
        if (strRole !== "Admin" && strRole != "TatvamAdmin") {
            bindRecipientList(retVal.lstReportRecipient);
            $("#txt_PeriousPeriod").removeAttr('disabled');
            $("#ddl_ReportPeriodicity").removeAttr('disabled');
            obtainedSubscriptionDetails = {};
            enableSaveButton();
        }
        else {
            emptyRecipientList();
            obtainedSubscriptionDetails = {};
            bindAvailableSubscriberWithoutFiltering(retVal.lstReportUsers);
            enableSaveButton();
        }
    }
    if ($this.value === "123" || $this.value === "124") {
        $("#radio_HTML").attr('checked', true);
        $("#radio_HTML").attr('disabled', false);
        $("#radio_PDF").attr('disabled', false);
    } else {
        $("#radio_PDF").attr('checked', true);
        $("#radio_HTML").attr('disabled', true);
        $("#radio_PDF").attr('disabled', true);
    }
}
//global variable to hold obtained subscription details
//to-do: need to move this global variable into a function parameter
var obtainedSubscriptionDetails;

function getReportSubscriptionDetails() {

    // continue with below flow only when both frequency and report is selected
    var selectedReportID = $("#ddl_ReportList option:selected").val();
    var selectedFreq = $("input[name='ReportPeriodicity']:checked").val();

    if (selectedReportID == "") {
        $("#tbl_RecipientDetails > tbody").empty();
        return undefined;
    }

    $("#txt_PeriousPeriod").removeAttr('disabled');
    $("#ddl_ReportPeriodicity").removeAttr('disabled');

    //Create the search object to get the Report Subscription details    
    var inpObject = new Object();
    inpObject.SubscriptionName = $("#txt_SubscriptionName").val(); // get subscription name
    inpObject.Frequency = $("input[name='ReportPeriodicity']:checked").val(); // get selected frequency value
    inpObject.ReportId = $("#ddl_ReportList").val();
    inpObject.DataCoverageUnits = $("#txt_PeriousPeriod").val();
    inpObject.DataCoverageUnitFrequency = $("#ddl_ReportPeriodicity").val();

    //Ajax call to get the Report subscription Details
    var rtnVal = TatvamAjaxCallWithReturn("GET", "../ReportSubscription/GetSubscriptionDetails", inpObject, null, {});
    //parse the return value
    var jsonData = JSON.parse(rtnVal.responseText);

    //maintain state of subscription form based on the edit/create mode
    maintainUIState(jsonData, inpObject);

    //set add/edit mode
    setMode(jsonData);

    //to-do: need to move this global variable into a function parameter    
    obtainedSubscriptionDetails = jsonData;

    if (jsonData.ReportScheduledId == 0) {
        //add functionality
        //during add mode, do not reset the already added recipient list
        if (jsonData.isEdit) {
            $("#tbl_RecipientDetails > tbody").empty();
        }

        jsonData.Frequency = inpObject.Frequency;
        jsonData.ReportId = inpObject.ReportId;


        //enable save for saving the subscription
        enableSaveButton();

    } else {
        //edit functionality
        $("#lbl_subscription_id").text(jsonData.ReportScheduledId);

        //enable update for saving the updated subscription
        enableUpdateButton();

        var reportname = $("#ddl_ReportList  option:selected").text();
        if (strRole !== "Admin" && strRole != "TatvamAdmin") {
            $("#txt_PeriousPeriod").attr('disabled', 'disabled');
            $("#ddl_ReportPeriodicity").attr('disabled', 'disabled');
        }
    }
    //Return report subscription details
    return jsonData;
}

function bindSubscriptionData(inpObject) {

    //To reset the UCD Filters
    clearReportFilters();
    //call reset subscription only during edit mode
    if (inpObject.isEdit) {
        resetSubscription();
        enableUpdateButton();
    }
   
    //assign subscription name
    $("#txt_SubscriptionName").val(inpObject.SubscriptionName);
    $("#ddl_State").val(inpObject.Status);
    $("#statusBlock").css("display", "block");
    $("#lbl_subscription_id").text(inpObject.ReportScheduledId);
    $("#ddl_ReportList").prop("disabled", true);
    $("#ddl_ReportList").val(inpObject.ReportId);
    $("#radio_" + inpObject.ReportPeriodicity).prop('checked', true);
    $("#radio_" + inpObject.DeliveryFormat).prop('checked', true);
    //$("input[name='ReportPeriodicity'][value='" + inpObject.Frequency + "']").prop('checked', true);
    if (inpObject.DataCoverageUnits !== 0) {
        $("#txt_PeriousPeriod").val(inpObject.DataCoverageUnits);
        $("#btn_newsubscription").removeAttr('disabled');
    }
    if (inpObject.DataCoverageUnitFrequency !== "" && inpObject.DataCoverageUnitFrequency != null) {
        $("#ddl_ReportPeriodicity").val(inpObject.DataCoverageUnitFrequency);
    }
    
    if (inpObject.ReportId === "123" || inpObject.ReportId === 123) {
        $("#radio_HTML").attr('checked', true);
        $("#radio_HTML").attr('disabled', false);
        $("#radio_PDF").attr('disabled', false);
    } else {
        $("#radio_PDF").attr('checked', true);
        $("#radio_HTML").attr('disabled', true);
        $("#radio_PDF").attr('disabled', true);
    }
    //if report filters exists bind report filters with subscription data.
    LoadReportSubscriptionUCDFilter();

    

}
/*Report Subscription Ends*/

/*Recipient Functions Starts*/
function bindRecipientList(recipientList) {

    $('#div_recipient').show();
    $('#tbl_RecipientDetails tbody').empty();
    $.each(recipientList, function addRecpt() {
        addRecipientRow(this);
    });
}

function emptyRecipientList() {
    $('#div_recipient').show();
    $('#tbl_RecipientDetails tbody').empty();
}

function addRecipientRow(NewSubscriber) {
    var noofRows = $('#tbl_RecipientDetails tbody tr').length;
    // Find a <table> element with id="myTable":
    var table = document.getElementById("tbl_RecipientDetails_body");
    // table.deleteRow(1)
    // Create an empty <tr> element and add it to the 1st position of the table:
    var row = table.insertRow(noofRows);
    // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
    var cell1 = row.insertCell(0);
    cell1.innerHTML = noofRows + 1;
    cell1.className = "cell-width10x";

    var cell2 = row.insertCell(1);
    cell2.innerHTML = NewSubscriber.RecipientFirstName;
    cell2.className = "cell-width20x";

    var cell3 = row.insertCell(2);
    cell3.innerHTML = NewSubscriber.RecipientLastName;
    cell3.className = "cell-width20x";

    var cell4 = row.insertCell(3);
    cell4.innerHTML = NewSubscriber.RecipientEmailId;
    cell4.className = "cell-width30x";

    var cell5 = row.insertCell(4);
    cell5.innerHTML = NewSubscriber.DirtyFlag;
    cell5.className = "cell-width10x";
    cell5.style.display = "none";


    var cell6 = row.insertCell(5);
    cell6.innerHTML = NewSubscriber.ModifiedCount;
    cell6.style.display = "none";
    

    if (NewSubscriber.DirtyFlag == "Insert") {
        var cell7 = row.insertCell(6);
        cell7.className = "cell-width20x delete";
        cell7.innerHTML = "<a onclick='deleteRow(this)'>Delete</a>";
    } else if (NewSubscriber.IsSubscribed) {
        var cell7 = row.insertCell(6);
        cell7.className = "cell-width20x delete";
        cell7.innerHTML = "<a onclick='deleteRow(this)'>Un-Subscribe</a>";
        cell5.innerHTML = "Subscribe";
    } else if (!NewSubscriber.IsSubscribed) {
        var cell7 = row.insertCell(6);
        cell7.className = "cell-width20x delete";
        cell7.innerHTML = "<a onclick='deleteRow(this)'>Subscribe</a>";
        cell5.innerHTML = "Un-Subscribe";
    }

}



function deleteRow($this) {
    if ($this.innerText == "Subscribe") {
        $this.innerText = "Un-Subscribe";
        $($this).closest('tr')[0].cells[4].innerHTML = "Subscribe";
    } else if ($this.innerText == "Un-Subscribe") {
        $this.innerText = "Subscribe";
        $($this).closest('tr')[0].cells[4].innerHTML = "Un-Subscribe";
    } else if ($this.innerText == "Delete") {
        $this.innerText = "Un-Delete";
        $($this).closest('tr')[0].cells[4].innerHTML = "Delete";
    } else {
        $this.innerText = "Delete";
        $($this).closest('tr')[0].cells[4].innerHTML = "Un-Delete";
    }
    //$($this).closest('tr').remove();
}

function getRecipient() {

    var subscriptionName = $("#txt_SubscriptionName").val();
    var recipientList = $('#tbl_RecipientDetails tr:has(td)').map(function (i, v) {
        var $td = $('td', this), DirtyFlag = $td.eq(4).text(), is_Subscribed;
        if (DirtyFlag === "Insert") {
            is_Subscribed = 1;
        } else if (DirtyFlag === "Subscribe") {
            DirtyFlag = "Update";
            is_Subscribed = 1;
        } else if (DirtyFlag === "Un-Subscribe") {
            is_Subscribed = 0;
            DirtyFlag = "Update";
        }

        return {
            No: $td.eq(0).text(),
            SubscriptionName: subscriptionName,
            RecipientFirstName: $td.eq(1).text(),
            RecipientLastName: $td.eq(2).text(),
            RecipientEmailId: $td.eq(3).text(),
            DirtyFlag: DirtyFlag,
            ModifiedCount: $td.eq(5).text(),
            IsSubscribed : is_Subscribed,
            ReportScheduledId: obtainedSubscriptionDetails.ReportScheduledId,
            ReportID: obtainedSubscriptionDetails.ReportId,
            Frequency: obtainedSubscriptionDetails.Frequency
        }
    }).get();
    return recipientList;
}

/*Recipient Functions Ends*/

/*Report User Functions Starts*/
function bindAvailableSubscriber(lstObject) {

    $('#tbl_availableSubscriber tbody').empty();
    
    if (!obtainedSubscriptionDetails.lstReportRecipient || obtainedSubscriptionDetails.lstReportRecipient.length == 0) {
        $.each(lstObject, function availableSubscriber() {
            addAvailableSubscriber(this);
        });
    }
    else {

        $.each(lstObject, function availableSubscriber() {

            //check whether this subscriber is already added to the recipient list
            //add only when this subscriber is not existing
            var recipientExists = false;
            var curRecipientEmailId = this.RecipientEmailId;

            $.each(obtainedSubscriptionDetails.lstReportRecipient, function () {
                if (this.RecipientEmailId == curRecipientEmailId) {
                    recipientExists = true;
                }
            });
            
            if (!recipientExists) {
                addAvailableSubscriber(this);
            }
        });
    }

    $('.CheckboxSubscriber').change(function chk_select() {
        $("#btn_addSelectedSubscriber").removeAttr('disabled');
    });

}

function bindAvailableSubscriberWithoutFiltering(lstObject) {

    $('#tbl_availableSubscriber tbody').empty();
    
    $.each(lstObject, function availableSubscriber() {
        addAvailableSubscriber(this);
    });


    $('.CheckboxSubscriber').change(function chk_select() {
        $("#btn_addSelectedSubscriber").removeAttr('disabled');
    });

}

function addAvailableSubscriber(availableSubscriber) {
    
    var noofRows = $('#tbl_availableSubscriber tbody tr').length;
    // Find a <table> element with id="myTable":
    var tableBody = document.getElementById("tbl_availableSubscriber_tbody");
    // Create an empty <tr> element and add it to the 1st position of the table:
    var row = tableBody.insertRow(noofRows);

    // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
    var cell0 = row.insertCell(0);
    cell0.innerHTML = "<input type='checkbox' id='chk_availableSubscriber'  class='selectAllCheckBox CheckboxSubscriber'>";
    cell0.className = "col-xs-2";

    var cell1 = row.insertCell(1);
    cell1.innerHTML = availableSubscriber.RecipientFirstName + " " + availableSubscriber.RecipientLastName;
    cell1.className = "col-xs-10";

    var cell2 = row.insertCell(2);
    cell2.innerHTML = availableSubscriber.RecipientFirstName;
    cell2.style.display = "none";

    var cell3 = row.insertCell(3);
    cell3.innerHTML = availableSubscriber.RecipientLastName;
    cell3.style.display = "none";

    var cell4 = row.insertCell(4);
    cell4.innerHTML = availableSubscriber.RecipientEmailId;
    cell4.style.display = "none";
}
/*Report User Functions Ends*/


function onRecipientAdd() {
    var report_Name = $("#ddl_ReportList").val();

    //disable all checkboxes by default on loading the available subscribers popup
    $('table#tbl_availableSubscriber input[type=checkbox]').prop('checked', false);

    if (report_Name == "") {
        TatvamAlert("Please select report name for the subscription.", "Error");
        $("#selectUser").modal('hide');
        return false;
    }
    
    $("#selectUser").modal('show');

}

//method to enable save button - add subscription
function enableSaveButton() {
    $("#btn_newsubscription").css({ 'display': 'inline-block' });
    $("#btn_updatesubscription").css({ 'display': 'none' });
}

//method to enable update option - update subscription
function enableUpdateButton() {
    $("#btn_newsubscription").css({ 'display': 'none' });
    $("#btn_updatesubscription").css({ 'display': 'inline-block' });
}

//function to disable all frequency types
function disableAllFrequencies() {
    //disable all the frequencies    
    $('input:radio[name="ReportPeriodicity"]').prop('checked', false);
}

//function to set either add/edit mode
function setMode(inputData) {
    inputData.isEdit = false;
    if (inputData.ReportScheduledId && inputData.ReportScheduledId > 0) {
        inputData.isEdit = true;
    }
}

//function to maintain state of values in UI of during non-editing scenario 
function maintainUIState(jsonData, inpObject) {
    //update data coverage and periodicity value based on earlier edit/add mode
    //in case earlier selected subscription was editable, then reset both values
    if (obtainedSubscriptionDetails && !obtainedSubscriptionDetails.isEdit && jsonData.ReportScheduledId == 0) {
        jsonData.DataCoverageUnits = inpObject.DataCoverageUnits;
        jsonData.DataCoverageUnitFrequency = inpObject.DataCoverageUnitFrequency;
        jsonData.SubscriptionName = inpObject.SubscriptionName;
    }
    else if (obtainedSubscriptionDetails && obtainedSubscriptionDetails.isEdit && jsonData.ReportScheduledId == 0) {
        jsonData.DataCoverageUnits = "";
        jsonData.DataCoverageUnitFrequency = "Days";
    }
}

//To clear the report filters and hide the panel
function clearReportFilters() {
    $('#reportSubscriptionForm .repeatingSection').remove();
    $("#reportSubscriptionFilterMessage").hide();
    $('#reportSubscriptionAddFilter').show();
}


function resetToNewSubscription() {

    $("#lbl_subscription_id").text("");
    $("#txt_SubscriptionName").val("");
    $("#ddl_ReportList").val("");
    $("#txt_PeriousPeriod").val("");
    $("#ddl_ReportPeriodicity").val("Days");
    $("#tbl_RecipientDetails > tbody").empty();
    $("#btn_addSelectedSubscriber").attr('disabled', 'disabled');
    $("#btn_newsubscription").attr('disabled', 'disabled');

    $("#txt_PeriousPeriod").removeAttr('disabled');
    $("#ddl_ReportPeriodicity").removeAttr('disabled');
    $('#div_recipient').hide();
    $("#ddl_State").val("Active");
    $("#statusBlock").css("display", "none");
    enableSaveButton();

    disableAllFrequencies();
    clearReportFilters();
}

//method checks if subscription already exists based on subscription name.
function CheckSubscriptionExists() {
    var isSubscriptionExists = false;
    var objSubscription = {};
    objSubscription.SubscriptionName = $.trim($("#txt_SubscriptionName").val());

    //Ajax call to get the Report subscription Details
    var rtnVal = TatvamAjaxCallWithReturn("GET", "../ReportSubscription/GetSubscriptionDetails", objSubscription);
    
    //parse the return value
    var jsonData = JSON.parse(rtnVal.responseText);

    //if ReportScheduledId exists then subscription already exists with the same subscription name.
    if ((jsonData && jsonData.ReportScheduledId !== 0 && jsonData.ReportScheduledId !== undefined) && (jsonData.ReportScheduledId !== obtainedSubscriptionDetails.ReportScheduledId)) {
        TatvamAlert("Subscription already exist with the same name. Please change subscription name.", "Warning");
        isSubscriptionExists = true;
    }
    else if (obtainedSubscriptionDetails.ReportScheduledId === 0 && (objSubscription.SubscriptionName === jsonData.SubscriptionName)) {
        TatvamAlert("Subscription already exist with the same name. Please change subscription name.", "Warning");
        isSubscriptionExists = true;
    }
    return isSubscriptionExists;
}