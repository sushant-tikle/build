﻿// Related Dimension List Grid Default Settings
function getDefaultOptions() {
    var tmpOptions = {
        caption: 'Related Classifier List', //Name of the Widget
        defaultRowHeight: 20,
        //defaultColWidth: 100,
        rowSelection: 'single',
        enableAutoSizeColumns: true,
        enableCellSelection: true,
        enableRowSelectionOnCellClick: false,
        enableJumpToRow: false, //enables spreadsheet jump to Row
        enableJumpToColumn: false, //enables spreadsheet jump to Column
        enableExportToCSV: true, //enables spreadsheet data export to csv	         

        //Column level properties
        enableColumnfloatingFilter: false, //Will allow the user to filter on the column
        enableColSorting: true, //Will allow the user to sort the columns	
        enableColHide: true, //enables spreadsheet column hide and unhide	     
        enableColResize: true, //property to enables spreadsheet column resizing        
        enableColFreezing: true, //property to enables spreadsheet column freezing	
        enableColumnMoveable: true, //property to enables spreadsheet column reordering
        enableSizeColumnsToFit: true,
        //Row level properties	 
        enableRowResize: false, //property to enables spreadsheet row resizing	       

        enableActionBar: true, //Below property will enable the action bar for the widget	 
        enableFormatting: false,  //enables spreadsheet formatting	      
    };
    return tmpOptions;
}


function viewReviewDetails() {
    //$('#RelatedDimensionReview').modal("show");    
    var selectedCellInfo = $("#grid_RelatedDimensions").spreadsheetWidget('getSelectedCell');
    if (selectedCellInfo === "") {
        TatvamAlert('Please select the cell to view the reviews.');
        return false;
    }
    var data = [selectedCellInfo.currentSelected.colID, ]
}

var GET_RELATEDDIMENSIONDATA = '../Data/GetGridData';
var GET_RELATEDReviews = '../RelatedCustomerDimensions/GetRelatedReviews';


function onMeasureChange() {
    var selMeasure = getSelectedMeasure();
    $('#ddlRelatedDimensionMeasure option').removeAttr("selected", "selected");
    $('#ddlRelatedDimensionMeasure option:selected').attr("selected", "selected");
    var data = {
        reportId: reportId,
        inpDimensionType: "CLASSIFIER",
        inpMeasure: selMeasure,
        tatvamReportFilterTo: null
    }
    TatvamAjaxCalls("GET", GET_RELATEDDIMENSIONDATA, data, bindDimensions, {});
}

function bindDimensions(data) {
    $("#grid_RelatedDimensions").empty();
    if (data.response.Result._GridData.length === 0) {
        $("#grid_RelatedDimensions").append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }
    var relatedDimensionList = data.response.Result;
    data = JSON.stringify(relatedDimensionList._GridData);
    data = JSON.parse(data);
    var colDef = getColumnDefinition(data);
    //Get the default gridOptions from the control. Do this before since instantiation requires this 
    //var defaultOptions = RelatedDimensionList._Properties;
    var defaultOptions = getDefaultOptions();
   // defaultOptions.frozenColumns = [{ "colId": "Classifier", "pinned": "left" }];
    //Instantiate the spreadsheet control at the specific ID 
    $("#grid_RelatedDimensions").spreadsheetWidget(defaultOptions);
    $("#grid_RelatedDimensions").spreadsheetWidget('ResetColumnDefinition', colDef);
    $("#grid_RelatedDimensions").spreadsheetWidget('setRowData', data);
    $("#grid_RelatedDimensions").spreadsheetWidget("setCellFocus", { rowIndex: 0, colName: data[0].Classifier });
    $("#grid_RelatedDimensions").spreadsheetWidget("sizeToFit");
}

function getColumnDefinition(colProp) {
    var selMeasure = $("#ddlRelatedDimensionMeasure").val();
    var columnDefs = [];
    columnDefs.push({
        headerName: 'Classifier', field: 'Classifier', width: 200, filter: 'string', cellStyle: {
            "text-align": "left"
        }
    });

    $.each(colProp[0], function (key, value) {
        if (key != "Classifier") {
            columnDefs.push({
                headerName: key, field: key, 
                cellRenderer: function (params) {
                    var trnVal = params.data[params.colDef.field];
                    if (trnVal === 0) {
                        return "-";
                    }
                    if (trnVal === "0") {
                        return "-";
                    }
                    if (selMeasure === "Average") {
                        return parseFloat(trnVal).toFixed(2);
                    }
                    return trnVal;
                },
                cellStyle: function (params) {
                    if (selMeasure === "Average") {
                        var trnVal = params.data["Classifier"];
                        var backgroundColor = TatvamRatingColor(params.data[params.colDef.field]);
                        return { backgroundColor: backgroundColor, "text-align": "right" };
                    }
                    return {
                        "text-align": "right"
                    };
                }
            });
        }
    });
    return columnDefs;
}

function getSelectedMeasure(){
    var selMeasure = $("#ddlRelatedDimensionMeasure").val();
    return selMeasure;
}

function onViewReviews() {
    var selRelatedDimensions = [];
    var selectedCell = $("#grid_RelatedDimensions").spreadsheetWidget("getFocusedCell");
    selRelatedDimensions.push({ "Name": selectedCell.column.colId });
    var rowData = $("#grid_RelatedDimensions").spreadsheetWidget("getRowDataByIndex", selectedCell.rowIndex);
    selRelatedDimensions.push({ "Name": rowData.Classifier });

    if (selectedCell.column.colId === "Classifier") {
        TatvamAlert("Please select the data value", "Warning");
        return false;
    }

    if (rowData[selectedCell.column.colId] === 0) {
        TatvamAlert("No Reviews to display", "Warning");
        return false;
    }

    


    var array=[];
    var inputFilters = {
        "SearchbyText": "Classifier",
        "SearchbyValue": " TARGET_ENTITY_VALUE in (@Classifier) ",
        "OperatorName": "Equal To",
        "OperatorValue": "in",
        "SelectedText": selRelatedDimensions,
        "SelectedValue": selRelatedDimensions,
        "ConditionName": "and",
        "ConditionValue": "and"
    }
    array.unshift(inputFilters);

    var selMeasure = getSelectedMeasure();
    var data = {
        reportId: reportId,
        inpDimensionType: "CLASSIFIER",
        inpMeasure: selMeasure,
        tatvamReportFilterTo: JSON.stringify(array)
    }

    TatvamAjaxCalls("POST", GET_RELATEDReviews, data, viewReview, {})
}

function viewReview() {
}