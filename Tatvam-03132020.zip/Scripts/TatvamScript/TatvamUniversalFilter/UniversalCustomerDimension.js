﻿/* Script Contents to be included into the JS file - Start*/
var masterJson;
var counter = 0;
var selecetdCacheUCDFilters;
var ucdFilterSearchByUrl = "../Filter/TatvamUniversalCustomerDimensonFilter";
var ucdFilterSearchValuesUrl = "../Filter/TatvamFilterSearchValue";
var ClearUCDCacheUrl = "../Filter/RemoveUniversalDimensionFilterCache";
var RetriveSavedUCDFiltersUrl = '../Filter/UniversalDimensionFilterByCache';
/*Function to Create the HTML contents and Place holder for the Controls - Start*/
//To-Do: Need to remove static coded html creation
function ucdModalRow(counter) {
    var ucdRowHtml = '<div class="repeatingSection universalFilterRepeatSection row"> '
        + '<div class="form-group col-xs-6 col-sm-2"> '
        + '<label for="ddlUCDSearchBy_' + counter + '">Search By</label> '
        + '<select id="ddlUCDSearchBy_' + counter + '" class="form-control ddlUCDSearchBy" name="ddlUCDSearchBy_' + counter + '" onchange="onChangeSearchBy(this)"> '
        + '</select> '
        + ' </div> '
        + '  <div class="form-group col-xs-12 col-sm-7" id="divUCDDDLValue"> '

        + '   <button type="button" class=" chosen-toggle deselect" onclick="ucdValueDeselect(event)">Deselect all</button> '
        + '   <button type="button" class="chosen-toggle select" onclick="ucdValueSelect(event)">Select all</button> '
        + '  <label for="ddlUCDValue_' + counter + '">Value</label> '
        + '   <select multiple class="form-control chosen-select ddlUCDValue required" id="ddlUCDValue_' + counter + '" name="ddlUCDValue_' + counter + '"></select> '
        + '  </div> '
        + ' <div class="customBtnGroup btn-group col-xs-6 col-sm-2"> '
        //        +'<button type="button" class="btn btn-primary btn-sm" onclick="ucdAddFilter(event)">AND</button>'
        //        +'<button type="button" class="btn btn-default btn-sm" onclick="ucdAddFilter(event)">OR</button>'

        + '<div class="btn-group" data-toggle="buttons" id="ddlUCDCondition_' + counter + '" onclick="ucdAddFilter(event,this)">'
        + '<label class="btn switchBtn btn-on btn-sm">'
        + '<input type="radio" value="AND" name="universalFilterCondition">AND</label>'
        + '<label class="btn switchBtn btn-off btn-sm ">'
        + '<input type="radio" value="OR" name="universalFilterCondition">OR</label>'
        + '</div>'

        //          + '   <label for="ddlUCDCondition_' + counter + '">Condition</label> '
        //
        //          + '   <select class="form-control required" id="ddlUCDCondition_' + counter + '" onchange="ucdAddFilter(event)"> '
        //           + '      <option value="">Select</option> '
        //            + '     <option value="AND">AND</option> '
        //            + '     <option value="OR">OR</option> '
        //           + '  </select> '
        + ' </div> '
        + ' <div class="form-group col-xs-6 col-sm-1"> '
        + '    <a href="#" class="buttonGray buttonRight deleteFilter customDeleteBtn" onclick="ucdDeleteFilter(event)"><i class="fa fa-trash-o"></i></a> '
        + '  </div> '

        + ' </div> ';
    return ucdRowHtml;
}
/*Function to Create the HTML contents and Place holder for the Controls - End*/

/*Function to Validate the Select Dropdown for Null or Empty - Start*/
function ddlValidate() {
    var flag = true;
    var e = $('#ucdForm .repeatingSection').find('select') || $('#ucdForm .repeatingSection').last().find('.chosen-choices') || $('#ucdForm .repeatingSection').find("input");
    for (i = 0; i < (e.length); i++) {
        var optionSelIndex = e[i].selectedIndex;
        $("#" + e[i].id).removeClass("ddlUCDError");
        if (!optionSelIndex) {
            var optionSelectedText = e[i].options[e[i].selectedIndex].value;
        }
        if (optionSelIndex < 0 || (optionSelIndex == 0 && optionSelectedText == '')) {
            var optionName = $("#" + e[i].id).parent().find('label')[0].textContent;
            $("#" + e[i].id).addClass("ddlUCDError");
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select an Option in " + optionName,
                size: "small",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                }
            });

            flag = false;
            break;
        }
    }
    return flag;
}
/*Function to Validate the Select Dropdown for Null or Empty - End*/

//Function to reset ucdForm - Starts
function ucdFormReset() {
    $(".universalFilterRepeatSection").remove();
    RetrieveSelectedUniversalCustomerDimFilter();
}
//Function to reset ucdForm - End

/*Function to Apply the Created Filters - Start*/

function ucdApplyFilter() {
    var flag = ddlValidate();
    if (flag) {
        $('#ucdAppliedFilterCount').empty();
        var rowData = retreiveRow();
        ucdSaveFilters(rowData);
        $("#ucdModal").modal('toggle');
        var count = $('#ucdForm .repeatingSection').length;
        $('#ucdAppliedFilterCount').append(count);
        $("#ucdFilterMessage").show();
    }
}
/*Function to Apply the Created Filters - End*/

/*Function to Select All values  - Start*/
function ucdValueSelect(e) {
    $(e.target).parent().find('option').prop('selected', true).parent().trigger('chosen:updated');
}
/*Function to Select All values  - End*/


/*Function to Select All values  - Start*/
function ucdValueDeselect(e) {
    $(e.target).parent().find('option').prop('selected', false).parent().trigger('chosen:updated');
}
/*Function to Clear All values  - End*/

/*Function to Delete Individual Filter - Start*/
function ucdDeleteFilter(e) {
    e.preventDefault();
    var current_filter = $(e.target).closest('#ucdForm .repeatingSection');
    var other_filters = current_filter.siblings('#ucdForm .repeatingSection');
    var valueId = $(e.target).closest('#ucdForm .repeatingSection').find('.ddlUCDValue').attr("id");
    if (other_filters.length === 0) {
        bootbox.alert({
            title: "Alert Box",
            size: "small",
            message: "You should atleast have one filter",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        });
        return;
    }
    current_filter.slideUp('slow', function () {
        current_filter.remove();
        // reset filter indexes
        other_filters.each(function () {
            resetAttributeNames($(this));
        })
    })
}
/*Function to Delete Individual Filter - End*/

/*Function to Create an Filter - Start*/
function ucdAddFilter(e, curObj) {
    var isLastChild = $(curObj).closest(".universalFilterRepeatSection ").is(":last-child");
    e.preventDefault();
    counter = generateCounter();
    var flag = ddlValidate();
    if (flag && isLastChild) {
        initCreateRow(counter);
    }
}

/*Function to Create an Filter - End*/


/*Function to bind the values on change of Search by - Start*/
function onChangeSearchBy(selectedObj) {
    var valueId = $("#" + selectedObj.id).closest('#ucdForm .repeatingSection').find('.ddlUCDValue').attr("id");
    var value = document.getElementById(valueId);
    var selectedFilter = selectedObj.options[selectedObj.selectedIndex].text;
    if (selectedObj.options[selectedObj.selectedIndex].data.ControlName === "MultiSelect") {
        $("#" + value.id).chosen('destroy');
        $("#" + valueId).replaceWith('<select multiple class="form-control chosen-select ddlUCDValue required" id="ddlUCDValue_' + counter + '" name="ddlUCDValue_' + counter + '"></select>');
        GetUCDSearchValues(selectedFilter, value, valueId);
        $("#" + valueId).trigger("chosen:updated");
    } else if (selectedObj.options[selectedObj.selectedIndex].data.ControlName === "TextBox") {
        $("#" + valueId).chosen('destroy');
        $("#" + valueId).replaceWith('<input  class="form-control ddlUCDValue"  id="ddlUCDValue_' + counter + '" />');
    }
}

/*Function to bind the values on change of Search by - End*/

/*Function to bind the values to SearchBy - Start*/
function bindDataToMaster(searchBy, masterJson) {
    if (searchBy == null) {
        return null;
    }
    for (var i = 0; i < masterJson.SearchBy.length; i++) {
        searchBy.options[searchBy.options.length] = new Option(masterJson.SearchBy[i].DimensionDisplayName, masterJson.SearchBy[i].DimensionParameter);
        var dimParam = JSON.parse(masterJson.SearchBy[i].DimensionParameter);
        searchBy.options[i].setAttribute("key_type", dimParam.DimensionDisplayName);
        searchBy.options[i].data = masterJson.SearchBy[i];
    }
}
/*Function to bind the values to SearchBy - End*/

/*Function to bind the values to Operator - Start*/
function bindDataToOperator(operator, operatorJson) {
    for (var i = 0; i < operatorJson[i].LstTatvamOperators.length; i++) {
        operator.options[operator.options.length] = new Option(operatorJson[i].LstTatvamOperators[i].OperatorDisplayName, operatorJson[i].LstTatvamOperators[i].OperatorSymbol);
    }
}

/*Function to bind the values to Operator - End*/


/*Function to bind the values to Values - Start*/
function bindDataToDimension(selectedFilter, value, ucdSearchValues) {
    $("#" + value.id).empty();
    if (selectedFilter != "Comment") {
        var select = $("#" + value.id);
        var data = ucdSearchValues;
        for (var prop in data) {
            var option = document.createElement('option');
            option.innerHTML = data[prop].Text;
            option.value = data[prop].Value;
            select.append(option);
        }
        $("#" + value.id).chosen('destroy');
        $("#" + value.id).chosen({
            width: "100%",
            create_option: false,
            skip_no_results: false,
            select_all_buttons: true,  //Adds "Select all" and "deselect all" buttons
            select_all_character: '*',  // Selecting all result for a specified key
            select_all_character: '/'  //Removing all result for a specified key
        });
    } else {
        $("#" + value.id).chosen('destroy');
        $("#" + value.id).chosen({
            width: "100%",
            create_option: false,
            skip_no_results: true,
            select_all_buttons: true,  //Adds "Select all" and "deselect all" buttons
            select_all_character: '*',  // Selecting all result for a specified key
            select_all_character: '/'  //Removing all result for a specified key
        });
    }

}
/*Function to bind the values to Values - End*/

/*Function to Rename the Control ID's when a filter is Deleted - Start*/
function resetAttributeNames(section) {
    var attrs = ["for", "id", "name"];
    var tags = section.find('input, label, select, div'), idx = section.index();
    tags.each(function() {
        var $this = $(this);
        $.each(attrs,
            function(i, attr) {
                var attr_val = $this.attr(attr);
                if (attr_val) {
                    $this.attr(attr, attr_val.replace(/(_)(\d+)/g, '_' + (idx)));
                }
            });
    });
}

/*Function to Rename the Control ID's when a filter is Deleted - End*/

/*Function to Delete all Applied Filters - Start*/
function ucdResetFilter(e) {
    bootbox.confirm({
        size: "small",
        title: "Alert Box",
        message: "Reset will remove all the Applied Filters. <br/> Are you sure you want to Reset?",
        buttons: {
            confirm: {
                label: 'Reset',
                className: 'btn-primary'
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-default'
            }
        },
        callback: function(result) {
            if (result) {
                //$('#ucdForm .repeatingSection').remove();
                //counter = generateCounter();
                //initCreateRow(counter);
                //$("#ucdFilterMessage").hide();
                $(this).modal('hide');
                ClearUCDCache();
                //sessionStorage.removeItem('ucdFilter');
            } else {
                $(this).modal('hide');
            }
        }
    });

}
/*Function to Delete all Applied Filters - End*/

/*Function to Initialise Method on Page Load for UCD Filter - Start*/
function initCreateRow(counter) {
    $('#ucdForm .formBody').last().append(ucdModalRow(counter));
    var searchBy = document.getElementById("ddlUCDSearchBy_" + counter);
    if (searchBy == null) {
        return;
    }
    var value = document.getElementById("ddlUCDValue_" + counter);

    //Function Call to Bind Data to the Search By DDL
    bindDataToMaster(searchBy, masterJson);
    //        bindDataToOperator(operator, masterJson.SearchBy);
    var selectedFilter = $("#" + searchBy.id + " option:selected").text();
    GetUCDSearchValues(selectedFilter, value);
}
/*Function to Initialise Method on Page Load for UCD Filter - End*/

/*Function to Initialise Method on Page Load when Filter Already Exists for UCD Filter - Start*/
function initRetreivedRow(savedFilter) {
    for (var key in savedFilter) {
        initCreateRow(key);
        $("#ddlUCDSearchBy_" + key + "  option").each(function () {
            var dimParam = JSON.parse($(this).val());
            if (dimParam.KeyType === savedFilter[key].KeyType && dimParam.ParentType === savedFilter[key].ParentType) {
                $(this).attr("selected", true);
            } else { $(this).attr("selected", false); }
        });
        //$('#ddlUCDSearchBy_' + key + ' option[text="' + savedFilter[key].KeyType + '"]').prop('selected', true);
        //$('#ddlUCDSearchBy_' + key + ' option[key_type="' + savedFilter[key].KeyType + '"]').prop('selected', true);
        $("#ddlUCDSearchBy_" + key + " option:contains(" + savedFilter[key].KeyType + ")").attr('selected', true);
        if (savedFilter[key].ConditionName == "AND") {
            $("#ddlUCDCondition_" + key + " .btn-on").addClass('active');
        } else {
            $("#ddlUCDCondition_" + key + " .btn-off").addClass('active');
        }
        var objValue = savedFilter[key].KeyWordValues;
        var objText = savedFilter[key].KeyWordValues;
        var value = document.getElementById("ddlUCDValue_" + key);
        if (savedFilter[key].KeyType != "Comment") {
            var selectedFilter = $("#ddlUCDSearchBy_" + key + " option:selected").text();
            GetUCDSearchValues(selectedFilter, value);
            for (var prop in objValue, objText) {
                $("#ddlUCDValue_" + key + " option[value='" + objValue[prop] + "']").prop('selected', true);
            }
            $('#ddlUCDValue_' + key).trigger("chosen:updated");
        } else {
            $("#ddlUCDValue_" + key).chosen('destroy');
            $("#ddlUCDValue_" + key).replaceWith('<input  class="form-control ddlUCDValue"  id="ddlUCDValue_' + counter + '"  />');
            $("#ddlUCDValue_0").val(objValue[0]);
        }


    }
    var count = $('#ucdForm .repeatingSection').length;
    $('#ucdAppliedFilterCount').empty();
    $('#ucdAppliedFilterCount').append(count);
    $("#ucdFilterMessage").show();
}

/*Function to Initialise Method on Page Load when Filter Already Exists for UCD Filter - End*/

/*Function to Store the values of the Filter into Object Model - Start*/
function retreiveRow() {
    var rowData = [];
    var row = $('#ucdForm .repeatingSection');
    for (var i = 0; i < row.length; i++) {
        var currentRow = {};
        var currentRow1 = {};
        $("#ddlUCDSearchBy_" + i + " option:selected").each(function () {
            currentRow.SearchbyText = $(this).text();
            currentRow.SearchbyValue = $(this).val();
        });

        var DimensionParameter = JSON.parse(currentRow.SearchbyValue);
        currentRow1.ParentType = DimensionParameter.ParentType;
        currentRow1.KeyType = DimensionParameter.KeyType;
        if (DimensionParameter.FilterType === "source" || DimensionParameter.FilterType === "category" || DimensionParameter.FilterType === "comment") {
            currentRow1.KeyType = currentRow.SearchbyText;
        }

        var isActiveBtn = $("#ddlUCDCondition_" + i + " .btn-on").hasClass("active");
        if (isActiveBtn) {
            currentRow1.Condition = "AND";
        } else {
            currentRow1.Condition = "OR";
        }
        currentRow1.KeyWordValues = FetchValue(i, currentRow.SearchbyText);
        rowData.push(currentRow1);
    }
    return rowData;
}

function retreiveRow_Old() {
    var rowData = [];
    var row = $('#ucdForm .repeatingSection');
    for (i = 0; i < row.length; i++) {
        rowData[i] = {};
        $("#ddlUCDSearchBy_" + i + " option:selected").each(function () {
            rowData[i]["SearchbyText"] = $(this).text();
            rowData[i]["SearchbyValue"] = $(this).val();
        });
        /*$("#ddlUCDCondition_" + i + " input[name='universalFilterCondition']:checked").each(function () {
            rowData[i]["ConditionName"] = $(this).text();
            rowData[i]["ConditionValue"] = $(this).val();
        });*/

        var isActiveBtn = $("#ddlUCDCondition_" + i + " .btn-on").hasClass("active");
        if (isActiveBtn) {
            rowData[i]["ConditionName"] = "AND";
            rowData[i]["ConditionValue"] = "AND";
        } else {
            rowData[i]["ConditionName"] = "OR";
            rowData[i]["ConditionValue"] = "OR";
        }

        rowData[i]["SelectedText"] = FetchText(i);
        rowData[i]["SelectedValue"] = FetchValue(i);
    }
    return rowData;
}

/*Function to Store the values of the Filter into Object Model - End*/

/*Function to Store the applied Filter in Session - Start*/
function ucdSaveFilters(rowData) {
    showLoadingCursor();
    //sessionStorage.setItem('ucdFilter', JSON.stringify(rowData));

    var ucdFilters = JSON.stringify(rowData);
    $.ajax({
        type: "POST",
        url: "../Filter/SaveUniversalDimensionFilter",
        data: { TatvamReportFilterTo: ucdFilters },
        success: function (isSelectedUcdFiltersSaved) {
            if (isSelectedUcdFiltersSaved) {
                location.reload(true);
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
        , complete: function () {
        }
    });
}

/*Function to Store the applied Filter in Session - End*/

/*Function to Retrieve the applied Filter in Session - Start*/
function ucdRetreiveucdSavedFilter() {
    var sesStoredData = sessionStorage.ucdFilter;
    if (sesStoredData != undefined)
        sesStoredData = JSON.parse(sesStoredData);
    return sesStoredData;
}
/*Function to Retrieve the applied Filter in Session - End*/

/*Function to generate the number of Filters  - Start*/
function generateCounter() {
    counter = $('#ucdForm .repeatingSection').length;
    return counter;
}
/*Function to generate the number of Filters  - End*/

/*Function to bind Object Model into the RowData Model for Search by Text  - Start*/
function FetchText(i) {
    var data = [];
    $('#ddlUCDValue_' + i + '_chosen > ul > li').each(function () {
        data.push({ "Name": $(this).contents().eq(0).text().trim() });
    });
    data.pop();
    return data;
}
/*Function to bind Object Model into the RowData Model for Search by Text  - End*/

/*Function to bind Object Model into the RowData Model for Search by Value  - Start*/
function FetchValue(i, searchText) {

    var data = [];
    var selector = $('#ddlUCDValue_' + i).val();
    if (searchText != "Comment") {
        for (var j = 0; j < selector.length; j++) {
            data.push(selector[j]);
        }
    }
    else {
        data.push(selector);
    }

    return data;
}

/*Function to bind Object Model into the RowData Model for Search by Text  - End*/


$(document).ready(function () {
    GetUCDFilterSearchBy();
});

function GetUCDFilterSearchBy() {
    $.ajax({
        type: "POST",
        async: false,
        url: ucdFilterSearchByUrl,
        success: function (result) {
            masterJson = result;
            RetrieveSelectedUniversalCustomerDimFilter();
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function GetUCDSearchValues(selectedSearchBy, value) {
    if (selectedSearchBy != "" && selectedSearchBy != undefined) {
        var dimensionParameter = GetUCDSearchByDimensionParameter(selectedSearchBy);
        $.ajax({
            type: "POST",
            async: false,
            url: ucdFilterSearchValuesUrl,
            data: { DimensionParameter: dimensionParameter },
            success: function (result) {
                bindDataToDimension(selectedSearchBy, value, result);
            },
            error: function (xhr, status, p3, p4) {
                var error = JSON.parse(xhr.responseText);
                TatvamAlert(error.ErrorMessage, "Error");
            }
        });
    }
}

function GetUCDSearchByDimensionParameter(selectedSearchBy) {
    var searchBy = masterJson.SearchBy;
    var index, queryId;
    for (index = 0; index < searchBy.length; ++index) {
        if (searchBy[index].DimensionDisplayName === selectedSearchBy) {
            queryId = searchBy[index].DimensionParameter;
            break;
        }
    }
    return queryId;
}

//Method to get queryid for selected dimension(search by) in UCD control
function GetUCDSearchByQueryId(selectedSearchBy) {
    var searchBy = masterJson.SearchBy;
    var index, queryId;
    for (index = 0; index < searchBy.length; ++index) {
        if (searchBy[index].DimensionDisplayName === selectedSearchBy) {
            queryId = searchBy[index].QueryId;
            break;
        }
    }
    return queryId;
}
//method to get saved customer dimension filters from cache
function RetrieveSelectedUniversalCustomerDimFilter() {
    if (!selecetdCacheUCDFilters) {
        $.ajax({
            type: "POST",
            url: RetriveSavedUCDFiltersUrl,
            success: function (selectedUCDFilters) {
                selecetdCacheUCDFilters = selectedUCDFilters;
                SetUcdFilters();
            },
            error: function (xhr, status, p3, p4) {
                var error = JSON.parse(xhr.responseText);
                TatvamAlert(error.ErrorMessage, "Error");
            }
        });
    }
    else {
        SetUcdFilters();
    }
}

function SetUcdFilters() {
    if (selecetdCacheUCDFilters && selecetdCacheUCDFilters.length > 0) {
        initRetreivedRow(selecetdCacheUCDFilters);
    } else {
        generateCounter();
        initCreateRow(counter);
    }
}


//To Clear the Saved UCD Filter from Cache.
function ClearUCDCache() {
    $.ajax({
        type: "GET",
        url: ClearUCDCacheUrl,
        success: function (result) {
            if (result.IsRemoved) {
                location.reload();
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}



/* Script Contents to be included into the JS file - End*/
