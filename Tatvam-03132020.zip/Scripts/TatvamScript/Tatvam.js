///#source 1 1 /Scripts/TatvamScript/Layout/MenuResizeHandler.js
jQuery(document).ready(function() {
    Metronic.init();
    Layout.init();
});


$(document).ready(function() {
    var setElementHeight = function() {
        var height = $(window).height();
        $('.page-sidebar-menu').css('height', (height));
    };

    $(window).on("resize", function() {
            setElementHeight();
        })
        .resize();
});

var Metronic = function() {
    var resizeHandlers = [];
    var assetsPath = '../../assets/';
    return {
        init: function() {
        },

        addResizeHandler: function(func) {
            resizeHandlers.push(func);
        },

        destroySlimScroll: function(el) {
            $(el).each(function() {
                if ($(this).attr("data-initialized") === "1") {
                }
            });
        },
        isTouchDevice: function() {
            try {
                document.createEvent("TouchEvent");
                return true;
            } catch (e) {
                return false;
            }
        },

        // To get the correct viewport width based on  http://andylangton.co.uk/articles/javascript/get-viewport-size-javascript/
        getViewPort: function() {
            var e = window,
                a = 'inner';
            if (!('innerWidth' in window)) {
                a = 'client';
                e = document.documentElement || document.body;
            }

            return {
                width: e[a + 'Width'],
                height: e[a + 'Height']
            };
        },
        getAssetsPath: function() {
            return assetsPath;
        }
    };
}();
///#source 1 1 /Scripts/TatvamScript/Layout/SideBar.js
var Layout = function () {

    var layoutCssPath = Metronic.getAssetsPath() + '';
    var handleSidebarAndContentHeight = function () {
        var content = $('.page-content');
        var sidebar = $('.page-sidebar');
        var body = $('body');

        if (body.hasClass("page-footer-fixed") === true && body.hasClass("page-sidebar-fixed") === false) {
            var availableHeight = Metronic.getViewPort().height - $('.page-footer').outerHeight() - $('.page-header').outerHeight();
            if (content.height() < availableHeight) {
                content.attr('style', 'min-height:' + availableHeight + 'px');
            }
        } else {
            var height;
            if (body.hasClass('page-sidebar-fixed')) {
                 height = _calculateFixedSidebarViewportHeight();
                if (body.hasClass('page-footer-fixed') === false) {
                    height = height - $('.page-footer').outerHeight();
                }
            } else {
                var headerHeight = $('.page-header').outerHeight();
                var footerHeight = $('.page-footer').outerHeight();

                if (Metronic.getViewPort().width < 992) {
                    height = Metronic.getViewPort().height - headerHeight - footerHeight;
                } else {
                    height = sidebar.height() + 20;
                }

                if ((height + headerHeight + footerHeight) <= Metronic.getViewPort().height) {
                    height = Metronic.getViewPort().height - headerHeight - footerHeight;
                }
            }
        }
    };


    // Handles sidebar toggler to close/hide the sidebar.
    var handleFixedSidebarHoverEffect = function () {
        var body = $('body');
        if (body.hasClass('page-sidebar-fixed')) {
            $('.page-sidebar').on('mouseenter', function () {
                if (body.hasClass('page-sidebar-closed')) {
                    $(this).find('.page-sidebar-menu').removeClass('page-sidebar-menu-closed');
                }
            }).on('mouseleave', function () {
                if (body.hasClass('page-sidebar-closed')) {
                    $(this).find('.page-sidebar-menu').addClass('page-sidebar-menu-closed');
                }
            });
        }
    };


 
    // Handle sidebar menu
    var handleSidebarMenu = function () {
        // handle sidebar link click
        jQuery('.page-sidebar').on('click', 'li > a', function (e) {
            if (Metronic.getViewPort().width >= 992 && $(this).parents('.page-sidebar-menu-hover-submenu').length === 1) { // exit of hover sidebar menu
                return;
            }

            if ($(this).next().hasClass('sub-menu') === false) {
                if (Metronic.getViewPort().width < 992 && $('.page-sidebar').hasClass("in")) { // close the menu on mobile view while laoding a page 
                    $('.page-header .responsive-toggler').click();
                }
                return;
            }

            if ($(this).next().hasClass('sub-menu always-open')) {
                return;
            }

            var parent = $(this).parent().parent();
            var the = $(this);
            var menu = $('.page-sidebar-menu');
            var sub = jQuery(this).next();

            var autoScroll = menu.data("auto-scroll");
            var slideSpeed = parseInt(menu.data("slide-speed"));
            var keepExpand = menu.data("keep-expanded");

            if (keepExpand !== true) {
                parent.children('li.open').children('a').children('.arrow').removeClass('open');
                parent.children('li.open').children('.sub-menu:not(.always-open)').slideUp(slideSpeed);
                parent.children('li.open').removeClass('open');
            }

            var slideOffeset = -200;

            if (sub.is(":visible")) {
                jQuery('.arrow', jQuery(this)).removeClass("open");
                jQuery(this).parent().removeClass("open");
                sub.slideUp(slideSpeed, function () {
                    if (autoScroll === true && $('body').hasClass('page-sidebar-closed') === false) {
                        if ($('body').hasClass('page-sidebar-fixed')) {
                            menu.slimScroll({
                                'scrollTo': (the.position()).top
                            });
                        } else {
                            Metronic.scrollTo(the, slideOffeset);
                        }
                    }
                    handleSidebarAndContentHeight();
                });
            } else {
                jQuery('.arrow', jQuery(this)).addClass("open");
                jQuery(this).parent().addClass("open");
                sub.slideDown(slideSpeed, function () {
                    if (autoScroll === true && $('body').hasClass('page-sidebar-closed') === false) {
                        if ($('body').hasClass('page-sidebar-fixed')) {
                            menu.slimScroll({
                                'scrollTo': (the.position()).top
                            });
                        } else {
                            Metronic.scrollTo(the, slideOffeset);
                        }
                    }
                    handleSidebarAndContentHeight();
                });
            }

            e.preventDefault();
        });

        // handle ajax links within sidebar menu
        jQuery('.page-sidebar').on('click', ' li > a.ajaxify', function (e) {
            e.preventDefault();
            Metronic.scrollTop();

            var url = $(this).attr("href");
            var menuContainer = jQuery('.page-sidebar ul');
            var pageContentBody = $('.page-content .page-content-body');

            menuContainer.children('li.active').removeClass('active');
            menuContainer.children('arrow.open').removeClass('open');

            $(this).parents('li').each(function () {
                $(this).addClass('active');
                $(this).children('a > span.arrow').addClass('open');
            });
            $(this).parents('li').addClass('active');

            if (Metronic.getViewPort().width < 992 && $('.page-sidebar').hasClass("in")) { // close the menu on mobile view while laoding a page 
                $('.page-header .responsive-toggler').click();
            }

            Metronic.startPageLoading({animate: true});

            var the = $(this);

            $.ajax({
                type: "GET",
                cache: false,
                url: url,
                dataType: "html",
                success: function (res) {

                    if (the.parents('li.open').length === 0) {
                        $('.page-sidebar-menu > li.open > a').click();
                    }

                    Metronic.stopPageLoading();
                    pageContentBody.html(res);
                    Layout.fixContentHeight(); // fix content height
                    Metronic.initAjax(); // initialize core stuff
                },
                error: function () {
                    Metronic.stopPageLoading();
                    pageContentBody.html('<h4>Could not load the requested content.</h4>');
                    TatvamAlert("Could not load the requested content.", "Error");                    
                }
            });
        });

        // handle ajax link within main content
        jQuery('.page-content').on('click', '.ajaxify', function (e) {
            e.preventDefault();
            Metronic.scrollTop();

            var url = $(this).attr("href");
            var pageContentBody = $('.page-content .page-content-body');

            Metronic.startPageLoading({animate: true});

            if (Metronic.getViewPort().width < 992 && $('.page-sidebar').hasClass("in")) { // close the menu on mobile view while laoding a page 
                $('.page-header .responsive-toggler').click();
            }

            $.ajax({
                type: "GET",
                cache: false,
                url: url,
                dataType: "html",
                success: function (res) {
                    Metronic.stopPageLoading();
                    pageContentBody.html(res);
                    Layout.fixContentHeight(); // fix content height
                    Metronic.initAjax(); // initialize core stuff
                },
                error: function () {
                    pageContentBody.html('<h4>Could not load the requested content.</h4>');
                    Metronic.stopPageLoading();
                    TatvamAlert("Could not load the requested content.", "Error");                    
                }
            });
        });
     
        // handle sidebar hover effect        
        handleFixedSidebarHoverEffect();

        // handle the search bar close
        $('.page-sidebar').on('click', '.sidebar-search .remove', function (e) {
            e.preventDefault();
            $('.sidebar-search').removeClass("open");
        });

        // handle the search query submit on enter press
        $('.page-sidebar .sidebar-search').on('keypress', 'input.form-control', function (e) {
            if (e.which === 13) {
                $('.sidebar-search').submit();
                return false; //<---- Add this line
            }
        });

        // handle the search submit(for sidebar search and responsive mode of the header search)
        $('.sidebar-search .submit').on('click', function (e) {
            e.preventDefault();
            if ($('body').hasClass("page-sidebar-closed")) {
                if ($('.sidebar-search').hasClass('open') === false) {
                    if ($('.page-sidebar-fixed').length === 1) {
                        $('.page-sidebar .sidebar-toggler').click(); //trigger sidebar toggle button
                    }
                    $('.sidebar-search').addClass("open");
                } else {
                    $('.sidebar-search').submit();
                }
            } else {
                $('.sidebar-search').submit();
            }
        });

        // handle close on body click
        if ($('.sidebar-search').length !== 0) {
            $('.sidebar-search .input-group').on('click', function(e){
                e.stopPropagation();
            });

            $('body').on('click', function() {
                if ($('.sidebar-search').hasClass('open')) {
                    $('.sidebar-search').removeClass("open");
                }
            });
        }
    };


    // Hanles sidebar toggler
    var handleSidebarToggler = function () {
        var body = $('body');
        if ($.cookie && $.cookie('sidebar_closed') === '1' && Metronic.getViewPort().width >= 992) {
            $('body').addClass('page-sidebar-closed');
            $('.page-sidebar-menu').addClass('page-sidebar-menu-closed');
        }

        // handle sidebar show/hide
        $('.page-sidebar, .page-header').on('click', '.sidebar-toggler', function () {
            var sidebar = $('.page-sidebar');
            var sidebarMenu = $('.page-sidebar-menu');
            $(this).toggleClass('active');
            $('.customerLogoHolder').toggleClass('active');
            $(".sidebar-search", sidebar).removeClass("open");
            var height = $(".page-content-wrapper").height();
            $('.page-sidebar-menu').css('height', (height));
            $('.customer_logo').toggleClass('hiddenInitially');
            if (body.hasClass("page-sidebar-closed")) {
                body.removeClass("page-sidebar-closed");
                sidebarMenu.removeClass("page-sidebar-menu-closed");
                if ($.cookie) {
                    $.cookie('sidebar_closed', '0');
                }
            } else {
                body.addClass("page-sidebar-closed");
                sidebarMenu.addClass("page-sidebar-menu-closed");
                if (body.hasClass("page-sidebar-fixed")) {
                    sidebarMenu.trigger("mouseleave");
                }
                if ($.cookie) {
                    $.cookie('sidebar_closed', '1');
                }
            }

            $(window).trigger('resize');
        });
    };

    // Handles the horizontal menu
    var handleHorizontalMenu = function () {
        //handle tab click
        $('.page-header').on('click', '.hor-menu a[data-toggle="tab"]', function (e) {
            e.preventDefault();
            var nav = $(".hor-menu .nav");
            var activeLink = nav.find('li.current');
            $('li.active', activeLink).removeClass("active");
            $('.selected', activeLink).remove();
            var newLink = $(this).parents('li').last();
            newLink.addClass("current");
            newLink.find("a:first").append('<span class="selected"></span>');
        });

        // handle search box expand/collapse        
        $('.page-header').on('click', '.search-form', function () {
            $(this).addClass("open");
            $(this).find('.form-control').focus();

            $('.page-header .search-form .form-control').on('blur', function () {
                $(this).closest('.search-form').removeClass("open");
                $(this).unbind("blur");
            });
        });

        // handle hor menu search form on enter press
        $('.page-header').on('keypress', '.hor-menu .search-form .form-control', function (e) {
            if (e.which === 13) {
                $(this).closest('.search-form').submit();
                return false;
            }
        });

        // handle header search button click
        $('.page-header').on('mousedown', '.search-form.open .submit', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).closest('.search-form').submit();
        });

        // handle hover dropdown menu for desktop devices only
        $('[data-hover="megamenu-dropdown"]').not('.hover-initialized').each(function() {   
            $(this).dropdownHover(); 
            $(this).addClass('hover-initialized'); 
        });
        
        $(document).on('click', '.mega-menu-dropdown .dropdown-menu', function (e) {
            e.stopPropagation();
        });
    };
   
    return {
        initHeader: function() {
            handleHorizontalMenu(); // handles horizontal menu    
        },

        initSidebar: function() {
            handleSidebarMenu(); // handles main menu
            handleSidebarToggler(); // handles sidebar hide/show
            
        },

        init: function () {            
            //this.initHeader();
            this.initSidebar();
          //  this.initContent();
         //   this.initFooter();
        },
        
        fixContentHeight: function () {
            handleSidebarAndContentHeight();
        },

        initFixedSidebarHoverEffect: function() {
            handleFixedSidebarHoverEffect();
        },

        initFixedSidebar: function() {
            handleFixedSidebar();
        },
           getLayoutCssPath: function () {
            return layoutCssPath;
        }
    };

}();

///#source 1 1 /Scripts/TatvamScript/Layout/TatvamMenu.js
var widgetCreator_CallURL = "../Home/WidgetCreator";
var sessionTimeout_CallURL = "../SessionTimeOut/SessionTimeOut";

$('.sidebar-toggler').click(function () {
    $('.search_input').val('');
    $('div ul li.start').css('display', 'block');
    if ($('.page-sidebar-closed').length) {
        $('.clear_searchinput').show();
    } else {
        $('.clear_searchinput').hide();
    }
});

$('.leftMenuOverlay').unbind('click').bind('click', function (e) {
    $('.sidebar-toggler')[0].click();
});


$('.clear_searchinput').click(function () {
    $('.search_input').val('');
    $('div ul li.start').css('display', 'block');
    $('.input-group').hide();
});


$('.input-group').hide();


$('.search_input').keyup(function () {
    $('ul .sub-menu').css('display', 'block');
    var searchText = $(this).val();
    $('#search_left ul > li').each(function () {
        var currentLiText = $(this).text(),
            showCurrentLi = currentLiText.toLowerCase().indexOf(searchText.toLowerCase()) !== -1;
        $(this).toggle(showCurrentLi);
    });
});


$('div ul li.start').click(function () {
    $(this).find('.sub-menu').slideToggle(300);
});

//* UI Sidebar window Ends Here *//

/* Height 100% for left menu Div */

var setElementHeight = function () {
    var height = $(window).height();
    $('.page-sidebar-menu').css('height', (height));
};

/* Height 100% for left menu Div Ends */

/**
 * Creating Span text
 * @param {} text 
 * @returns {} 
 */
var createTextNode = function (text) {
    var span = document.createElement("span");
    span.className = "title";
    var tx = document.createTextNode(text);
    span.appendChild(tx);
    return span;
};

var createFontAwesomeNode = function (text) {
    var i = document.createElement("i");
    i.className = text;
    return i;
};

var createliNode = function (text, icon, isarrow, id) {
    var nodeli = document.createElement("li");
    nodeli.setAttribute("id", "menu_" + id);
    var a = document.createElement("a");
    if (text === "Home Dashboard" || text === "Executive Summary") {
        a.setAttribute('onclick', 'OnMenuClick(' + id + ',"' + text + '");return false;');
        isarrow = false;
    }
    if (icon !== "") {
        a.appendChild(createFontAwesomeNode(icon));
    }
    a.appendChild(createTextNode(text)); //Append to li
    if (isarrow) {
        var span = document.createElement("span");
        span.className = "arrow";
        a.appendChild(span);
    }
    nodeli.appendChild(a);
    return nodeli;
};


/*Get User Menus*/

function buildleftmenu(models) {
    var rootUl = document.createElement("ul");
    rootUl.className = "page-sidebar-menu page-sidebar-menu-closed";
    rootUl.setAttribute('data-slide-speed', '200');
    /*Adding Menu Icon*/
    var rootNodeLi = document.createElement("li");
    rootNodeLi.className = "sidebar-toggler-wrapper customerLogoHolder";
    rootNodeLi.title = "Menu";
    //Customer Logo div
    var customerLogoDiv = document.createElement("div");
    customerLogoDiv.className = "customer_logo hiddenInitially";
    var customerLogoImage = document.createElement("img");
    customerLogoImage.src = '../content/Images/Customer/' + customerLogo;
    customerLogoImage.className = "cust_logo img-responsive center-block";
    customerLogoDiv.appendChild(customerLogoImage);
    rootNodeLi.appendChild(customerLogoDiv);
    //Sidebar toggler
    var div = document.createElement("div");
    div.className = "sidebar-toggler";
    rootNodeLi.appendChild(div);
    rootUl.appendChild(rootNodeLi); //Append to root ul

    BuildRecursiveDynamicMenu(models, rootUl);
    $("#leftmenu").html("").append(rootUl);
}

function BuildRecursiveDynamicMenu(models, rootUl) {
    $.each(models, function (i, item) {
        //if (item.UserReport.IsMenu) {
        var childNodeUl, childNodeLi;
        var a;
        if (item.ParentId === 0) {
            childNodeLi = createliNode(item.ReportCategory, item.Icon, true, item.ReportCategoryId);
            if (item.SubReportCollection.length > 0) {
                childNodeUl = document.createElement("ul");
                childNodeUl.className = "sub-menu SkrollThis";
                BuildRecursiveDynamicMenu(item.SubReportCollection, childNodeUl);
                childNodeLi.appendChild(childNodeUl); //Append to root ul
            }
            rootUl.appendChild(childNodeLi);
        } else if (item.ParentId !== 0 && item.SubReportCollection.length > 0) {
            childNodeLi = createliNode(item.ReportCategory, item.Icon, true, item.ReportCategoryId);
            if (item.SubReportCollection.length > 0) {
                childNodeUl = document.createElement("ul");
                childNodeUl.className = "sub-menu SkrollThis page-sidebar-fixed";
                BuildRecursiveDynamicMenu(item.SubReportCollection, childNodeUl);
                childNodeLi.appendChild(childNodeUl); //Append to root ul
            }
            rootUl.appendChild(childNodeLi);
        } else {
            var rootNodeLi = document.createElement("li");
            rootNodeLi.setAttribute("id", "menu_" + item.ReportCategoryId);
            a = document.createElement("a");
            a.setAttribute('onclick', 'OnMenuClick(' + item.ReportCategoryId + ',"' + item.ReportCategory + '");return false;');
            a.appendChild(createTextNode(item.ReportCategory)); //Append to li
            rootNodeLi.appendChild(a);
            rootUl.appendChild(rootNodeLi); //Append to root ul
        }

        if (item.ReportCategory == "Home Dashboard") {
            childNodeUl = document.createElement("ul");
            childNodeLi.className = "active";
            childNodeLi.appendChild(childNodeUl);

        }
        //}
    });
}


function OnMenuClick(reportCategoryId, reportName) {
    showLoadingCursor();
    var sidebar = $('.page-sidebar');
    var body = $('body');
    var sidebarMenu = $('.page-sidebar-menu');
    $(".sidebar-search", sidebar).removeClass("open");
    var height = $(".page-content-wrapper").height();
    $('.page-sidebar-menu').css('height', (height));
    body.addClass("page-sidebar-closed");
    sidebarMenu.addClass("page-sidebar-menu-closed");
    if (body.hasClass("page-sidebar-fixed")) {
        sidebarMenu.trigger("mouseleave");
    }
    if ($.cookie) {
        $.cookie('sidebar_closed', '1');
    }
    //$('.sidebar-toggler').click();
    document.title = reportName;
    $('#hdn_reportid_page').val(reportCategoryId);
    sessionStorage.setItem("ReportId", reportCategoryId);     //------value stored in the sessionstorage   
    sessionStorage.setItem("reportName", reportName);     //------value stored in the sessionstorage   
    if ($("#paintpage").length <= 0) {
        window.location.href = "../Home/Home";
        return false;
    }
    $.ajax({
        type: "POST",
        url: widgetCreator_CallURL,
        data: { ReportCategoryId: reportCategoryId },
        success: function (result) {
            if (result.indexOf("<title>SessionTimeOut</title>") > -1) {
                window.location.href = sessionTimeout_CallURL;
            }
            else {
                $("#paintpage").empty();
                $("#paintpage").html(result);
                $("li").removeClass("active");
                $("#menu_" + reportCategoryId).addClass("active");
                if ($("#menu_" + reportCategoryId).parent()[0].classList.contains("sub-menu")) {
                    $("#menu_" + reportCategoryId).parent().parent().addClass("active");
                }
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });


    if (!$('.customer_logo').hasClass('hiddenInitially')) {
        $('.customer_logo').addClass('hiddenInitially');
    }

    if ($('.sidebar-toggler').hasClass('active')) {
        $('.sidebar-toggler').removeClass('active');
    }

    return false;
}


///#source 1 1 /Scripts/TatvamScript/Common/TatvamCommon.js
var myColors = ['#3f51b5', '#03a9f4', '#ffca08', '#ff710f', '#a0a700', '#007bc3', '#a7008f', '#309b46', '#8ebc00', '#ff7663', '#10c4b2', '#ff4350', '#ff4350', '#99d101', '#008fd3', '#004586', '#006bff', '#c4f565', '#ff420e', '#ffd320', '#579d1c', '#7e0021', '#83caff', '#314004', '#aecf00', '#4b1f6f', '#ff950e', '#c5000b', '#0084d1'];

var shapes = ['circle', 'cross', 'triangle-up', 'triangle-down', 'diamond', 'square', 'hexagram', 'x', 'star-triangle-up', 'star-triangle-down', 'x-open', 'circle-open', 'triangle-up-open', 'triangle-down-open', 'diamond-open', 'square-open', 'hexagram-open', 'star-triangle-up-open', 'star-triangle-down-open'];


function TatvamAjaxCalls(method, url, data, callBack, params) {
    if (method === "POST") {
        data = JSON.stringify(data);
    } else if (method === "GET") {
        data = data;
    }

    $.ajax({
        type: method,
        url: url,
        data: data,
        contentType: "application/json",
        async: false,
        success: function (result) {
            if (typeof callBack === "function") {
                params.response = result;
                callBack(params);
            }
        },
        error: function (xhr, status, p3, p4) {
            if (xhr.status === 401) {
                TatvamAlert(xhr.statusText + " Access is denied due to invalid credentials.", "Error");
            } else {
                var error = JSON.parse(xhr.responseText)
                TatvamAlert(error.ErrorMessage, "Error");
            }
        }
    });
}

function TatvamAjaxCallWithReturn(method, url, data) {
    if (method === "POST") {
        data = JSON.stringify(data);
    } else if (method === "GET") {
        data = data;
    }

    return $.ajax({
        type: method,
        url: url,
        data: data,
        contentType: "application/json",
        async: false,
        success: function (result) {
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function toDate(d) {
    return new Date(d);
}

function getBool(val) {
    return !!JSON.parse(String(val).toLowerCase());
}

function trimChar(string, charToRemove) {
    while (string.charAt(0) === charToRemove) {
        string = string.substring(1);
    }

    while (string.charAt(string.length - 1) === charToRemove) {
        string = string.substring(0, string.length - 1);
    }

    return string;
}

function GetYaxisMaxValue(value) {

    var dtick;
    var yMax;
    var max = value / 1000;

    if (max > 10) {
        yMax = Math.ceil(value / 1000) * 1000;
        dtick = 1000;
        max = value / 500;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 500) * 500;
            dtick = 500;
        }
        max = value / 200;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 200) * 200;
            dtick = 200;
        }
    }
    else if (max <= 10 && max >= 1) {
        yMax = Math.ceil(value / 1000) * 1000;
        dtick = 1000;
        max = value / 500;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 500) * 500;
            dtick = 500;
        }
        max = value / 200;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 200) * 200;
            dtick = 200;
        }
    } else {
        max = value / 100;
        yMax = Math.ceil(value / 100) * 100;
        dtick = 100;
        if (max <= 10 && max >= 1) {

            max = value / 50;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 50) * 50;
                dtick = 50;
            }
            max = value / 25;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 25) * 25;
                dtick = 25;
            }
            max = value / 20;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 20) * 20;
                dtick = 20;
            }
            max = value / 15;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 15) * 15;
                dtick = 15;
            }
        } else {
            max = value / 10;
            yMax = Math.ceil(value / 10) * 10;
            dtick = 10;
            if (max <= 10 && max >= 1) {
                max = value / 5;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 5) * 5;
                    dtick = 5;
                }
                max = value / 2;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 2) * 2;
                    dtick = 2;
                }
                max = value / 1;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 1) * 1;
                    dtick = 1;
                }
            } else if (max <= 10 && max <= 1) {
                max = value / 5;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 5) * 5;
                    dtick = 5;
                }
                max = value / 2;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 2) * 2;
                    dtick = 2;
                }
                max = value / 1;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 1) * 1;
                    dtick = 1;
                }
            }
        }
    }
   

    return [{ max: yMax, dtick: dtick }];
}


/*Wait Cursor Script Starts*/
var overlay = $('<div id="overlay" class="modal-backdrop fade in"></div>');

function showLoadingCursor() {
    $("body").css("cursor", "none");
    //overlay.show();
    $('<div class="modal-backdrop fade in"></div>').appendTo('body');
    $('.popup').show();
}

function hideLoadingCursor() {
    $('.popup').hide();
    $('.modal-backdrop').remove();
    $("body").css("cursor", "auto");
}

/*Wait Cursor Script Ends*/


function GetXaxisMaxValue() {


}

function ConvertTatvamDataFormat(value, type) {
    var format = d3.format(type);
    return format(value);

}

/*common handler which acts as interceptor to all ajax requests.
currently, this handler is used to handle session time out related scenarios with ajax requests for data.
*/
$(document).ajaxSuccess(function (event, request, settings) {
    //to-do: need to check for solution other than considering 203 status code.    
    if (request.status === 203) {
        window.location.href = "../SessionTimeOut/SessionTimeOut";
    }
});

//Method to add class to element based on ID.
function AddClassToElementById(id, className) {

    if (!(className && id))
        return;

    $("#" + id).addClass(className);
}



//common method to add a new object (with one property) inside a base object.
function setObjProp(baseObj, baseObjPropName, newPropName, newPropValue) {
    //checks whether the base object contains the expected baseObjProp, if not then adds the baseObjPropName along with new property name value.
    if (baseObj[baseObjPropName] === undefined) {        
        baseObj[baseObjPropName] = {};
    }
    setProp(baseObj[baseObjPropName], newPropName, newPropValue);
}

//common method to add a new property and value
function setProp(obj, propName, propValue) {
    obj[propName] = propValue;
}

//To-Do: Need to consider the default parameters even when call is made without most of the properties.
// Common method for displaying the dialog popup 
function TatvamGenericConfirmDialog(dialogProperties) {

    //Bind the message for the dialog
    $(dialogProperties.dialogID).html(dialogProperties.message);

    var buttonProps = {};

    //Dynamically adding the buttons and it respective call back methods as per configuration.
    for (var index = 0; index < dialogProperties.buttonFunctions.length; index++) {
        var currentButtonFunction = dialogProperties.buttonFunctions[index];
        setProp(buttonProps, currentButtonFunction.name, currentButtonFunction.func);
    }

    //Binding the properties to the actual dialog box.
    $(dialogProperties.dialogID).dialog({
        resizable: dialogProperties.resizable,
        modal: dialogProperties.modal,
        title: dialogProperties.dialogTitle,
        height: dialogProperties.dialogHeight,
        width: dialogProperties.dialogWidth,
        buttons: buttonProps
    });
}

//Method to populate dropdown options
function PopulateDdlOptions(obj) {
    var optionsLength = obj.list.length;
    if (obj.list && optionsLength > 0) {

        for (var index = 0; index < optionsLength; index++) {
            var curOption = obj.list[index];

            if (curOption.Selected) {
                obj.controlObj.append('<option value="' +
                    curOption[obj.valueSelector] +
                    '"  selected="selected">' +
                    curOption[obj.textSelector] +
                    '</option>');
            }
            else {
                obj.controlObj.append('<option value="' +
                   curOption[obj.valueSelector] +
                   '">' +
                   curOption[obj.textSelector] +
                   '</option>');
            }
        }
    }
}


function TatvamRatingColor(rating) {
    if (rating < 1) {
        return '#4286f4';
    }
    else if (rating < 1.5) {
        return '#f34443';
    }
    else if (rating >= 1.5 && rating < 2.5) {
        return '#e66e0b';
    }
    else if (rating >= 2.5 && rating < 3.5) {
        return '#f3b81a';
    }
    else if (rating >= 3.5 && rating < 4.5) {
        return '#2dac07';
    }
    else if (rating >= 4.5) {
        return '#196004';
    }
}



//on success reload the page to get accurate data based on the periodicity
function tatvamDocumentReload() {
    document.location.reload(true);
}
///#source 1 1 /Scripts/TatvamScript/Common/TatvamPopup.js
var Tatvam = Tatvam || {};

function SetBootboxTitle(title) {
    if (!title) {
        title = "Tatvam";
    } else {
        title = title;
    }
    return title;
}

Tatvam.messages = Tatvam.messages || (function() {
    var showMessage = {
        'Info': function(message, callback) {
            bootbox.dialog({
                title: "Tatvam",
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                buttons: {
                    main: {
                        label: 'Ok',
                        className: 'k-button pull-right',
                        callback: function(result) {
                            if (result) {
                                if (callback) {
                                    callback(true);
                                }
                            } else {
                                if (callback) {
                                    callback(false);
                                }
                            }
                        }
                    }
                }
            });
        },
        'Dialog': function(message, callback, title, ctrlName, okButtonName, cancalButtonName) {
            bootbox.confirm({
                title: SetBootboxTitle(title),
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                buttons: {
                    'cancel': {
                        label: ((cancalButtonName !== undefined && cancalButtonName !== "" && cancalButtonName !== null) ? cancalButtonName : 'Cancel'),
                        className: 'k-button pull-right'
                    },
                    'confirm': {
                        label: ((okButtonName !== undefined && okButtonName !== "" && okButtonName !== null) ? okButtonName : 'Ok'),
                        className: 'k-button btn-yes'
                    }
                },
                callback: function(result) {
                    if (result) {
                        if (callback) {
                            callback(true);
                        }
                    } else {
                        if (callback) {
                            callback(false);
                        }
                    }
                    if (ctrlName !== undefined && ctrlName !== "" && ctrlName !== null) {
                        $(ctrlName).focus();
                    }
                }
            });
        },
        'DialogWithoutCancel': function(message, callback, title, ctrlName) {
            bootbox.confirm({
                title: SetBootboxTitle(title),
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                buttons: {
                    'cancel': {
                        label: 'Cancel',
                        className: 'HideDialogCancelButton'
                    },
                    'confirm': {
                        label: 'Ok',
                        className: 'button ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only pull-right'
                    }
                },
                callback: function(result) {
                    if (result) {
                        if (callback) {
                            callback(true);
                        }
                    } else {
                        if (callback) {
                            callback(false);
                        }
                    }
                    if (ctrlName !== undefined && ctrlName !== "" && ctrlName !== null) {
                        $(ctrlName).focus();
                    }
                }
            });
        },
        'Error': function(screenTitle, message, ctrlName) {
            bootbox.alert({
                title: screenTitle,
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                callback: function() {
                    if (ctrlName !== undefined && ctrlName !== "" && ctrlName !== null) {
                        $(ctrlName).focus();
                    }
                }
            });
        }
    };

    return {
        showInfo: showMessage['Info'],
        showConfirm: showMessage['Dialog'],
        showError: showMessage['Error'],
        showConfirmWithoutCancel: showMessage['DialogWithoutCancel']
    };
}(this));

///#source 1 1 /Scripts/TatvamScript/Layout/TatvamHeader.js


var LogOffWindowLocationURL = "../Account/LogOff";
var UnreadMessageCountCallURL = "../TatvamNotification/TatvamNotificationMessageReadCount";
var AccountChangeCallURL = "../AccountChange/ChangeCurrentCustomerAccount";


// Click Drop-down-notification Starts Here 27/03/2015 //  		  
$('.dropdown-notification').click(function() {
    $(this).find('.dropdown-menu').css('display', 'block');
    $('.dropdown-admin .dropdown-menu').hide("slow");
});

$('.dropdown-admin').click(function() {
    $(this).find('.dropdown-menu').css('display', 'block');
    $('.dropdown-notification .dropdown-menu').hide("slow");
});

$('.page-container').click(function() {
    $('.dropdown-menu').css('display', 'none');
});
// Click Drop-down-notification Ends Here 27/03/2015 //


$(document).mouseup(function(e) {
    $('.dropdown-notification .dropdown-menu').hide();
    $('.dropdown-admin .dropdown-menu').hide();
});


function Logout() {
    bootbox.confirm({
        message: "Are you sure. You want to log out?",
        title: "Confirmation",
        size: "small",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                window.location = LogOffWindowLocationURL;
            } else {
                $(this).modal('hide');
            }
        }
    });
}

$.ajax(
{
    url: UnreadMessageCountCallURL,
    type: "Get",
    success: function (Result) {
        if (Result > 0) {
            $("#spanid").text(Result);
        }
        else {
            $("#spanid").attr("style", "visibility:hidden");
        }
    }
});


function ChangeCurrentCustomerAccount(newlySelectedCustomercode) {
    bootbox.confirm({
        size: "small",
        title: "Confirmation",
        message: "Are you sure, you want to change the property?",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                $(this).modal('hide');
                ChangeCurrentCustomerAccount_CallServer(newlySelectedCustomercode);
            }else{
                $(this).modal('hide');
        }
        }
    })
}


function ChangeCurrentCustomerAccount_CallServer(newlySelectedCustomercode) {
    $.ajax({
        type: "POST",
        url: AccountChangeCallURL,
        data: { inpNewCustomerCode: newlySelectedCustomercode },
        success: function(searchResults) {
            sessionStorage.setItem("ReportId", 1);
            sessionStorage.setItem("reportName", 'Dashboard');
            location.reload(true);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}
///#source 1 1 /Scripts/TatvamScript/Layout/TatvamFooter.js
var footerConstants = {
    url: {
        getBuildDetail: '../Data/BuildInfo'
    },
    elementIDConstant: {
        versionID: "#spnVersion",
        buildID: "#spnBuild",
        buildDate : "#spnBuildDate"
    },
};

$(function () {
    GetBuildDetails(BuildFooter);
});

//set build details in footer
function BuildFooter(buildInfo) {
    if (buildInfo) {
        $(footerConstants.elementIDConstant.versionID).text(buildInfo.Version);
        $(footerConstants.elementIDConstant.buildID).text(buildInfo.Build);
        $(footerConstants.elementIDConstant.buildDate).text(buildInfo.BuildDate);
    }
}

//get build details
function GetBuildDetails(callback) {
    $.ajax({
        url: BUILDINFO_URL,
        async: true,
        success: function (data) {
            callback(data);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}
///#source 1 1 /Scripts/TatvamScript/Chart/Emoticon.js
function CreateEmoticon(reportName, score, reportID) {
    $('#value_' + reportID).append(score);
    var scoreclass = $("#smile_" + reportID).find('.' + Math.round(parseFloat(score)));
    scoreclass.css("opacity", "1");
    $('#value_' + reportID).parent().css("opacity", "1");
    $('#smile_' + reportID).css('display', 'block');
}

function GetEmoticonChartData(reportId) {
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {        
        var reportName = data.Report.ReportCategory.replace(/ /g, '');
        if(data.Result === null){
            $("#smile_" + reportId).css('display', 'block');
            $("#smile_" + reportId).empty();
            $("#smile_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if(data.Result.length === 0){
            $("#smile_" + reportId).css('display', 'block');
            $("#smile_" + reportId).empty();
            $("#smile_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if ((typeof (data.Result.toFixed(2)) === "undefined") || data.Result.toFixed(2) === "0.00" || data.Result === 0)
        {
            $("#smile_" + reportId).css('display', 'block');
            $("#smile_" + reportId).empty();
            $("#smile_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else {
            $("#value_" + reportId).empty();            
            CreateEmoticon(reportName, data.Result.toFixed(2), reportId);
        }
        $("#chartloader_" + reportId).css('display', 'none');
    })
        .fail(function () { $('#smile').css('display', 'block'); $("#smile").empty(); $("#smile").append("Something went wrong."); })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}
///#source 1 1 /Scripts/TatvamScript/Chart/UserRating.js
function CreateUserRating(score, reportID) {
    var userRatingImageBasePath = "../content/images/UserRating/";
    if (typeof (score) === "undefined")
        score = 0;
    var imagename = "";

    if (score <= 0) {
        imagename = "zero-stars_large.png";
    } else if (score > 0 && score <= 0.5) {
        imagename = "half-stars_large.png";
    } else if (score > 0.5 && score <= 1) {
        imagename = "one-stars_large.png";
    } else if (score > 1 && score <= 1.5) {
        imagename = "one-half-stars_large.png";
    } else if (score > 1.5 && score <= 2) {
        imagename = "two-stars_large.png";
    } else if (score > 2 && score <= 2.5) {
        imagename = "two-half-stars_large.png";
    } else if (score > 2.5 && score <= 3) {
        imagename = "three-stars_large.png";
    } else if (score > 3 && score <= 3.5) {
        imagename = "three-half-stars_large.png";
    } else if (score > 3.5 && score <= 4) {
        imagename = "four-stars_large.png";
    } else if (score > 4 && score <= 4.5) {
        imagename = "four-half-stars_large.png";
    } else if (score > 4.5 && score <= 5) {
        imagename = "five-stars_large.png";
    }


    var ratingimage = document.createElement("img");
    ratingimage.src = userRatingImageBasePath + imagename;
    $('#value_' + reportID).append(score.toPrecision(3));    
    $("#reviewimage_" + reportID).append(ratingimage);
    $('#userrating_' + reportID).css('display', 'block');
}


function GetUserRatingData(reportId) {  
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        if(data.Result === null){
            $("#userrating_" + reportId).css('display', 'block');
            $("#userrating_" + reportId).empty();
            $("#userrating_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if(data.Result.length === 0){
            $("#userrating_" + reportId).css('display', 'block');
            $("#userrating_" + reportId).empty();
            $("#userrating_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if ((typeof (data.Result.toFixed(2)) === "undefined") || data.Result.toFixed(2) === "0.00")
        {
            $("#userrating_" + reportId).css('display', 'block');
            $("#userrating_" + reportId).empty();
            $("#userrating_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else {
            $("#value_" + reportId).empty();
            $("#reviewimage_" + reportId).empty();
            CreateUserRating(data.Result, reportId);
        }
        $("#chartloader_" + reportId).css('display', 'none');       
    })
        .fail(function() {   $("#userrating_" + reportId).css('display', 'block');  $("#userrating_" + reportId).empty();  $("#userrating_" + reportId).append("Something went wrong."); })
        .always(function() { $("#chartloader_" + reportId).css('display', 'none'); });
}

///#source 1 1 /Scripts/TatvamScript/Chart/ReviewCount.js
function CreateReviewCount(divId,iconId,  value, reportCategory, icon) {
    $("#" + divId).attr("id", reportCategory.replace(/ /g, ''));    
    $("#" + reportCategory.replace(/ /g, '')).append(value);
    $("#" + iconId).attr("class", icon);
}


function GetReviewCountData(reportId) {
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $("#review_count_" + reportId).css('display', 'block');
        if(data.Result === null){
            $("#review_count_" + reportId).empty();
            $("#review_count_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if(data.Result === 0){
            
            $("#review_count_" + reportId).empty();
            $("#review_count_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        } else{
            $("#review_icon_" + reportId).empty();
            $("#review_" + reportId).empty();
            CreateReviewCount("review_" + reportId, "review_icon_" + reportId, data.Result, data.Report.ReportCategory, data.Report.Icon);
        }
        $('#chartloader_' + reportId).css('display', 'none');
    }).fail(function() {  
        $("#count").empty();  
        $("#review_" + reportId).empty();  
        $("#review_" + reportId).append("Something went wrong."); 
    }).always(function() { 
        $("#chartloader_" + reportId).css('display', 'none');
    });
}

///#source 1 1 /Scripts/TatvamScript/Chart/FacebookRecommendations.js
function GetFacebookRecommendationsData(reportId){
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $("#facebookRecommendations").css('display', 'block');
        if(data.Result == null){
            $("#facebookRecommendations").empty();
            $("#facebookRecommendations").append("<div class=\'nodata\'>No Data Available.</div>");
        }  else if(data.Result.Recommend === 0 && data.Result.DoesntRecommend === 0){
            $("#facebookRecommendations").empty();
            $("#facebookRecommendations").append("<div class=\'nodata\'>No Data Available.</div>");
        } else {
            if (data.Result.Recommend === undefined) {
                $("#facebookRecommendations").empty();
                $("#facebookRecommendations").append("<div class=\'nodata\'>No Data Available.</div>");
            } else {
                $("#recommendationCount").text(data.Result.Recommend);
                $("#notrecommendationCount").text(data.Result.DoesntRecommend);            }
        }
    })
        .fail(function() { 
            $("#facebookRecommendations").css('display', 'block');  
            $("#facebookRecommendations").empty();  
            $("#facebookRecommendations").append("Something went wrong.");  
        })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}
///#source 1 1 /Scripts/TatvamScript/Chart/ReviewList.js
var GetReviewList_CallURL = "../Review/ReviewList";
var GetClassifierList_CallURL = "../Review/GetClassifierListbyFactId";

/*
currently this is made as global variable
TO-DO: Need to add appropriate fix to the same.
*/
var selectedFilters = null;
var availableReivew = "";


function onMoreLinkClick() {
    // Configure/customize these variables. Show more/less text
    var showChar = 300;  // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "Read More";
    var lesstext = "Read Less";


    $(".morelink").click(function () {
        if ($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
}

function CallReviewListonWordCloudClick(ReportId, selectedText, selectedValue, searchbyText, searchbyValue) {    
    var mainClassifier = $.trim($("#wordCloudWithClickSelectedVal").text());
    var subClassifier = $.trim($("#StackedBarChartSelectedSubClassifier").text());
    var array = GetSearchFilters();
    //var inputFilters = {
    //    "SearchbyText": searchbyText,
    //    "SearchbyValue": searchbyValue,
    //    "OperatorName": "Equal To",
    //    "OperatorValue": "in",
    //    "SelectedText": selectedText,
    //    "SelectedValue": selectedValue,
    //    "ConditionName": "or",
    //    "ConditionValue": "or"
    //}

    var inputFilters = {
        "Condition": "AND",
        "ParentType": "CLASSIFIER",
        "KeyType": "CLASSIFIER",
        ParentValues: [mainClassifier],
        KeyWordValues: selectedText
    };
    array.unshift(inputFilters);
    var displayValue = "";

    var selectedRating = "0";
    if ($(".reviewListFilterSmile li.selectedli")[0] !== undefined) {
        selectedRating = $(".reviewListFilterSmile li.selectedli")[0].className.split(' ')[0];
    }
    var  rating = 0;
    if (selectedRating !== "0") {
        rating = selectedRating;
    }

    $.ajax({
        type: 'POST',
        async: false,
        url: GetReviewList_CallURL,
        data: { reportId: ReportId, TatvamReportFilterTo: JSON.stringify(array), rating: rating },
        success: function (result) {
            var reportCategoryIdIndex = result.indexOf("data-id");
            if (reportCategoryIdIndex !== -1) {
                var reportCategoryId = result.substr(reportCategoryIdIndex + 9).split('"')[0];
                $("#report_" + reportCategoryId).html(result);                
                $("#ReviewListSelectedMani").empty();
                $("#ReviewListSelectedMani").append(mainClassifier);

                $("#ReviewListSelectedSub").empty();
                $("#ReviewListSelectedSub").append(subClassifier);


                selectedFilters = inputFilters;
                if (selectedRating != "") {
                    $(".reviewListFilterSmile li").removeClass("selectedli");
                    var scoreclass = $('.' + Math.round(parseFloat(selectedRating)))
                    scoreclass.addClass("selectedli");
                }
                $("ul.bgheight").css({ display: "block" })
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error, "Error");
        }
    });
}

//method to get the search filters.
function GetSearchFilters() {
    var searchFilters = [];
    $('.searchpanel').each(function () {
        var searchbyText = $(this).find("#ddl_searchby option:selected").text();
        var searchbyValue = $(this).find("#ddl_searchby option:selected").val();

        var operatorName = $(this).find("#ddl_operator option:selected").text();
        var operatorValue = $(this).find("#ddl_operator option:selected").val();

        var valueId = $(this).find("[id^='ddl_value']").attr('id');

        var SelectedText = [];
        var SelectedValue = [];

        $(this).find("#" + valueId + " option:selected").each(function () {
            SelectedText.push({ Name: this.text });
            SelectedValue.push({ Name: this.value });
        });

        if (SelectedText.length === 0) {
            var val = $(this).find("#" + valueId).val();
            if (val) {
                SelectedValue = [];
                SelectedText.push({ Name: '%' + $(this).find("#" + valueId).val() + '%' });
                SelectedValue.push({ Name: '%' + $(this).find("#" + valueId).val() + '%' });
            }
        }


        if (SelectedValue.length > 0) {
            searchFilters.push({
                "SearchbyText": searchbyText,
                "SearchbyValue": searchbyValue,
                "OperatorName": operatorName,
                "OperatorValue": operatorValue,
                "SelectedText": SelectedText,
                "SelectedValue": SelectedValue,
                "ConditionName": "and",
                "ConditionValue": "and"
            });
        }
    });

    return searchFilters;
}

//method to obtain configured review details as JSON.
function GetReviewDetailsConfiguration(reportdetails) {
    if (reportdetails && reportdetails.length > 0) {
        return JSON.parse(reportdetails);
    }
}


function updateWidgetHeight(ReportCategoryId) {
    var gridster = $('.gridster ul#widgets').gridster().data('gridster');
    var widgetObj = gridster.$widgets.closest("#widget_" + ReportCategoryId);
    var height = $("#" + ReportCategoryId + " table").height();
    var sizey = Math.round(height / 100);
    var margin = sizey * 5
    sizey = (sizey == 1) ? sizey + 1 : sizey;
    gridster.resize_widget(widgetObj, 10, sizey, function (obj1, obj2) { });
}


// Tatvam 2.8 Implementation

function onRatingSmileClick(val, reportId) {
    $(".reviewListFilterSmile li").removeClass("selectedli");
    var scoreclass = $('.' + val);
    scoreclass.addClass("selectedli");

    $.ajax({
        type: "POST",
        url: "../Data/GetReviewData",
        data: { reportId: reportId, tatvamReportFilterTo: JSON.stringify([model[0]]), rating: val },
        async: false,
        success: function (data) {
            $("#feedback_" + reportId).empty();
            bindReviewData(data.Result, reportId);
        },
        error: function (xhr, status, p3, p4) {

        }
    });
}

function bindReviewData(data, reportId) {
    if (data.length === 0) {
        $("#feedback_@Model.ReportId").append("<div class=\'nodata\'>No Data Available.</div>");
    }
    $("#reviewTemplate").tmpl(data, {
        dataArrayIndex: function (item) {
            return $.inArray(item, data);
        }
    }).appendTo("#feedback_" + reportId);

    if (loadAllReviews) {
        setTimeout(function () {
            $(".materialTabContent").css({ "height": "95%", "overflow-y": "auto" });
            var height = $(".materialTabContent").height();
            $('#widgets').css({ "height": height + "px" });
            $('.page-footer-fixed').css({ "top": height + 500 + "px" });
        }, 2000);
    }
    if (!reviewsExpandAll) {
        onMoreLinkClick();
    } else {
        $("#feedback_" + reportId).find(".moreellipses").remove();
        $("#feedback_" + reportId).find(".morelink").remove();
        $("#feedback_" + reportId).find(".morecontent span").css({ display: "inline" });
    }
    if (reportId === 1075) {
        var gridster = $('.gridster ul#widgets').gridster().data('gridster');
        var widgetObj = gridster.$widgets.closest("#widget_" + reportId);
        var reviewListContainerHeight = $("#feedback_" + reportId).height() + 1000;
        var sizex = widgetObj.attr("data-sizex");
        if (sizex !== undefined) {
            var sizey = Math.ceil(reviewListContainerHeight / 128);
            sizey = (sizey == 1) ? sizey + 2 : sizey + 1;
            gridster.resize_widget(widgetObj, sizex, sizey, function (obj1, obj2) { });
        }
    }
    hideLoadingCursor();
}

/*******Pagination for review reports implementation - start ********/

function PaginationReviewList(reportID, skip) {
    $.getJSON("../Data/GetReviewData", { reportId: reportID, tatvamReportFilterTo: JSON.stringify([reviewModel[0]]), isExecutiveSummary: false, skip: skip }, function (data) {
        bindReviewData(data.Result, reportID);
    });
}


//binding scroll event handler to allreviews tab
function BindScrollEventHandler(reportID) {
    var element = $('#feedback_' + reportID);
    element.scroll(function () {
        if (element.scrollTop() + element.height() > this.scrollHeight - 100) {
        }
    });
    var element = $('#feedback_' + reportID);
    //var element = $('.materialTabContent');
    element.scrollTop(0);
    //binding scroll event handler to allreviews tab
    element.unbind("scroll").on("scroll", function (evt) {
        if (element.scrollTop() + element.height() > this.scrollHeight - 100) {
            showLoadingCursor();
            var skip = $(".materialCard").length;
            PaginationReviewList(reportID, skip);
        }
    });
}
/*******Pagination for review reports implementation - end ********/

function GetDate(jsonDate) {
    var tempData = jsonDate.split('-');
    var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var monthShort = month[tempData[1] - 1];
    return tempData[2] + "-" + monthShort + "-" + tempData[0];
}


function GetReviewText(startIndex, endIndex, comment) {
    var res = comment.substr(startIndex, endIndex);
    return res;
}


function GetReviewData(reportId , rating) {
    $.getJSON("../Data/GetReviewData", { reportId: reportId, tatvamReportFilterTo: JSON.stringify([reviewModel[0]]), isExecutiveSummary: false, rating: rating }, function (data) {
        $("#feedback_" + reportId).empty();
        enableRatingFilter = data.Report.ReportDefinition.reviewdisplay.enableRatingFilter;
        if(enableRatingFilter){
            $(".selectedText").css('display', 'block');
        }
        if(data.Result == null){
            if(data.Message !== "" ){
                $("#feedback_" + reportId).empty();
                $("#feedback_" + reportId).append("<div class=\'nodata\'>" + data.Message + "</div>");
            }
        }
        else if(data.Result.length === 0 ){
            $("#feedback_" + reportId).empty();
            $("#feedback_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        } else {
            reviewsExpandAll = data.Report.ReportDefinition.reviewdisplay.reviewsExpandAll;
            onScrollLoad = data.Report.ReportDefinition.reviewdisplay.onScrollLoad;
            loadAllReviews = data.Report.ReportDefinition.reviewdisplay.loadAllReviewsWarning;


            if(data.Report.ReportDefinition.reviewdisplay.loadAllReviewsWarning) {
                bootbox.confirm({
                    message: "The All Reviews is meant to display all the reviews for the currently selected time range. This report works best when you have a short date range selected. If you have a large date range selected this report may have extremely long load times and may fail to load at all. Do you wish to proceed?",
                    title: "Warning",
                    size: "small",
                    buttons: {
                        confirm: {
                            label: 'Proceed',
                            className: 'btn-primary'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-default'
                        }
                    },
                    callback: function (result) {
                        $(this).modal('hide');
                        if (result) {
                            bindReviewData(data.Result, reportId);
                        } else {
                            sessionStorage.setItem("ReportId", 1);
                            sessionStorage.setItem("reportName", 'Dashboard');
                            location.reload(true);
                        }
                    }
                });
            } else {
                bindReviewData(data.Result, reportId);
            }

            if(onScrollLoad){
                BindScrollEventHandler(reportId);
            }
        }

    })
        .fail(function() { 
            $("#feedback_" + reportId).append("Something went wrong.");  
        })
        .always(function() { 
            $('#chartloader_' + reportId).css('display', 'none'); 
        });   
}
///#source 1 1 /Scripts/TatvamScript/Chart/TatvamCustomPlotly.js
function ChartRenderer(data) {
    var reportData, reportDetails, chartData, reportCategory
    reportDetails = data.Report;
    reportCategory = reportDetails.ReportCategory;
    var divname = "plotly_chart_" + reportDetails.ReportCategoryId;

    if (data.Result === null) {
        $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
        $('#' + divname).append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }

    if (data.Result.length === 0) {
        $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
        $('#' + divname).append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }
    var layout = jQuery.parseJSON(data.Report.ReportDefinition.layout); //reportDetails.layout;   

    var height = $('#report_' + reportDetails.ReportCategoryId).height() - 10;
    var width = $('#report_' + reportDetails.ReportCategoryId).width();
    if (height) {
        layout.height = height;
    } else {
        layout.height = 355;
    }
    layout.width = width;
    var maxValue = 0;
    data.Result.forEach(function (trace) {
        trace.y.forEach(function (yValue) {
            if (maxValue < yValue)
                maxValue = yValue;
        });    
        trace.text = trace.y.map(function (v, i) {
            var convertedValue = v;
            var hoverValue = v;
            if (trace.yaxis === 'y1') {
                convertedValue = ConvertTatvamDataFormat(v, layout.yaxis.tickformat);
            }
            else if (trace.yaxis === 'y2') {
                convertedValue = ConvertTatvamDataFormat(v, layout.yaxis2.tickformat);
            }

            if (v !== 0)
                hoverValue = trace.name + "<br>(" + trace.x[i] + "," + convertedValue + ")";
            return hoverValue || null;
        });
        trace.hoverinfo = 'text';
    });

    var tickvals = [];
    var ticktext = [];
    /*Check tickvals exist in array*/
    data.Result[0].x.forEach(function (XAxisValues) {
        if (tickvals.indexOf(XAxisValues) === -1) {
            tickvals.push(XAxisValues);
            if (XAxisValues.length > 12)
                ticktext.push(XAxisValues.substr(0, 12) + '...');
            else
                ticktext.push(XAxisValues);
        }
    });

    var value = GetYaxisMaxValue(maxValue);   


    var y0Max = value[0].max;
    var dtick = value[0].dtick;

    if (layout.yaxis.range == undefined) {
        layout.yaxis.range = [0, y0Max];
        layout.yaxis.dtick = dtick;
    }
    layout.xaxis.tickvals = tickvals;
    layout.xaxis.ticktext = ticktext;
    
    Plotly.newPlot(divname, data.Result, layout, {
        modeBarButtons: [[
            {
                name: "Download as PNG",
                icon: Plotly.Icons.camera,
                click: function (gd) {
                    Plotly.downloadImage(gd, {
                        filename: reportCategory,
                        format: 'png',
                        width: gd._fullLayout.width,
                        height: gd._fullLayout.height
                    })
                }
            },  //-- for export or image downloading. Download plot as a png
            'hoverClosestCartesian',//show the respective values for the selected category on hovering on the point.
            'hoverCompareCartesian'//compare the values of all the categories on hovering on the point.
        ]], displaylogo: false, displayModeBar: true
    });


    $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
}


function GetPlotlyChartData(reportId) {
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        ChartRenderer(data);
    })
        .fail(function () { $("#plotly_chart_" + reportId).append("Something went wrong."); })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}
///#source 1 1 /Scripts/TatvamScript/Chart/tatvamHorizontalProgressBar.js
/*
 * Horizontal Progress Bar Plugin
 * Copyright (c) 2017
 * Depends:
 *   - jQuery v3.1.0+
 *   - bootstrap
 * @author Nithya Rani
 * @version 1.0.0
 * 
 */

(function ($) {
    'use strict';

    /**         
     * 
     * Provides the ability to manipulate the HTML template for each element of the Filter panel. 
     * These methods will be used only inside the plugin. 
     * Will not be exposed to the end user.
     * 
     * @param
     * 
     * @event
     * 
     * @return
     *      The DOM elemtns based on the type of Templates
     */
    var createHtmlTemplate = {          
            /**         
             * 
             * Provides the ability to manipulate the HTML template for each progress bar. 
             * This also bind the progress bar to the widget control
             * These methods will be used only inside the plugin. 
             * Will not be exposed to the end user.
             * 
             * @param {$pluginId}
             *      Accept the plugin id
             * @param {data}
             *      Accept the one progress bar data
             * @event
             * 
             * @return
             *      The DOM elements using the plugin id
             */
            createProgress: function ($pluginId, data, $this) {
                var progressHtml = "";
                progressHtml += "<div class='horizontalProgressRow'>";

                progressHtml += "<div class='progressBarLabel progressBar' style='text-align: left;padding-right: 0px !important;padding-left: 0px !important;color: " + $this['text-color'] + "; font-size : " + $this['font-size'] + "px; font-family : " + $this['font-family'] + ";margin-top: 0.5% !important;'>" + data.label + " (" + data.value + ")</div>";

                progressHtml += "<div class='horizontalProgressBar progressBar' style='padding-right: 0px !important;padding-left: 0px !important;'>";

                progressHtml += "<div style='overflow: hidden;background-color: #f5f5f5;border-radius: 4px;box-shadow: inset 0 1px 2px rgba(0, 0, 0, .1);height: 10px !important;margin-bottom: 7px !important;position: relative;display: block;width: 100%;margin: 0.5rem 0 1rem 0;'>";
                progressHtml += "<div class='determinate' style=' border-radius: 10px;position: absolute;top: 0;left: 0; bottom: 0;transition: width .3s linear; width: " + data.percentage.toFixed(2) + "% !important;background-color:" + data.color + ";'></div>";
                progressHtml += "</div>";
                progressHtml += "</div>";

                progressHtml += "<div class='horizontalProgressBarPercentage progressBar'  style='padding-right: 10px !important;padding-left: 0px !important;color: " + $this['text-color'] + "; font-size : " + $this['font-size'] + "px; font-family : " + $this['font-family'] + ";margin-top: 0.5% !important;'>" + data.percentage.toFixed(2) + " % </div>";

                progressHtml += "</div>";

                $("#" + $pluginId).append(progressHtml);
            }
        },
        /**         
         * 
         * Provides the ability to Read/Set/Get the Constant Details. 
         * These methods will be used only inside the plugin. 
         * Will not be exposed to the end user.
         * 
         * @param
         * 
         * @event
         * 
         * @return
         *      The DOM elemtns based on the type of Templates
         */
        exceptionHandling = {
            log: function (mesage) {
                console.log(mesage);
            },
            error: function (mesage) {
                console.error(mesage);
            }
        };


    function TatvamHorizontalProgressBar($el, options) {
        var that = this,
            name = $el.attr('name') || options.name || '';
        this.pluginId = $el.attr("id");
        this.inpData = ""; // placeholder to keep the original clean input data
        this.curData = ""; // placeholder to keep the dirty data
        this.caption = options.caption;
        this.enableClose = options.enableClose;
        this.onClose = options.onClose !== "undefined" ? options.onClose : "";
        this.filterConstant = options.filterConstant;
        this.language = options.language;
        this['text-color'] = options['text-color'];
        this['font-family'] = options['font-family'];
        this['font-size'] = options['font-size'];
    }

    TatvamHorizontalProgressBar.prototype = {
        init: function () {
          
        },       
        /**
         * Set the User input
         * 
         * @param {inpModel}
         *      set the Filter Data to the Input
         */
        setData: function (inpModel) {
            this.inpData = inpModel;
            this.curData = inpModel;
            this.createProgress();
        },      
        /**
         * Create Progress for the input data
         */
        createProgress: function () {
            var pluginId = this.pluginId;
            var $this = this;
            $.each(this.inpData, function (i, obj) {
                createHtmlTemplate.createProgress(pluginId, obj, $this);
            });
        },
    };

    // add the plugin to the jQuery.fn object
    $.fn.TatvamHorizontalProgressBar = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData"];
        this.each(function () {
            var $this = $(this),
                data = $this.data('TatvamHorizontalProgressBar'),
                options = $.extend({}, $.fn.TatvamHorizontalProgressBar.defaults, $this.data(), typeof option === "object" && option);
            if (typeof option === 'string') {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw 'Method ' + option + ' does not exist on TatvamHorizontalProgressBar';
                }
                //call the allowed methods
                value = data[option](args[1]);
            } else {
                data = new TatvamHorizontalProgressBar($this, options);
                $this.data('TatvamHorizontalProgressBar', data);
                data.init(this.id);
            }
        });
        return typeof value !== 'undefined' ? value : this;
    };
    $.fn.TatvamHorizontalProgressBar.defaults = {
        // We define an empty function so that
        // we don't need to check its existence before calling it.
        caption: 'Widget Caption',
        enableClose: true,
        onClose: null,
        language: "en",
        'text-color': "#333",
        "font-family": "Helvetica, Arial, sans-serif",
        "font-size": 12,
    };
})(jQuery);

///#source 1 1 /Scripts/TatvamScript/Chart/tatvamRadialProgressBar.js
/*
 * NPS Plugin
 * Copyright (c) 2017
 * Depends:
 *   - jQuery v3.1.0+
 *   - bootstrap
 *   - bootbox
 * @author Nithya Rani
 * @version 1.0.0
 * 
 */
(function ($) {
    'use strict';

    /**         
     * 
     * Provides the ability to Read/Set/Get the Constant Details. 
     * These methods will be used only inside the plugin. 
     * Will not be exposed to the end user.
     * 
     * @param
     * 
     * @event
     * 
     * @return
     *      The DOM elemtns based on the type of Templates
     */
    var exceptionHandling = {
            log: function (mesage) {
                console.log(mesage);
            },
            error: function (mesage) {
                console.error(mesage);
            }
        },
        createTemplate = {
            /**         
             * 
             * Provides the ability to manipulate the HTML template for each progress bar. 
             * This also bind the progress bar to the widget control
             * These methods will be used only inside the plugin. 
             * Will not be exposed to the end user.
             * 
             * @param {$pluginId}
             *      Accept the plugin id
             * @param {options}
             *      Accept the one progress bar data
             * @event
             * 
             * @return
             *      The DOM elements using the plugin id
             */
            createProgressTemplate: function ($obj, options) {
                var defaults = {
                    "inline": true,
                    "font-size": 40,
                    "font-family": "Helvetica, Arial, sans-serif",
                    "text-color": null,
                    "lines": 1,
                    "line": 0,
                    "symbol": "",
                    "margin": 0,
                    "color": "rgb(55,123,181)",
                    "background": "rgba(0,0,0,0.1)",
                    "size": $obj.outerWidth(),
                    "fill": "5px",
                    "range": [0, 100]
                };

                this.options = $.extend(defaults, options);
                this.first_rot_base = -135;
                this.second_rot_base = -315;
                this.options.size = parseInt(this.options.size, 10);
                this.options.fill = parseInt(this.options.fill, 10);
                this.options['font-size'] = parseInt(this.options['font-size'], 10);
                this.options.margin = Math.max(0, parseInt(this.options.margin, 10));
                this.options['text-color'] = this.options['text-color'] || this.options.color;


                $obj.css({
                    "position": "relative",
                    "width": this.options.size,
                    "height": this.options.size,
                    "display": this.options.inline ? "inline-block" : "block"
                });

                /**
                 * create the progress bar circle
                 */
                this.$radialBackground = $("<div>").appendTo($obj).css({
                    "box-sizing": "border-box",
                    "-moz-box-sizing": "border-box",
                    "-webkit-box-sizing": "border-box",
                    "position": "absolute",
                    "top": this.options.margin,
                    "left": this.options.margin,
                    "width": this.options.size - this.options.margin * 2,
                    "height": this.options.size - this.options.margin * 2,
                    "border": this.options.fill + "px dotted " + this.options.background,
                    //"border": this.options.fill + "px solid #ff0000",
                    "border-radius": Math.ceil(this.options.size / 2) + "px",
                });
                /**
                 * Right side of the progress bar
                 */
                this.$radialFirstHalfMask = $("<div>").appendTo($obj).css({
                    "position": "absolute",
                    "top": this.options.margin,
                    "right": this.options.margin,
                    "width": Math.round(this.options.size / 2) - this.options.margin,
                    "height": this.options.size - this.options.margin * 2,
                    "overflow": "hidden"
                });

                this.$radialFirstHalf = $("<div>").appendTo(this.$radialFirstHalfMask).css({
                    "box-sizing": "border-box",
                    "-moz-box-sizing": "border-box",
                    "-webkit-box-sizing": "border-box",
                    "position": "absolute",
                    "top": "0px",
                    "border-width": this.options.fill,
                    "border-style": "solid",
                    "border-color": this.options.color + " " + this.options.color + " transparent transparent",
                    "width": "200%",
                    "height": "100%",
                    "border-radius": "50%",
                    "left": "-100%",
                    "transform": "rotate(" + this.first_rot_base + "deg)"
                });


                /**
                 * Left side of the progress bar
                 */
                this.$radialSecondHalfMask = $("<div>").appendTo($obj).css({
                    "position": "absolute",
                    "top": this.options.margin,
                    "left": this.options.margin,
                    "width": Math.round(this.options.size / 2) - this.options.margin,
                    "height": this.options.size - this.options.margin * 2,
                    "overflow": "hidden"
                });


                this.$radialSecondHalf = $("<div>").appendTo(this.$radialSecondHalfMask).css({
                    "box-sizing": "border-box",
                    "-moz-box-sizing": "border-box",
                    "-webkit-box-sizing": "border-box",
                    "position": "absolute",
                    "top": "0px",
                    "border-width": this.options.fill,
                    "border-style": "solid",
                    "border-color": this.options.color + " " + this.options.color + " transparent transparent",
                    "width": "200%",
                    "height": "100%",
                    "border-radius": "50%",
                    "left": "0px",
                    "transform": "rotate(" + this.second_rot_base + "deg)"
                });
                if (this.options['text-color']) {
                    this.$radialLabel = $("<div id='radial_label'>").appendTo($obj).css({
                        "position": "absolute",
                        "font-size": "17px",
                        "font-family": this.options['font-family'],
                        "font-weight" : "bold",
                        "color": '#4f4c4c',
                        "left": "50%",
                        "top": "50%",
                        "transform": "translate(-50%, -50%)"
                    });
                }

                this.percentage = 0;
                this.queue = [];
                return this;
            },

        };


    function TatvamRadialProgressBar($el, options) {
        this.pluginId = $el.attr("id");
        this.data = ""; // placeholder to keep the original clean input data
        this.caption = options.caption;
        this.enableClose = options.enableClose;
        this.onClose = options.onClose !== "undefined" ? options.onClose : "";
        this.language = options.language;
        var $obj = $("#" + this.pluginId);
        this.queue = options.queue;
        //this.inline = options.inline;
        //this['font-size'] = options['font-size'];
        //this['font-family'] = options['font-family'];
        //this['text-color'] = options['text-color'];
        //this.lines = options.lines;
        //this.line = options.line;
        //this.symbol = options.symbol;
        //this.margin = options.margin;
        //this.color = options.color;
        //this.background = options.background;

        //this.size = $obj.outerWidth();
        //this.fill = options.fill;
        //this.range = options.range;
        //this.first_rot_base = options.first_rot_base;
        //this.second_rot_base = options.second_rot_base;
        this.options = $.extend(this, options);
        // this.options.size = parseInt(this.size, 10);
        // this.options.fill = parseInt(options.fill, 10);
        // this.options['font-size'] = parseInt(options['font-size'], 10);
        // this.options.margin = Math.max(0, parseInt(options.margin, 10));
        //this.percentage = 0;
        //this.options.percentage = 0;
    }

    TatvamRadialProgressBar.prototype = {
        init: function () {

        },
        /**
         * Create the Filter Gadget based on the given field name and field type
         */
        createNPSWidget: function (data) {
            if (data === "undefined") {
                exceptionHandling.error(this.filterConstant.errorMessages.inputNotProvided);
                return;
            }

            if (data === "") {
                exceptionHandling.error(this.filterConstant.errorMessages.blankInput);
                return;
            }
            this.createProgress(data);
        },
        /**
         * Set the User input
         * 
         * @param {inpModel}
         *      set the Filter Data to the Input
         */
        setData: function (inpModel) {
            this.data = inpModel;
            this.createProgress();
        },
        /**
         * Set the Caption of the widget
         * 
         * @param {caption}
         *      set the caption to the label
         */
        setCaption: function (caption) {
            if (caption === "") {
                exceptionHandling.error();
                return;
            }
            this.caption = caption;
            $("#caption_" + this.pluginId).empty();
            $("#caption_" + this.pluginId).append(this.caption);
        },
        /**
         * return the widget Caption
         */
        getCaption: function () {
            return this.caption;
        },
        /**
         * Create Progress for the input data
         */
        createProgress: function () {
            var $this = this;

            var space = $this.space || 2,
                segmentFill = Math.floor($this.fill / $this.data.length) - space,
                margin = 0;

            for (var i = 0; i < $this.data.length; i++) {
                var obj = $this.data[i];
                var tempFill = {
                    'fill': segmentFill,
                    'margin': margin,
                    'lines': $this.data.length,
                    'line': obj.index,
                    'color': obj.color
                };
                $("#" + this.pluginId).data("__multiProgress" + obj.index, new createTemplate.createProgressTemplate($("#" + this.pluginId), $.extend(this, obj, tempFill), obj.index));
                margin += segmentFill + space;

                this.progressToPercentage({
                    "index": $this.data[i].index,
                    'percentage': $this.data[i].percentage,
                    'time': $this.data[i].time
                });
            }
            var promoters = 0;
            var detractors = 0;
            $.each(this.data, function(i,obj) {
                if (obj.label === "Promoters") {
                    promoters = obj.percentage;
                }
                if (obj.label === "Detractors") {
                    detractors = obj.percentage;
                }
            });
            var overAllScore = (promoters - detractors).toFixed(0);
            if (overAllScore > 0) {
                overAllScore = "+" + overAllScore;
            }
            $("#radial_label").text(overAllScore);
        },

        progressToPercentage: function (options) {
            var self = $("#" + this.pluginId).data("__multiProgress" + options.index),
                offset = options.offset || 0,
                interval_delay = 10,
                time = options.time || 1000,
                targetPerc = Math.max(0, Math.min(100, (options.percentage - self.options.range[0]) / (self.options.range[1] - self.options.range[0]) * 100)),
                diffPerc = targetPerc - self.percentage,
                direction = diffPerc / Math.abs(diffPerc),
                step = diffPerc / (time / interval_delay);
            if (!self.animation) {
                self.animation = setInterval(function () {
                    if ((direction > 0 && self.percentage >= targetPerc) || (direction < 0 && self.percentage <= targetPerc)) {
                        window.clearInterval(self.animation);
                        self.animation = null;
                        var next = self.queue.shift();
                        if (next) {
                            self.progressToPercentage(next);
                        }
                        return;
                    }
                    self.percentage += step;
                    var first_rot = self.first_rot_base;
                    var second_rot = self.second_rot_base;
                    if (self.percentage < 50) {
                        first_rot = self.first_rot_base + (self.percentage / 50) * 180;
                        second_rot = self.second_rot_base;
                    } else {
                        first_rot = self.first_rot_base + 1 * 180;
                        second_rot = self.second_rot_base + ((self.percentage - 50) / 50) * 180;
                    }
                    self.$radialFirstHalf.css({
                        "transform": "rotate(" + first_rot + "deg)"
                    });
                    self.$radialSecondHalf.css({
                        "transform": "rotate(" + second_rot + "deg)"
                    });
                    //if (self.$radialLabel) {
                    //    var value = targetPerc ? self.percentage / targetPerc * (targetPerc - offset) : 0;
                    //    value = self.options.range[0] + value / 100 * (self.options.range[1] - self.options.range[0]);
                    //    var text = Math.round(value + self.options.symbol);
                    //    for (var ti = 0; ti < self.options.line; ti++) {
                    //        text = "&nbsp;<br>" + text;
                    //    }
                    //    for (var tj = self.options.lines - (self.options.line + 1); tj > 0; tj--) {
                    //        text = text + "<br>&nbsp;";
                    //    }
                    //    self.$radialLabel.html(text);
                    //}
                }, interval_delay);
            } else {
                this.queue.push(options);
            }
        }
    };


    // add the plugin to the jQuery.fn object
    $.fn.TatvamRadialProgressBar = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData", "setCaption", "getCaption", "progressToPercentage"];
        this.each(function () {
            var $this = $(this),
                data = $this.data('TatvamRadialProgressBar'),
                options = $.extend({}, $.fn.TatvamRadialProgressBar.defaults, $this.data(), typeof option === "object" && option);
            if (typeof option === 'string') {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw 'Method ' + option + ' does not exist on TatvamRadialProgressBar';
                }
                //call the allowed methods
                value = data[option](args[1]);
            } else {
                data = new TatvamRadialProgressBar($this, options);
                $this.data('TatvamRadialProgressBar', data);
                data.init(this.id);
            }
        });
        return typeof value !== 'undefined' ? value : this;
    };
    $.fn.TatvamRadialProgressBar.defaults = {
        // We define an empty function so that
        // we don't need to check its existence before calling it.
        caption: 'Widget Caption'    
    };
})(jQuery);

///#source 1 1 /Scripts/TatvamScript/Chart/tatvamRadialHorizontalProgressCombo.js
/*
 * Horizontal Plus Radial Progress Bar Plugin
 * Copyright (c) 2017
 * Depends:
 *   - jQuery v3.1.0+
 *   - bootstrap
 * @author Nithya Rani
 * @version 1.0.0
 * 
 */
(function ($) {
    'use strict';

    /**         
     * 
     * Provides the ability to manipulate the HTML template for each element of the Filter panel. 
     * These methods will be used only inside the plugin. 
     * Will not be exposed to the end user.
     * 
     * @param
     * 
     * @event
     * 
     * @return
     *      The DOM elemtns based on the type of Templates
     */
    var createHtmlTemplate = {
        /**         
         * 
         * Provides the ability to manipulate the HTML template for each progress bar. 
         * This also bind the progress bar to the widget control
         * These methods will be used only inside the plugin. 
         * Will not be exposed to the end user.
         * 
         * @param {$pluginId}
         *      Accept the plugin id
         * @param {data}
         *      Accept the one progress bar data
         * @event
         * 
         * @return
         *      The DOM elements using the plugin id
         */
        createProgress: function ($pluginId) {
            var containerHeight = $("#" + $pluginId).parent().height() - 40;
            var progressHTML = "";            
            progressHTML += "<div class='radialProgressContainer' style=''><div id='radialProgress" + $pluginId + "' class='leftDivision' style='width:" + containerHeight + "px !important; '></div></div>";
            progressHTML += "<div class='horizontalProgressContainer' style=''><div id='Horizontalprogress" + $pluginId + "' class='rightDivision'></div></div>";
            
            $("#" + $pluginId).append(progressHTML);
        }
    },
        /**         
         * 
         * Provides the ability to Read/Set/Get the Constant Details. 
         * These methods will be used only inside the plugin. 
         * Will not be exposed to the end user.
         * 
         * @param
         * 
         * @event
         * 
         * @return
         *      The DOM elemtns based on the type of Templates
         */
        exceptionHandling = {
            log: function (mesage) {
                console.log(mesage);
            },
            error: function (mesage) {
                console.error(mesage);
            }
        };


    function TatvamRadialHorizontalProgressBar($el, options) {
        var that = this,
            name = $el.attr('name') || options.name || '';
        this.pluginId = $el.attr("id");
        this.inpData = ""; // placeholder to keep the original clean input data
        this.curData = ""; // placeholder to keep the dirty data
        this.infoDetails = options.infoDetails;
        this.caption = options.caption;
        this.enableClose = options.enableClose;
        this.onClose = options.onClose !== "undefined" ? options.onClose : "";
        this.filterConstant = options.filterConstant;
        this.language = options.language;
        this['text-color'] = options['text-color'];
        this['font-family'] = options['font-family'];
        this['font-size'] = options['font-size'];
    }

    TatvamRadialHorizontalProgressBar.prototype = {
        init: function () {
            createHtmlTemplate.createProgress(this.pluginId);
            $(this.infoDetails.selector).append("<a style='position: absolute;z-index: 9;right: 10px;font-size: 20px;' href='#' class='pull-right' data-trigger='focus' data-placement='left' data-toggle='popover'  data-container='body'><i class='fa fa-info-circle' aria-hidden='true'></i></a>");
            $('[data-toggle="popover"]').popover({ title: this.infoDetails.title, content: "<div style='font-size:12px;'>" + this.infoDetails.description + "</div>", html: true, placement: "left" });
        },
        /**
         * Set the User input
         * 
         * @param {inpModel}
         *      set the Filter Data to the Input
         */
        setData: function (inpModel) {
            this.inpData = inpModel;
            this.curData = inpModel;
            this.createProgress();
        },
        /**
         * Create Progress for the input data
         */
        createProgress: function () {
            var pluginId = this.pluginId;
            var $this = this;
            $("#radialProgress" + pluginId).TatvamRadialProgressBar(layout);
            $("#radialProgress" + pluginId).TatvamRadialProgressBar("setData", this.inpData);

            $("#Horizontalprogress" + pluginId).TatvamHorizontalProgressBar(layout);
            $("#Horizontalprogress" + pluginId).TatvamHorizontalProgressBar("setData", this.inpData);
        },
    };

    // add the plugin to the jQuery.fn object
    $.fn.TatvamRadialHorizontalProgressBar = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData"];
        this.each(function () {
            var $this = $(this),
                data = $this.data('TatvamRadialHorizontalProgressBar'),
                options = $.extend({}, $.fn.TatvamRadialHorizontalProgressBar.defaults, $this.data(), typeof option === "object" && option);
            if (typeof option === 'string') {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw 'Method ' + option + ' does not exist on TatvamRadialHorizontalProgressBar';
                }
                //call the allowed methods
                value = data[option](args[1]);
            } else {
                data = new TatvamRadialHorizontalProgressBar($this, options);
                $this.data('TatvamRadialHorizontalProgressBar', data);
                data.init(this.id);
            }
        });
        return typeof value !== 'undefined' ? value : this;
    };
    $.fn.TatvamRadialHorizontalProgressBar.defaults = {
        // We define an empty function so that
        // we don't need to check its existence before calling it.
        caption: 'Widget Caption',
        enableClose: true,
        onClose: null,
        language: "en",
        'text-color': "#333",
        "font-family": "Helvetica, Arial, sans-serif",
        "font-size": 12
    };
})(jQuery);



function GetNPSData(reportId) {
    $.getJSON("../Data/GetNPSData", { reportId: reportId, isExecutiveSummary: false }, function (data) {          
        var reportname = data.Report.ReportCategory.replace(/ /g, '');      
        if (data.Result == null || data.Result.length <= 0) {
            $("#divid_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        } else {    
            $("#divid_" + reportId).empty();
            $("#divid_" + reportId).TatvamRadialHorizontalProgressBar(layout);
            $("#divid_" + reportId).TatvamRadialHorizontalProgressBar("setData", data.Result);
        }
        $('#chartloader_' + reportId).css('display', 'none');
    })
        .fail(function() {    
            $("#divid_" + reportId).css('display', 'block');
            $("#divid_" + reportId).empty();
            $("#divid_" + reportId).append("Something went wrong.");
        })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}
///#source 1 1 /Scripts/TatvamScript/Chart/TatvamGrid.js
function GetGridData(reportId) {
    $.getJSON("../Data/GetGridData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $("#Grid_" + reportId).css('display', 'block');
        if (data.Result.length === 0) {
            $("#Grid_" + reportId).empty();
            $("#Grid_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else {
            if (data.Result._GridData.length === 0) {
                $("#Grid_" + reportId).spreadsheetWidget(data.Result._Properties);
            }

            if (data.Result._Properties.columnDefs !== undefined && data.Result._Properties.columnDefs !== null) {
                // This will convert the column definition function string to function for execution
                data.Result._Properties.columnDefs.forEach(function (value, index) {
                    if (value.cellRenderer != null) {
                        var cellRenderer = value.cellRenderer;
                        data.Result._Properties.columnDefs[index].cellRenderer = eval(cellRenderer);
                    }
                    if (value.cellStyle != null) {
                        var cellStyle = value.cellStyle;
                        data.Result._Properties.columnDefs[index].cellStyle = eval(cellStyle);
                    }
                });
            } else {
                data.Result._Properties.columnDefs = data.Result._GridColumns;
            }

            $("#Grid_" + reportId).spreadsheetWidget(data.Result._Properties);
            $("#Grid_" + reportId).spreadsheetWidget('setRowData', data.Result._GridData);

            var gridster = $('.gridster ul#widgets').gridster().data('gridster');
            var widgetObj = gridster.$widgets.closest("#widget_" + reportId);
            var sizex = widgetObj.attr("data-sizex");

            if (sizex !== undefined) {
                var reviewListContainerHeight = $("#Grid_" + reportId + " .ag-body-container").height();
                console.log(reviewListContainerHeight);
                var sizey = Math.ceil(reviewListContainerHeight / 128);
                gridster.resize_widget(widgetObj, sizex, sizey +1, function (obj1, obj2) { });
            }

            $("#report_" + reportId).css({ 'overflow': 'hidden' });
            $("#report_" + reportId).parent().css({ 'height': '94%' });

        }
        $("#chartloader_" + reportId).css('display', 'none');
    }).fail(function () { $('#smile').css('display', 'block'); $("#smile").empty(); $("#smile").append("Something went wrong."); }).always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}
