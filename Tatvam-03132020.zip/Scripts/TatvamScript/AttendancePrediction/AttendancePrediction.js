﻿var saveModel_CallURL = "../Page/SaveModelData";
var viewModel_CallURL = "../Page/ViewModelData";
var getPrediction_CallURL = "../Page/GetAttendancePredictionGridData";
var getInfluencers_CallURL = "../Page/GetAttendancePredictionInfluencerDisplayList";

var chk_Influencers = [];
var influencerNames = [];

function DisableButtonOnDataChange() {

    $('#btnPredict').prop("disabled", true);

}

function EnableButtonOnDataChange() {

    $('#btnPredict').prop("disabled", false);


}

function EnableAttendancePredictionFormControls() {

    $('#days').prop("disabled", false);
    $('#fromdate').prop("disabled", false);
    $('input:checkbox').prop("disabled", false);
    EnableButtonOnDataChange();
}

function DisableAttendancePredictionFormControls() {

    $('#days').prop("disabled", true);
    $('#fromdate').prop("disabled", true);
    $('input:checkbox').prop("disabled", true);
    DisableButtonOnDataChange();
}

function ResetControls() {

    $("#fromdate").val('');
    $("#days").val('21');
    $("#Years").val('1');

    chk_Influencers = [];

    $(".btn").removeClass("active");
    $("#lbldefault").empty();
    setInputDate("#fromdate");
    $("#txtModelName").val('');
    // DisableButtonOnDataChange();
    DisablePredictedControls();
    //$('input:checkbox').removeAttr('checked');
    $('input:checkbox').prop('checked', false);
    $('#AttendancePredictionChart').empty();
    if ($('#ddlmodel').has('option').length === 0) {
        $("#modelControls").hide();
    }
    else {
        $("#ddlmodel")[0].selectedIndex = -1;
        $("#ddlmodel option:selected").removeAttr("selected");
        $("#ddlmodel option:first").attr('selected', 'selected').change();
        if ($("#ddlmodel-button").is(":visible"))
            window.location.reload(true);
        //ViewModel($("#ddlmodel option:first").val());
    }
}

function EnablePredictedControls() {
    $("#PredictAttendanceChart").show();
    $("#PredictAttendanceData").show();
}

function DisablePredictedControls() {

    $("#PredictAttendanceChart").hide();
    $("#PredictAttendanceData").hide();
}


function CallAttendancePredictionCreateDialog() {
    $("#Create_Model_dialog").html("<div class='col-lg-11'><div class='row'><div class='col-lg-4 tatvamlable'><label>Model Name</label></div><div class='col-lg-8'><input type='text' placeholder='Name of Model' class='form-control' id='txtModelName' tabindex='18'></div></div><br /><div class='row'><div class='col-lg-4'></div><div class='col-lg-5'><div class='tatvamradio'><div class='tatvamradio-primary'><input type='checkbox' name='chkHistoricalYr' id='chk_default' value='Default' tabindex='19' /><label for='chk_default' tabindex='19'>Default</label></div></div></div></div></div>");
    var ModelDialog = $("#Create_Model_dialog").dialog();
    $("#model_overlay").show();
    $("#Create_Model_dialog").dialog({
        resizable: false,
        modal: true,
        title: "Create/Update Model",
        width: 400,
        buttons: {
            "Proceed": function () {
                var modelName = $("#txtModelName").val().trim();
                var isDefault = $("#chk_default").is(":checked");
                if (modelName === "") {
                    $("#dialog-confirm").html("Please enter Model Name.");

                    $("#dialog-confirm").dialog({
                        resizable: false,
                        modal: true,
                        title: "Error",
                        width: 300,
                        buttons: {
                            "Ok": function () {
                                $(this).dialog('close');
                                $("#model_overlay").hide();
                                ModelDialog.dialog('open');
                            }
                        }
                    });
                }
                else if (/^[a-zA-Z0-9- ]*$/.test(modelName) === false) {
                    $("#dialog-confirm").html("Special characters are not allowed");
                    $("#dialog-confirm").dialog({
                        resizable: false,
                        modal: true,
                        title: "Error",
                        width: 300,
                        buttons: {
                            "Ok": function () {
                                $(this).dialog('close');
                                $("#model_overlay").hide();
                                ModelDialog.dialog('open');
                            }
                        }
                    });
                }
                else if (($("#ddlmodel").val() !== null && $("#ddlmodel").val()[0] !== modelName && $('#ddlmodel option[value="' + titleCase(modelName) + '"]').length !== 0)) {
                    $("#dialog-confirm").html("This model is already created.Do u want to overwrite the existing model?");
                    $("#dialog-confirm").dialog({
                        resizable: false,
                        modal: true,
                        title: "Warning",
                        width: 300,
                        buttons: {
                            "Ok": function () {
                                ModelDialog.dialog('close');
                                $(this).dialog('close');
                                $("#model_overlay").hide();
                                SaveModel(modelName, isDefault);

                                if ($('#ddlmodel option[value="' + titleCase(modelName) + '"]').length === 0) {

                                    $("#ddlmodel option:selected").removeAttr("selected");
                                    $("#ddlmodel").append('<option value="' + titleCase(modelName) + '" selected="selected">' + titleCase(modelName) + '</option>');

                                }
                                else {
                                    $("#ddlmodel option:selected").removeAttr("selected");
                                    $("#ddlmodel option[value='" + titleCase(modelName) + "']").remove();
                                    $("#ddlmodel").append('<option value="' + titleCase(modelName) + '" selected="selected">' + titleCase(modelName) + '</option>');
                                    $("#ddlmodel option[value='" + titleCase(modelName) + "']").attr("selected", 1);

                                }
                            },
                            "Cancel": function () {
                                $("#model_overlay").hide();
                                $(this).dialog('close');
                                ModelDialog.dialog('open');
                            }
                        }
                    });

                }

                else if ($("#ddlmodel").val() === null && $('#ddlmodel').has('option').length > 0 && $('#ddlmodel option[value="' + titleCase(modelName) + '"]').length !== 0) {
                    $("#dialog-confirm").html("This model is already created.Do u want to overwrite the existing model?");
                    $("#dialog-confirm").dialog({
                        resizable: false,
                        modal: true,
                        title: "Warning",
                        width: 300,
                        buttons: {
                            "Ok": function () {
                                $(this).dialog('close');
                                ModelDialog.dialog('close');
                                SaveModel(modelName, isDefault);
                                if ($('#ddlmodel option[value="' + titleCase(modelName) + '"]').length === 0) {
                                    $("#ddlmodel option:selected").removeAttr("selected");
                                    $("#ddlmodel").append('<option value="' + titleCase(modelName) + '" selected="selected">' + titleCase(modelName) + '</option>');

                                }
                                else {
                                    $("#ddlmodel option:selected").removeAttr("selected");
                                    $("#ddlmodel option[value='" + titleCase(modelName) + "']").remove();
                                    $("#ddlmodel").append('<option value="' + titleCase(modelName) + '" selected="selected">' + titleCase(modelName) + '</option>');
                                    $("#ddlmodel option[value='" + titleCase(modelName) + "']").attr("selected", 1);

                                }
                            },
                            "Cancel": function () {
                                $(this).dialog('close');
                                ModelDialog.dialog('open');
                            }
                        }
                    });

                }
                else {
                    SaveModel(modelName, isDefault);

                    if ($('#ddlmodel').has('option').length === 0) {
                        $("#ddlmodel option:selected").removeAttr("selected");
                        $("#ddlmodel").append('<option value="' + titleCase(modelName) + '" selected="selected">' + titleCase(modelName) + '</option>');

                    }

                    else if ($('#ddlmodel').has('option').length > 0 && $('#ddlmodel option[value="' + titleCase(modelName) + '"]').length === 0) {
                        $("#ddlmodel option:selected").removeAttr("selected");
                        $("#ddlmodel").append('<option value="' + titleCase(modelName) + '" selected="selected">' + titleCase(modelName) + '</option>');

                    }

                    if (isDefault === true) {
                        $("#lbldefault").text('Default Model');
                    }
                    else {
                        $("#lbldefault").empty();
                    }
                    $(this).dialog('close');

                }

            },
            "Discard": function () {
                $("#dialog-confirm").html("Are you sure. You want to discard Changes.");
                $("#dialog-confirm").dialog({
                    resizable: false,
                    modal: true,
                    dialogClass: "no-close",
                    title: "Warning",
                    width: 300,
                    buttons: {
                        "Ok": function () {
                            $(this).dialog('close');
                            $("#model_overlay").hide();
                            ModelDialog.dialog('close');
                        },
                        "Cancel": function () {
                            $(this).dialog('close');
                            $("#model_overlay").hide();
                            ModelDialog.dialog('open');
                        }
                    }
                });
            }
        }
    });
}

function titleCase(str) {

    return str.split(' ').map(function (val) {
        return val.charAt(0).toUpperCase() + val.substr(1).toLowerCase();
    }).join(' ');
}

function SaveModel(modelName, isDefault) {
    if (ValidateAttendancePredictionForm()) {
        var message = '';
        if (chk_Influencers.length === 0) {
            message += "Influencers<br />";
        }

        if (message !== '') {
            bootbox.alert({
                title: "Error Message",
                message: "Please enter below mandatory fields <div style='color:#ff0000;'>" + message + '</div>',
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                }
            })
            return false;
        }

        showLoadingCursor();
        $("#modelControls").show();
        $("#btndiscard").hide();
        $("#btnNew").show();

        $.ajax({
            type: "POST",
            url: saveModel_CallURL,
            data: { year: $("#Years").val(), fromDate: getFormattedDate($("#fromdate").val()), days: $("#days").val(), modelName: modelName, influencers: chk_Influencers, isDefault: isDefault },
            success: function (searchResults) {

                hideLoadingCursor();
                if (searchResults.length > 100) {
                    if (searchResults.indexOf("<title>SessionTimeOut</title>") > -1)
                        window.location.href = "../SessionTimeOut/SessionTimeOut";
                }

                else {

                    if (searchResults === 1) {
                        bootbox.alert({
                            size: "small",
                            title: "Success",
                            message: "Model saved successfully.",
                            buttons: {
                                ok: {
                                    label: 'Yes',
                                    className: 'btn-primary'
                                }
                            },
                            callback: function () {
                                $(this).modal('hide');
                                storeValue('model', $('#txtModelName').val());
                                window.location.reload(true);
                            }
                        })
                    } else {
                        TatvamAlert("Unable to save the model.", "Error");
                    }
                }
            },
            error: function () {
                hideLoadingCursor();
                TatvamAlert("Error occurred while saving the model. Please contact your system administrator.", "Error");
            }
        });
    }
}

function TatvamAlert(Message, Title) {
    bootbox.alert({
        title: Title,
        message: Message,
        buttons: {
            ok: {
                label: 'Ok',
                className: 'btn-primary'
            }
        },
        callback: function () {
            ResetControls();
        }
    })
}

function loadInfluencers() {
    var chkContainer = $('#PredictAttendanceForm .tatvamCheckboxContent .checkboxrow .tatvamradio');

    $.ajax({
        type: "GET",
        url: getInfluencers_CallURL,
        success: function (influencers) {
            chkContainer.html('');
            var days = $("#days").val();

            $.each(influencers, function (i, influencer) {

                var option = "";

                if (days > 1 && influencer.InfluencerName.toLowerCase().indexOf("google") > -1) {
                    option = "disabled";
                }

                chkContainer.append('<div class="tatvamradio-primary">\
                                     <input type="checkbox" name="chkInfluencers" id="chk_Influencers' + i + '" value="' + influencer.InfluencerValue + '" ' + option + '/>\
                                     <label for="chk_Influencers' + i + '" >' + influencer.InfluencerName + '</label>\
                                     </div>\
                ');

            });

            ctrl = $("input[type='checkbox']").filter(function () {
                return $(this).attr('value').toLowerCase().indexOf('google') > -1;
            });
        },
        error: function () {
            hideLoadingCursor();
            TatvamAlert("Error occurred while fetching influencer data.", "Error");

        }
    });
}

function ViewModel(modelName) {
    $("#modelControls").show();
    $("#btndiscard").hide();
    $("#btnNew").show();
    $.ajax({
        type: "POST",
        url: viewModel_CallURL,
        data: { modelName: modelName },
        success: function (searchResults) {
            if (searchResults.Error !== null) {
                TatvamAlert(searchResults.Error, "Error");
            }
            else if (searchResults.LstAttendancePredictionFormDo.length !== 0) {
                AssignValuestoAttendancePredictionForm(searchResults.LstAttendancePredictionFormDo[0]);
            }
            else {
                ResetControls();
            }
            PredictData();
        },
        error: function () {
            hideLoadingCursor();
            TatvamAlert("Error occurred while fetching the model.", "Error");

        }
    });
}



function ValidateAttendancePredictionForm() {
    var message = '';
    var dayserrormessage = '';
    //if (chk_Influencers.length === 0) {
    //    message += "Influencers<br />";
    //}

    if ($("#Years").val().trim() === '') {
        message += "Years<br />";
    }
    if ($("#Years").val().trim() === "0") {
        dayserrormessage += "Years cannot be 0<br />";
    }
    if ($("#Years").val().trim() > 3) {
        dayserrormessage += "Years cannot be greater than 3 <br />";
    }
    if ($("#days").val().trim() === '') {
        message += "# of Days<br />";
    }
    if ($("#days").val().trim() === "0") {
        dayserrormessage += "No of Days cannot be 0 <br />";
    }

    if ($("#days").val().trim() > 30) {
        dayserrormessage += "Kindly predict for 30 days only <br />";
    }
    var EnteredDate = $("#fromdate").val(); // For JQuery
    var year = EnteredDate.substring(0, 4);
    var d = new Date();
    var currentyear = d.getFullYear();
    if ((year < currentyear - 3) || (year > currentyear)) {
        dayserrormessage += "The date range can span only within previous 3 years from the current year.";
    }
    //if (year > currentyear) {
    //    dayserrormessage += "The date range can span only within previous 5 years from the current year.";
    //}
    if ($("#fromdate").val().trim() === '') {
        message += "Date<br />";
    }

    if (message !== '') {
        bootbox.alert({
            title: "Error Message",
            message: "Please enter below mandatory fields <div style='color:#ff0000;'>" + message + '</div>',
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            }
        })
        return false;
    }
    else if (message === '' && dayserrormessage !== '') {
        bootbox.alert({
            title: "Error Message",
            message: dayserrormessage,
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            }
        })
        return false;

    }
    return true;
}

function CreateAttendancePredictionPage(data) {
    showLoadingCursor();
    $('#btnReset').prop("disabled", true);    
    if (data.LstAttendancePredictionFormDo.length === 0) {
        DisablePredictedControls();
        // DisableButtonOnDataChange();
        $("#PredictAttendanceForm").hide();
        $("#modelControls").hide();
        $("#btndiscard").hide();
        $("#btnNew").show();
        $("#days").val('21');
        //   $("#fromdate").datepicker({ dateFormat: 'dd-M-y' }).datepicker("setDate", "0");
        setInputDate("#fromdate");

    } else {
        $("#PredictAttendanceForm").show();
        $("#modelControls").show();
        $("#btndiscard").show();
        $("#btnNew").hide();
        $("#ddlmodel").empty();

        DisablePredictedControls();
        // DisableButtonOnDataChange();
        var isdefault = false;

        $.each(data.LstAttendancePredictionFormDo, function (i) {
            if (data.LstAttendancePredictionFormDo[i].Isdefault) {
                AssignValuestoAttendancePredictionForm(data.LstAttendancePredictionFormDo[i]);
                $("#lbldefault").text('Default Model');
                EnableAttendancePredictionFormControls();
                isdefault = true;
                $("#ddlmodel").append('<option value="' + data.LstAttendancePredictionFormDo[i].Modelname + '" selected="selected">' + data.LstAttendancePredictionFormDo[i].Modelname + ' (Default)' + '</option>').attr("selected", 1);
                EnablePredictedControls();
                $("#btndiscard").hide();
                $("#btnNew").show();

                FillPredictControls(data);
            }
            else {
                $("#btndiscard").hide();
                $("#btnNew").show();
                $("#ddlmodel").append('<option value="' + data.LstAttendancePredictionFormDo[i].Modelname + '">' + data.LstAttendancePredictionFormDo[i].Modelname + '</option>');

            }
        });
        if (!isdefault) {
            DisableAttendancePredictionFormControls();
        }

    }
    hideLoadingCursor();
}

function AssignValuestoAttendancePredictionForm(data) {
    chk_Influencers = [];
    //$('input:checkbox').removeAttr('checked');
    $("#ddlmodel option[value='" + data.Modelname + "']").attr("selected", 1);
    setInputDate("#fromdate");
    $("#days").val(data.PredictionForDays);
    $("#txtModelName").val(data.Modelname);
    if (data.Isdefault) {
        $("#lbldefault").text('Default Model');
    }
    else {
        $("#lbldefault").empty();
    }
    // var jsonObject = jQuery.parseJSON(data.JSONdata);
    $('input[name="chkInfluencers"]').each(function (i) {
        $(this).prop("checked", false);
    });
    $('input[name="chkInfluencers"]').each(function (i) {        
        var val = CheckValueExistinList(data.InfluencerList, this.value);
        if (val) {
            $(this).prop("checked", true);
            chk_Influencers.push(this.value);
        }
    });

    $("#Years").val(data.Years);

    $('#btnPredict').prop("disabled", false);
    $('#btnsaveModel').prop("disabled", false);
    $("#btnReset").prop("disabled", true);
}


function CheckValueExistinList(list, value) {

    return list.some(function (el) {
        return el.Text === value;
    });
}

function loadGrid(jsonData) {
    var listOfColumnModels = [];
    var listOfColumnNames = [];

    for (var prop in jsonData[0]) {
        if (jsonData[0].hasOwnProperty(prop)) {
            //  We have found one property (field) in our JSON data.
            //  Add a column to the list of Columns which we want our jqGrid to display
            if (prop != "Attendance") {
                listOfColumnNames.push(prop);

                listOfColumnModels.push({
                    name: prop,
                    sortable: true,
                    hidden: false,
                    width: 145,
                    align: "center"
                });
            }
        }
    }

    $.each(listOfColumnNames, function (i, v) {
        listOfColumnNames[i] = v.replace(/_/g, " ");
    });

    var Attendacegrid = $("#grid");
    Attendacegrid.jqGrid({
        datatype: "local",
        data: jsonData,
        //colNames: ['Date', 'Day of Week', 'Special Day', 'Predicted Attendance', 'Actual Attendance'],
        //colModel: [{
        //    name: 'PredictionDt',
        //    index: 'PredictionDt',
        //    width: 80,
        //    sorttype: "PredictionDt", align: "center"
        //}, {
        //    name: 'DayofWeek',
        //    index: 'Day of Week',
        //    width: 70,
        //    sorttype: "string", align: "left"
        //},
        //    {
        //        name: 'SpecialDay',
        //        index: 'Special Day',
        //        width: 100, align: "left"
        //    },

        //    {
        //        name: 'PredictedFp',
        //        index: 'Predicted FP',
        //        width: 100, align: "right"
        //    },
        //    {
        //        name: 'ActualFp',
        //        index: 'Actual FP',
        //        width: 95, align: "right"
        //    }
        //],
        colNames: listOfColumnNames,
        colModel: listOfColumnModels,
        height: "auto",
        width: 600,
        cmTemplate: { editable: true, searchoptions: { clearSearch: false } },
        // rowNum: 10,
        // rowList: [5, 10, 20],
        // pager: "#SourceWeigtagegridpager",
        toppager: false,
        cloneToTop: false,
        pgbuttons: false,
        pginput: false,
        gridview: true,
        rowNum: 10000,
        shrinkToFit: false,
        autowidth: true,
        //  rownumbers: true, // show row numbers
        //rownumWidth: 25, // the width of the row numbers columns
        autoencode: true,
        ignoreCase: true,
        sortname: "Dates",
        viewrecords: true,
        sortorder: "desc",
        // caption: "Prediction Report",
        altRows: false, //Enables alternate row colors
        hoverrows: true, // true by default, can be switched to ProductCategory/GetAllCompaniesfalse if highlight on hover is not needed
        multiSort: false, // Allows multiple column sorting

    });

    jQuery('#grid').jqGrid('clearGridData');
    jQuery('#grid').jqGrid('setGridParam', { data: jsonData });
    jQuery('#grid').trigger('reloadGrid');
}

function loadSummaryGrid(jsonData) {

    var Attendacegrid = $("#SummaryGrid");
    Attendacegrid.jqGrid({
        datatype: "local",
        data: jsonData,
        colNames: ['Influencers', 'Predictor Coefficient', 'P-Value'],
        colModel: [{
            name: 'Influencers',
            index: 'Influencers',
            width: 100,
            sorttype: "Influencers", align: "left"
        }, {
            name: 'PredictorCoefficient',
            index: 'Predictor Coefficient',
            width: 100,
            sorttype: "string", align: "right"
        },
            {
                name: 'PValue',
                index: 'P-Value',
                width: 100, align: "right"
            }
        ],
        height: 500,
        width: 610,
        cmTemplate: { editable: true, searchoptions: { clearSearch: false } },
        // rowNum: 10,
        // rowList: [5, 10, 20],
        // pager: "#SourceWeigtagegridpager",
        toppager: false,
        cloneToTop: false,
        pgbuttons: false,
        pginput: false,
        gridview: true,
        rowNum: 10000,
        //  rownumbers: true, // show row numbers
        //rownumWidth: 25, // the width of the row numbers columns
        autoencode: true,
        ignoreCase: true,
        // sortname: "Date",
        viewrecords: true,
        sortorder: "desc",
        // caption: "Prediction Report",
        altRows: false, //Enables alternate row colors
        hoverrows: true, // true by default, can be switched to ProductCategory/GetAllCompaniesfalse if highlight on hover is not needed
        multiSort: false, // Allows multiple column sorting
        loadComplete: function () {
            var width = $("#SummaryGrid").width();
            $(".ui-jqgrid-bdiv").css({ "width": width + 20 });
            $(".ui-jqgrid-hdiv").css({ "width": width + 20 });
            $(".ui-jqgrid-toppager").css({ "width": width + 2 });
        }
    });

    jQuery('#SummaryGrid').jqGrid('clearGridData');
    jQuery('#SummaryGrid').jqGrid('setGridParam', { data: jsonData });
    jQuery('#SummaryGrid').trigger('reloadGrid');
}




function TatvamObjectToJsonConvert(searchResults) {
    var gidData = JSON.stringify(searchResults);
    var jsonData = jQuery.parseJSON(gidData);
    return jsonData;
}

function OnMenuClick(reportCategoryId, reportName) {
    showLoadingCursor();
    $('#hdn_reportid_page').val(reportCategoryId);
    sessionStorage.setItem("ReportId", reportCategoryId);
    sessionStorage.setItem("reportName", reportName);     //------value stored in the sessionstorage   
    window.location.href = "../Home/Home";
    return false;
}


function CreateTatvamAttendancePredictionChartWidget(reportDetails, chartData) {
    $('#AttendancePredictionChart').empty();
    if (chartData === null || chartData.length === 0) {
        $('#AttendancePredictionChart').append("<div class='nodata'>No Data Available.</div>");
        return;
    }
    var min, max;

    var objReportDetails = jQuery.parseJSON(reportDetails.ReportDetail.ReportDetails);

    var xrangemin = objReportDetails.xrangemin;
    var xrangemax = objReportDetails.xrangemax;

    var dataSetres = GetAttendancePredictionChartData(chartData);
    var value = GetYaxisMaxValue(dataSetres[0].maxValue);

    var dtick = value[0].dtick;
    // dtick = 5;
    var lineChartdata = dataSetres[0].dataset;
    var xmax = 12;
    if (lineChartdata[0].x.length < xmax)
        xmax = lineChartdata[0].x.length;
    max = value[0].max + 500;
    min = dataSetres[0].minValue - 1000;
   
    if (min <= 0)
    {
        min = 0;
    }

    var layout = {
        height: 390,
        title: '',
        showlegend: true,
        barmode: 'group',
        yaxis: {
            title: "# of Visitors",
            showline: true,
            showgrid: false,
            range: [0, max],
            tickformat: '0f',
            fixedrange: true, ticks: 'outside', tickwidth: '1'
        },
        //xaxis: {
        //    title: 'Date', showline: true, showgrid: true, type: 'category', range: [xrangemin, xrangemax], ticks: 'outside', tickwidth: '1',tickangle : -50,
        //    tickvals: ["28-Mar-16", "29-Mar-16", "30-Mar-16", "01-Apr-16", "02-Apr-16", "03-Apr-16", "04-Apr-16", "05-Apr-16", "06-Apr-16", "07-Apr-16", "08-Apr-16", "09-Apr-16", "10-Apr-16", "11-Apr-16", "12-Apr-16", "13-Apr-16", "14-Apr-16", "15-Apr-16", "16-Apr-16", "17-Apr-16", "18-Apr-16", "19-Apr-16", "20-Apr-16", "21-Apr-16", "22-Apr-16", "23-Apr-16", "24-Apr-16", "25-Apr-16", "26-Apr-16", "27-Apr-16", "28-Apr-16", "29-Apr-16", "30-Apr-16", "01-May-16", "02-May-16", "03-May-16", "04-May-16", "05-May-16", "06-May-16", "07-May-16", "08-May-16"],
        //    ticktext: ["28-Mar-16", "29-Mar-16", "30-Mar-16", "01-Apr-16", "02-Apr-16", "03-Apr-16", "04-Apr-16", "05-Apr-16", "06-Apr-16", "07-Apr-16", "08-Apr-16", "09-Apr-16", "10-Apr-16", "11-Apr-16", "12-Apr-16", "13-Apr-16", "14-Apr-16", "15-Apr-16", "16-Apr-16", "<span style=\"fill:red\">17-Apr-16</span>", "18-Apr-16", "19-Apr-16", "20-Apr-16", "21-Apr-16", "22-Apr-16", "<span style=\"fill:red\">23-Apr-16</span>", "24-Apr-16", "25-Apr-16", "26-Apr-16", "27-Apr-16", "28-Apr-16", "29-Apr-16", "30-Apr-16", "01-May-16", "02-May-16", "03-May-16", "04-May-16", "05-May-16", "06-May-16", "07-May-16", "08-May-16"]
        //},

        xaxis: { title: 'Date', showline: true, showgrid: false, type: 'category', ticks: 'outside', range: [lineChartdata[0].x.length, lineChartdata[0].x.length] + 30, tickangle: -50 },
        margin: {
            l: 70,
            r: 80,
            b: 100,
            pad: 0,
            t: 40
        },
        bargap: 0.15,
        bargroupgap: 0.99,
        legend: {
            y: 1.3,
            x: 1,
            orientation: 'h',
            xanchor: "right", borderwidth: 0, bordercolor: "#ffffff",
        }
    };


    lineChartdata.forEach(function (trace) {
        trace.text = trace.y.map(function (v, i) {
            var hoverValue = v;
            if (trace.name === 'Current Date')
                return null;
            if (v !== 0)
                hoverValue = trace.name + "<br>(" + trace.x[i] + "," + v + ")";
            return hoverValue || null;
        });
        trace.hoverinfo = 'text';
    });

    Plotly.newPlot("AttendancePredictionChart", lineChartdata, layout, {
        displaylogo: false,
        displayModeBar: false
    });
}
var maxValue = 0;
function GetAttendancePredictionChartData(chartData) {

    var dataset = [];
    var minValue = 0;
    for (var i = 0; i < chartData.length; i++) {
        var x = [];
        var y = [];
        var text = [];
        for (var j = 0; j < chartData[i].DataValues.length; j++) {
            if (minValue === 0)
                minValue = chartData[i].DataValues[j].YAxisValues;
            //   if (parseFloat(chartData[i].DataValues[j].YAxisValues) !== 0) {
            if (maxValue < chartData[i].DataValues[j].YAxisValues)
                maxValue = chartData[i].DataValues[j].YAxisValues;
            if (minValue > chartData[i].DataValues[j].YAxisValues)
                minValue = chartData[i].DataValues[j].YAxisValues;
            x.push(chartData[i].DataValues[j].XAxisValues);
            y.push(parseFloat(chartData[i].DataValues[j].YAxisValues));
            text.push(chartData[i].DataValues[j].XAxisValues);
            // }
        }
        var color = "#FFCA08";
        var width = 2;
        var dash = 'solid';
        var size = 5;
        if (chartData[i].DataSeries === "Actual") {
            color = "#50A6DF";
            width = 2;
            dash = 'solid';
            size = 10;
        }
        else {
            color = '#76DEFB';
            width = 2,
            dash = 'solid';
            size = 10;
        }

        dataset.push({
            type: 'scatter',
            marker: {
                symbol: "circle",
                size: 10,
                colors: color,
                color: "rgb(255, 255, 255)",
                line: {
                    width: 2,
                    color: color
                }
            },
            x: x,
            y: y,
            text: text,
            name: chartData[i].DataSeries,
            mode: "lines+markers",
            line: {
                shape: "linear", //linear/spline/hv/vh/hvh/vhv
                dash: "solid", //solid/dot/dash/longdash/dashdot/longdashdot                
                width: width,
                colors: color,
                color: color
            }
        });
    }

    var currentDate = new Date();
    var day = currentDate.getDate();
    if (day.toString().length == 1)
        day = "0" + day;
    var month = currentDate.getMonth() + 1;
    if (month.toString().length == 1)
        month = "0" + month;
    var year = currentDate.getFullYear();
    var date = month + "-" + day + "-" + year;
    dataset.push({
        name: "Current Date",
        type: 'bar',
        line: {
            color: "rgb(255,65,54)",
            width: 1
        },
        mode: "markers",
        showlegend: false,
        x: [date],
        y: [maxValue],
        text: [date],
        marker: {
            color: "rgb(255,65,54)",
            line: {
                color: "#FF6261",
                width: 1
            },
            opacity: 1
        }




    });


    return [{ dataset: dataset, maxValue: maxValue, minValue: minValue }];
}

function getYearList(input) {

    var noofYears = input;
    var currentTime = new Date();
    var year = currentTime.getFullYear();
    var YearList = [];
    for (var i = 1; i <= noofYears; i++) {
        year = year - 1;
        YearList.push(year);

    }
    return YearList;
}


function getFormattedDate(input) {
    var sptdate = String(input).split("-");
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var myMonth = sptdate[1];
    var myDay = sptdate[2];
    var myYear = sptdate[0];
    var combineDatestr = myDay + "-" + months[myMonth - 1] + "-" + myYear;
    return combineDatestr;
}

function PredictData() {

    var fromdt = getFormattedDate($("#fromdate").val());
    //  var yearList = getYearList($("#Years").val());
    if (ValidateAttendancePredictionForm()) {
        showLoadingCursor();
        $.ajax({
            type: "POST",
            url: getPrediction_CallURL,
            data: { Year: $("#Years").val(), FromDate: fromdt, Days: $("#days").val(), Modelname: $("#ddlmodel").val(), Influencers: chk_Influencers },
            success: function (searchResults) {

                if (searchResults.Error !== null) {
                    TatvamAlert(searchResults.Error, "Error");
                }
                else {

                    if (searchResults.APLstChartModel === undefined) {
                        if (searchResults.indexOf("<title>SessionTimeOut</title>") > -1) {

                            window.location.href = "../SessionTimeOut/SessionTimeOut";
                        }
                        else {

                            EnablePredictedControls();
                            FillPredictControls(searchResults);
                        }
                    }
                    else {

                        EnablePredictedControls();
                        FillPredictControls(searchResults);
                    }
                }
                chkDaysForGA();

            },
            error: function (xhr, status, p3, p4) {
                hideLoadingCursor();
                var error = JSON.parse(xhr.responseText)
                TatvamAlert(error, "Error");
            }
        });
        setTimeout(function () { hideLoadingCursor(); }, 3000);
    }
}

function FillPredictControls(searchResults) {
    if (searchResults.Error !== null) {
        TatvamAlert(searchResults.Error, "Error");
    }
    else {
        var jsonData = TatvamObjectToJsonConvert(searchResults.LstAttendancePredictionGridDo);
        var jsonSummaryData = TatvamObjectToJsonConvert(searchResults.LstAttendancePredictionSummaryGridDo);
        loadGrid(jsonData);
        //loadSummaryGrid(jsonSummaryData);
        var displayText = searchResults.PredictedSummary.split(',');
        //  var displayText = searchResults.PredictedSummary.replace(/ /g, '&nbsp;');
        // displayText = displayText.replace(/\n/g, '<br />');
        //$("#summarySection").empty();
        //$("#summarySection").html(displayText);
        $("#lbl1").empty();
        $("#lbl1").html(displayText[0]);
        $("#lbl2").empty();
        $("#lbl2").html(displayText[1]);
        if (jsonData.length === 0)
            $("#Grid").append('<div class=\'nodata\' style="width: 200px;">No Data Available.</div>');

        var model = {
            "Report": { "ChartType": "LineChart", "Emailid": null, "Icon": "", "ObjDetailDo": null, "ParentId": 64, "ReportCategory": "Actual Vs Prediction", "ReportCategoryId": 66, "ReportType": "Chart", "SequenceNo": "2", "SubReportCollection": [], "ReportDetail": { "CornerRadius": 0, "DonutLabelOutside": false, "HalfCircle": false, "IsGrouped": "1", "IsStacked": "1", "LegendPosition": "", "ReportId": null, "ReportSubTitle": "Attendance Prediction", "RotationLabel": "-90", "ShowLabel": false, "ShowLegend": false, "Spacing": "", "Status": null, "ValueType": "", "XAxisCaption": "", "XAxisFormat": "", "Y0AxisCaption": "# of Visitors", "Y0AxisFormat": "", "Y1AxisCaption": "", "Y1AxisFormat": "", "IsCompetitor": false, "IsLoadDefault": false, "Y0AxisMin": 0, "Y0AxisMax": 100, "Y1AxisMin": 0, "Y1AxisMax": 0, "ReportDetails": "{\"iscontinuous\": false,\"xrangemin\": 10,\"xrangemax\": 30}", "CreatedBy": null, "CreatedDate": null, "ModifiedBy": null, "ModifiedCount": 0, "ModifiedDate": null }, "CreatedBy": null, "CreatedDate": null, "ModifiedBy": null, "ModifiedCount": 0, "ModifiedDate": null }
        };

        CreateTatvamAttendancePredictionChartWidget(model.Report, searchResults.APLstChartModel);
    }
}

$(".tatvamCheckboxContent").delegate("input[type='checkbox'],input[type='number'],input[type='text'], select", 'change', function () {

    var $this = $(this);
    $("#btnReset").prop("disabled", false);
    if ($this.attr("name") === 'chkInfluencers') {
        if ($this.prop('checked'))
            chk_Influencers.push($this.attr('value'));
        else {
            chk_Influencers = jQuery.grep(chk_Influencers, function (value) {
                return value !== $this.attr('value');
            });
        }
    }

    if ($("#Years").val().trim() !== '' && $("#days").val().trim() !== '' && $("#fromdate").val().trim() !== '') {
        EnableButtonOnDataChange();
    } else {
        DisableButtonOnDataChange();
    }
});

$("#btnNew").button().on("click", function () {
    $("#PredictAttendanceForm").show();
    $("#btndiscard").show();
    $("#modelControls").hide();
    $("#btnNew").hide();

    EnableAttendancePredictionFormControls();
    $("#modelControls").hide();
    ResetControls();

});

$("#btnsaveModel").click(function () {

    var retVal = ValidateAttendancePredictionForm();
    if (retVal) {
        CallAttendancePredictionCreateDialog();

        var modelName = $("#ddlmodel").val();
        var lblDefault = $("#lbldefault").text();
        if (modelName !== null)
            $("#txtModelName").val(modelName); // bind the dropdown value

        if (lblDefault !== "")
            $('#chk_default').prop("checked", true);
    }
});

$("#btnPredict").click(function () {

    PredictData();

});

$("#btndiscard").click(function () {

    if (chk_Influencers.length !== 0 || $("#Years").val().trim() !== "1" || $("#days").val().trim() !== '10') {
        bootbox.confirm({
            title: "Are you sure. You want to discard Changes.",
            message: "Warning",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-default'
                }
            },
            callback: function (result) {
                if (result) {
                    $(this).modal('hide');
                    window.location.reload(true);
                } else {
                    $(this).modal('hide');
                }
            }
        })
    }
    else {
        $("#btnNew").show();
        $("#btndiscard").hide();
        if ($('#ddlmodel').has('option').length === 0) {
            $("#modelControls").hide();
            $("#PredictAttendanceForm").hide();
        }
        else {
            $("#modelControls").show();
            $("#PredictAttendanceForm").show();
        }
    }
});


$("#btnReset").click(function () {
    bootbox.confirm({
        title: "Are you sure. You want to reset the model?",
        message: "Warning",
        buttons: {
            confirm: {
                label: 'Ok',
                className: 'btn-primary'
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                $(this).modal('hide');
                if ($("#ddlmodel").val() !== null) {
                    ViewModel($("#ddlmodel").val());
                } else {
                    ResetControls();
                }
                $("#btnNew").show();
                $("#btndiscard").hide();
                $("#modelControls").show();
            } else {
                $(this).modal('hide');
            }
        }

    })

});


$("#txtModelName").keypress(function (e) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var key = value;

    if (!regex.test(key)) {
        e.preventDefault();
    }
});

$("#days").keydown(function (event) {
    $("#btnReset").prop("disabled", false);
    // Allow only backspace and delete
    if (event.keyCode === 46 || event.keyCode === 8) {
        // let it happen, don't do anything
    }
    else {
        // Ensure that it is a number and stop the keypress
        if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
            event.preventDefault();
        }
    }
});

function storeValue(key, value) {
    if (localStorage) {
        localStorage.setItem(key, value);
    } else {
        $.cookies.set(key, value);
    }
}

function getStoredValue(key) {
    if (localStorage) {
        return localStorage.getItem(key);
    } else {
        return $.cookies.get(key);
    }
}
