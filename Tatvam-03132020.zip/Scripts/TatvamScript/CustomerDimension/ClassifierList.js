﻿//string constants used for this module
var classifierListConstants = {
    elementIDConstant: {
        treeViewID: "#treeview"
    },
    columnValues:
        {
            countOfPositiveReviews: "countOfPositiveReviews",
            countOfNegativeReviews: "countOfNegativeReviews",
            countOfNeutralReviews: "countOfNeutralReviews"
        },
    columnHeaders:
        {
            PositiveReviews: "Positive Reviews",
            NegativeReviews: "Negative Reviews",
            NeutralReviews: "Neutral Reviews",
            Classifier: "Classifiers"
        },
    states: {
        opened: "opened"
    },
    columnWidth: {
        width: 130,
        auto:'auto'
    },
    messages: {
        noDataAvailable: "<div class=\'nodata\'>No Data Available.</div>",
    },
    treeConfig: {
        state: "state"
    }
}
//on document ready, following steps are executed
$(document).ready(function () {
    //To-Do: Need to review the code
    var classifierListArr = [];
    //iterate the model and include it an array
    for (var i = 0; i < classifierListModel.length; i++) {
        //method to set state to 'open' so that basenode expands to first level
        setObjProp(classifierListModel[i], classifierListConstants.treeConfig.state, classifierListConstants.states.opened, true);
        classifierListArr.push(classifierListModel[i]);
    }
    // call method to display treetable
    DisplayTreeView(classifierListArr);
});

//Funtion for displaying the details of categories and their classifiers
function DisplayTreeView(treeData) {
    //check for treedata length, if no data then display no data message.
    if (treeData.length === 0) {
        $(classifierListConstants.elementIDConstant.treeViewID).append(classifierListConstants.messages.noDataAvailable);
        return;
    }
    //bind treedata with the needed jstree configuration like core, sort,table etc..
    $(classifierListConstants.elementIDConstant.treeViewID)
        .jstree({
            "core": {
                "multiple": false,
                'data': treeData //Data Binded to tree
            },
            "plugins":
            [
                , "sort" //automatically arranges all sibling nodes defaults to alphabetical order.
                , "table" //For creating a table 
            ],
            // configure tree table
            table: {
                columns: [
                    {
                        //width defines column width of treetable
                        width: classifierListConstants.columnWidth.auto,
                        header: classifierListConstants.columnHeaders.Classifier,
                    },

                    {
                        //width defines column width of treetable
                        width: classifierListConstants.columnWidth.width,
                        //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
                        //this is the value to bind to the header
                        value: classifierListConstants.columnValues.countOfPositiveReviews,
                        // string to use as a header for the column like "Positive Reviews"
                        header: classifierListConstants.columnHeaders.PositiveReviews,

                    }
                    ,
                    {
                        //width defines column width of treetable
                        width: classifierListConstants.columnWidth.width,
                        //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
                        //this is the value to bind to the header
                        value: classifierListConstants.columnValues.countOfNegativeReviews,
                        // string to use as a header for the column lke "Negative Reviews"
                        header: classifierListConstants.columnHeaders.NegativeReviews,

                    },
                    { //width defines column width of treetable
                        width: classifierListConstants.columnWidth.width,
                        //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
                        //this is the value to bind to the header
                        value: classifierListConstants.columnValues.countOfNeutralReviews,
                        // string to use as a header for the column lke "Neutral Reviews"
                        header: classifierListConstants.columnHeaders.NeutralReviews,

                    }
                ]
            }
        });
}



