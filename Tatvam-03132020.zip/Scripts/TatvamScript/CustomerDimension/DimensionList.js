﻿//string constants used for this module
var dimensionListConstants = {
    elementIDConstant: {
        treeViewID: "#treeview",
        ddlCustomerDimensionsId: "#ddlCustomerDimensions"
    },

    states: {
        opened: "opened"
    },
    columnWidth: {
        width: 400,
        auto: 'auto'
    },
    messages: {
        noDataAvailable: "<div class=\'nodata\'>No Data Available.</div>",
    },
    treeConfig: {
        state: "state"
    },
    httpMethods: {
        get: "GET"
    },
    url: {
        customerDimensionList: "../CustomerDimension/CustomerDimensions",
        dimensionListTreeTableUrl: "../CustomerDimension/DimensionListTreetable"
    },
    columnHeaders:
       {
           header: 'Dimensions',

       },
    columnSelectors:
        {
            valueSelector: 'source_entity_type',
            textSelector: 'target_entity_type'
        },
};

//on document ready, following steps are executed
$(document).ready(function () {
    BindCustomerDimensions(customerDimensionList);
});



//Funtion for displaying the details of categories and their classifiers
function DisplayTreeView(treeData) {
    //check for treedata length, if no data then display no data message.
    if (treeData.length === 0) {
        $(dimensionListConstants.elementIDConstant.treeViewID).append(dimensionListConstants.messages.noDataAvailable);
        return;
    }
    var columns = [];

    // on change of dimensions refresh  treelist
    if ($(dimensionListConstants.elementIDConstant.treeViewID).jstree(true).settings) {

        $(dimensionListConstants.elementIDConstant.treeViewID).jstree(true).settings.core.data = {};
        $(dimensionListConstants.elementIDConstant.treeViewID).jstree(true).settings.core.data = treeData;
        $(dimensionListConstants.elementIDConstant.treeViewID).jstree(true).refresh();
    } else {

        // Create  columns and push the respective column values  

        columns.push({
            width: dimensionListConstants.columnWidth.auto,
            header: dimensionListConstants.columnHeaders.header, //string to use as a header for the column                 
        })
        // get column names 
        var propNames = Object.getOwnPropertyNames(treeData[0].data);
        var orderedColumns = GetOrderedColumns(propNames);

        for (var i = 0; i < orderedColumns.length; i++) {

            columns.push({

                header: orderedColumns[i], //string to use as a header for the column.          
                value: orderedColumns[i], //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.

            })
        }
        //bind treedata with the needed jstree configuration like core, sort,table etc..
        $(dimensionListConstants.elementIDConstant.treeViewID)
            .jstree({
                "core": {
                    "multiple": false,
                    'data': treeData //Data Binded to tree
                },
                "plugins":
                [
                    "core"
                    , "ui"
                    , "sort" //automatically arranges all sibling nodes defaults to alphabetical order.
                    , "table" //For creating a table 
                ],

                table: {
                    //width: width ,// for the entire jstree-table. If no width is given, automatically fills the entire viewport (width: 100%;)
                   // height: height ,//for the entire jstree-table. If no height is given, height will reflect the amount of content.
                    fixedHeader: true,//false. If true, then when the tree is scrolled the column headers will remain visible. Defaults to true.
                    //columnWidth:,// default width for a column for which no width is given. If no width is given, the default is auto.
                    columns: columns,
                    resizable: true,//false if the columns should be resizable. Defaults to false.
                    draggable: true,//false if the columns should be draggable (requires jQuery UI with sortable plugin). Defaults to false.
                    stateful: true,//false. If true, then whenever a column width is resized, it will store it in html5 localStorage, if available. Defaults to false.
                    contextmenu: true,//false whether or not a context menu for editing the cells should be shown on right-click. Defaults to false.
                    headerContextMenu: true,//false whether or not a context menu for managing columns should be shown on right-click. Defaults to true.
                    //checkIcon: ,//class for the context menu check icons. Defaults to 'fa fa-check' (Font Awesome).
                    //arrowUpIcon: ,//class for the up arrow icon. Defaults to 'fa fa-chevron-up' (Font Awesome).
                    //arrowDownIcon: ,//class for the down arrow icon. Defaults to 'fa fa-chevron-down' (Font Awesome).
                },
            });

        //TO-DO: need to handle horizontal scroll appropriately
        $(".jstree-table-wrapper").css("overflow-x", "scroll");

        setTimeout(function () {
            var height = $(".treeview").height();
            $('#widgets').css({ "height": height + "px" });
            var gridster = $('.gridster ul#widgets').gridster().data('gridster');
            var widgetObj = gridster.$widgets.closest("#" + gridster.$widgets[0].id);
            var sizex = widgetObj.attr("data-sizex");
            var sizey = Math.ceil(height / 128);
            gridster.resize_widget(widgetObj, sizex, sizey, function (obj1, obj2) { });
        }, 2000);
    }
}

// bind dimensions according the customer
function BindCustomerDimensions(CustomerDimensions) {
    var controlObj = $(dimensionListConstants.elementIDConstant.ddlCustomerDimensionsId);

    var ddlOptions = {
        controlObj: controlObj,
        list: CustomerDimensions,
        valueSelector: dimensionListConstants.columnSelectors.valueSelector,
        textSelector: dimensionListConstants.columnSelectors.textSelector
    };
    PopulateDdlOptions(ddlOptions);
    $('#ddlCustomerDimensions').on('change', function (e) {
        $('#ddlCustomerDimensions option').removeAttr("selected", "selected");
        $('#ddlCustomerDimensions option:selected').attr("selected", "selected");
        LoadDimensionTreeTable();
    });

    //call to get Dimensionstreedata
    LoadDimensionTreeTable();
}
function LoadDimensionTreeTable() {
    showLoadingCursor();
    //selected text from drop down
    var selectedValue = $(dimensionListConstants.elementIDConstant.ddlCustomerDimensionsId).find("option:selected").text();

    //value of the selected dropdown text
    var selectedText = $(dimensionListConstants.elementIDConstant.ddlCustomerDimensionsId).find("option:selected").val();

    var data = { "inpParentType": selectedText, "inpChildType": selectedValue, "reportId": sessionStorage.ReportId }
    // call to get dimension list
    $.ajax({
        url: dimensionListConstants.url.dimensionListTreeTableUrl,
        type: dimensionListConstants.httpMethods.get,
        data: data,
        success: function (result) {
            result = JSON.parse(result);
            // draw dimension treetable based on dimension selected from dropdown
            BuildDimensionTreeTable(result, selectedValue);
            hideLoadingCursor();
        },
        error: function (xhr, status, p3, p4) {
            hideLoadingCursor();
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function BuildDimensionTreeTable(DimensionListModel) {
    //To-Do: Need to review the code
    var DimensionListArr = [];
    //iterate the model and include it an array
    for (var i = 0; i < DimensionListModel.length; i++) {
        //method to set state to 'open' so that basenode expands to first level
        setObjProp(DimensionListModel[i], dimensionListConstants.treeConfig.state, dimensionListConstants.states.opened, true);
        DimensionListArr.push(DimensionListModel[i]);
    }
    // call method to display treetable
    DisplayTreeView(DimensionListArr);
}

function GetOrderedColumns(inputColumns) {
    var columns = [];

    if (!inputColumns || inputColumns.length === 0) {
        return columns;
    }

    //Value -> Parse the value as integer of the first property
    var val = parseInt(inputColumns[0]);

    //Check whether Value is a number
    //if value is numeric
    if (!isNaN(val)) {

        var numericColumns = [];
        var nonNumericColumns = [];

        for (var index = 0; index < inputColumns.length; index++) {

            //if numeric, then add to numeric columns
            var val = parseInt(inputColumns[index]);
            if (!isNaN(val)) {
                numericColumns.push(inputColumns[index]);
            }
            else {
                //non numeric columns
                nonNumericColumns.push(inputColumns[index]);
            }
        }

        //concat both non-numeric and numeric into columns
        for (var index = 0; index < nonNumericColumns.length; index++) {
            columns.push(nonNumericColumns[index]);
        }
        for (var index = 0; index < numericColumns.length; index++) {
            columns.push(numericColumns[index]);
        }
    }
    else {
        columns = inputColumns;
    }

    return columns;
}