﻿
//string constants used for this module
var classifierMgmtConstants = {
    elementIDConstant: {
        treeViewID: "#treeview",
        btnSaveID: "#btn_submit",
        dialogConfirmID: "#dialog-confirm"
    },
    classConstant: {
        treeViewContextMenuClass: ".jstree-contextmenu",
        treeViewAnchorClass: '.jstree-anchor',
        treeClickClass: '.jstree-clicked',
        hideTreeNode: 'hide-tree-node-mgmt'
    },
    messages: {
        duplicateClassifierNotAllowed: "already available.Duplicate Classifier not allowed",
        selectKeyWordtoDelete: "Select any keyword before proceeding with the deletion.",
        noDataAvailable: "<div class=\'nodata\'>No Data Available.</div>",
        successfullySaved: "Data Saved Succesfully.",
        failedToSave: "Data not Saved",
        OnDeletion: "record ?"

    },
    scripts: {
        jstree: '../Scripts/jstree.min.js'
    },
    url: {
        saveDimension: '../CustomerDimension/SaveClassifierDimensionManagementTreeview'
    },
    icons:
        {
            starIcon: '../Content/Images/star.png',
            treeIcon: '../Content/Images/tree-icon.png',
            leafIcon: '../Content/Images/leaf_icon.png',
        },
    keywords: {
        newNodeOnCreate: 'New Classifier',
        alertBox: "Alert Box",
        treeViewColumnHeader: "Classifiers",
        classifier: "Classifier",
        // deletion: "On Deletion of the "
        deletion: "Are you sure you want to delete "
    },
    jstreeConfiguration: {
        create: "Create",
        rename: "Rename",
        delete: "Delete",
        maxChildren: 1,
        maxDepth: 10,
        parentnode: "#",
        moveNode: "move_node"
    },
    nodeStatus: {
        added: 0,
        renamed: 1,
        removed: 2,
        moved: 3
    },
    levels: {
        one: 1
    },
    states: {
        opened: "opened"
    },
    treeConfig: {
        state: "state"
    }
}

//on document ready, following steps are executed

$(document).ready(function () {    
    var classifierArr = [];
    //iterate the model and include this in an array.
    //TO-DO: need to check whether this step is mandatory.          
    for (var i = 0; i < classifierTreeModel.length; i++) {
        //method to set the state to 'open' so that base node expands to first level.
        setObjProp(classifierTreeModel[i], classifierMgmtConstants.treeConfig.state, classifierMgmtConstants.states.opened, true);
        classifierArr.push(classifierTreeModel[i]);
    }
    
    //call method to display the tree view.
    DisplayTreeView(classifierArr);
});


//close the context menu on clicking any node in the tree view.
//TO-DO: May be clicking outside tree view should close the context menu.
$(classifierMgmtConstants.elementIDConstant.treeViewID).click(function () {
    $(classifierMgmtConstants.classConstant.treeViewContextMenuClass).css("display", "none");
});

//TO-DO: Need to verify the usage of below global variables and then use it locally or remove accoridingly.
var deleteid = "";
var retval = 1;
var Parents, Parent, Childrens, Nodeid, nodeLevel;

//Funtion for displaying the classifiers
function DisplayTreeView(treeData) {

    /**
   *  if there is no treedata then display as "no data available"
   *  else
   * bind the treedata to treeview
   * @param {} treedata 
   * 
   */
    //check for treedata length, if no data then display no data message.
    if (treeData.length === 0) {
        $(classifierMgmtConstants.elementIDConstant.treeViewID).empty();
        $(classifierMgmtConstants.elementIDConstant.treeViewID).append(classifierMgmtConstants.messages.noDataAvailable);
    }
    else {
        //bind treedata with the needed jstree configuration like core, types etc...
        $.getScript(classifierMgmtConstants.scripts.jstree, function () {
            $(classifierMgmtConstants.elementIDConstant.treeViewID)
                .bind("select_node.jstree", function (e, data) {
                    nodeLevel = data.node.parents.length;
                })
                .jstree({
                    "core": {
                        "multiple": false,
                        "check_callback": true, // so that create works
                        strings: {
                            //name for any any new node creation
                            'New node': classifierMgmtConstants.keywords.newNodeOnCreate
                        },
                        "open_parents": true,
                        "force_text": true,
                        'data': treeData,
                        'error': function (err) {

                            var dialogMessage;

                            // check for duplicates at node
                            if (err.plugin === "unique" || err.plugin === "core" || err.plugin === "types") {
                                if ((err.id === 'unique_01' || err.id === 'unique_03')) {

                                    //setting duplicate message
                                    dialogMessage = classifierMgmtConstants.keywords.classifier + " '" +
                                        jQuery.parseJSON(err.data).pos.fontcolor("red") + "' " +
                                        classifierMgmtConstants.messages.duplicateClassifierNotAllowed;
                                }

                                if (!dialogMessage) {
                                    return;
                                }
                                //displaying dialog for duplicate message
                                bootbox.alert({
                                    title: classifierMgmtConstants.keywords.alertBox,
                                    message: dialogMessage,
                                    buttons: {
                                        ok: {
                                            label: 'Ok',
                                            className: 'btn-primary'
                                        }
                                    },
                                    callback: function () {
                                        $(this).modal('hide');
                                    }
                                })
                               
                            }
                        },

                        //callback called when there is change in the hierarchy
                        'check_callback': function (operation, node, nodeParent, node_position, more) {
                            //if the operation is move node, then change the id of the current node.
                            //TO-DO: need to understand and add more details to this.
                            if (operation === classifierMgmtConstants.jstreeConfiguration.moveNode) {
                                return nodeParent.id !== classifierMgmtConstants.jstreeConfiguration.parentnode;
                            }
                            return true;
                        }

                    },
                    //used for displaying icons on creation of node
                    //TO-DO: need to add more details to this for better understanding.
                    "types": {
                        "#": {
                            "max_children": classifierMgmtConstants.jstreeConfiguration.maxChildren,
                            "max_depth": classifierMgmtConstants.jstreeConfiguration.maxDepth
                            //"valid_children": ["root"]
                        },
                        "root": {
                            //'icon': classifierMgmtConstants.icons.starIcon
                            //"valid_children": ["default"]
                        },
                        "default": {
                            //'icon': ""
                            //"valid_children": ["default", "file"]
                        },
                        "file": {
                            //"icon": classifierMgmtConstants.icons.leafIcon
                            //"valid_children": []
                        }
                    },
                    //right click nodes and shows a list of configurable actions in a menu
                    'contextmenu': {
                        "select_node": true,
                        "items": function (node) {

                            return {
                                "create": { // creation of new node upon right click of node
                                    "separator_after": true,
                                    "label": classifierMgmtConstants.jstreeConfiguration.create,
                                    "action": function (data) {
                                        //call function to create a node
                                        ClassifierCreate();
                                    }
                                },
                                "rename": { // rename of  node upon right click of node
                                    "label": classifierMgmtConstants.jstreeConfiguration.rename,
                                    "shortcut_label": 'F2',
                                    "action": function (data) {
                                        //call function to rename a node
                                        ClassifierRename();
                                    }
                                },
                                "Delete": {// deletion of new node upon right click of node
                                    "label": classifierMgmtConstants.jstreeConfiguration.delete,
                                    "action": function (data) {
                                        //call function to remove the node
                                        ClassifierDelete();
                                    }
                                }
                            }

                        }
                    },
                    // drag and drop of node
                    "dnd": {
                        "is_draggable": function (node) {
                            if (node[0].parent === classifierMgmtConstants.jstreeConfiguration.parentnode) {
                                return false;
                            } else {
                                return true;
                            }
                        },
                        "drag_selection": true
                    },

                    "plugins":
                        [
                        'contextmenu' //This plugin makes it possible to right click nodes and shows a list of configurable actions in a menu.
                        , "dnd"// The dnd plugin enables drag'n'drop support for jstree, also using foreign nodes and drop targets.
                        , "types"//This plugin makes it possible to add predefined types for groups of nodes, which means to easily control nesting rules and icon for each group.
                        , "unique" //Enforces that no nodes with the same name can coexist as siblings. This plugin has no options, it just prevents renaming and moving nodes to a parent, which already contains a node with the same name
                        , "sort" //automatically arranges all sibling nodes defaults to alphabetical order.
                        , "table" //For creating a table 
                        ],
                    // configure tree table
                    table: {
                        columns: [
                            {
                                width: 'auto',
                                header: classifierMgmtConstants.keywords.treeViewColumnHeader,
                            }
                        ],
                        resizable: true,
                        contextmenu: true,
                        draggable: true
                    }
                }).bind('loaded.jstree', function (event, data) {

                    //get jstree instance
                    var jstTreeInstance = $(classifierMgmtConstants.elementIDConstant.treeViewID).jstree(true);

                    //get all the nodes
                    var allNodes = jstTreeInstance.get_json(classifierMgmtConstants.jstreeConfiguration.parentnode, { flat: true });

                    //iterate and then hide only the nodes which are marked as removed.
                    for (var index = 0; index < allNodes.length; index++) {
                        if (allNodes[index].data && allNodes[index].data.flag && allNodes[index].data.flag === classifierMgmtConstants.nodeStatus.removed) {
                            var node = jstTreeInstance.get_node(allNodes[index].id);
                            node.li_attr.class = classifierMgmtConstants.classConstant.hideTreeNode;
                            // hide the node which have nodeStatus (removed=2) on page load
                            $(classifierMgmtConstants.jstreeConfiguration.parentnode + allNodes[index].id).hide();
                        }
                    }
                }).bind("move_node.jstree", function (e, data) {
                    // set moved status on hierarchy change.
                    // Don't consider setting flag value if the dimension/node is created newly and renamed.
                    var flag = (data && data.node && data.node.data && data.node.data.flag) ? data.node.data.flag : -1;
                    if ((data.parent !== data.old_parent) && (data.node.data.flag !== classifierMgmtConstants.nodeStatus.added) &&
                         (flag !== classifierMgmtConstants.nodeStatus.removed)) {
                        data.node.data = { "flag": classifierMgmtConstants.nodeStatus.moved };
                    }
                });
        });
    }

    //this is a callback which is run on each action on the node, including the click
    function bind_node(event, data) {
        Parents = data.node.parent;
        Childrens = data.node.children_d;
    }

    //TO-DO: Need to check this.
    //$(classifierMgmtConstants.elementIDConstant.treeViewID).data().jstree
}

//Create  New node
function ClassifierCreate() {

    //get the instance of the jstree
    var ref = $(classifierMgmtConstants.elementIDConstant.treeViewID).jstree(true);

    //get the ID of the selected node.
    var sel = ref.get_selected();

    var index = sel[0].indexOf('j');

    if (!sel.length) {
        return false;
    }

    //create a node 
    sel = sel[0];
    if (nodeLevel == classifierMgmtConstants.levels.one) {
        sel = ref.create_node(sel, { "type": "default" });
    }
    else {
        sel = ref.create_node(sel, { "type": "file" });
    }
    ref.get_node(sel).data = { "flag": classifierMgmtConstants.nodeStatus.added };
    ref.edit(sel);
}

//Rename  New node
function ClassifierRename() {
    //get tree instance
    var ref = $(classifierMgmtConstants.elementIDConstant.treeViewID).jstree(true);
    //get ID of current node
    var sel = ref.get_selected();

    if (!sel.length) {
        return false;
    }
    else {
        //allow to rename when only when there is some text 
        sel = sel[0];

        //mark the flag as renamed only for existing nodes and ignore flag change for newly added nodes.
        if (ref.get_node(sel).data && (ref.get_node(sel).data.flag === undefined || ref.get_node(sel).data.flag == classifierMgmtConstants.nodeStatus.renamed)) {
            ref.get_node(sel).data = { "flag": classifierMgmtConstants.nodeStatus.renamed };
        }

        ref.edit(sel);
    }
}

//Delete  Node
function ClassifierDelete() {
    //get tree instance
    var ref = $(classifierMgmtConstants.elementIDConstant.treeViewID).jstree(true);
    //get ID of current node
    var sel = ref.get_selected();

    if (sel.length === 0) {

        //set message text in confirm dialog
        //display dialog
        bootbox.confirm({
            title: classifierMgmtConstants.keywords.alertBox,
            message: classifierMgmtConstants.messages.selectKeyWordtoDelete,
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-default'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })

        //$(classifierMgmtConstants.elementIDConstant.dialogConfirmID).dialog({
        //    resizable: false,
        //    modal: true,
        //    title: classifierMgmtConstants.keywords.alertBox,
        //    height: 170,
        //    width: 350,
        //    close: function () {
        //        $(this).dialog('close');
        //    },

        //    buttons: {
        //        "Ok": function () {
        //            $(this).dialog('close');
        //        }
        //    }
        //});
    }
    else {
        //delete the selected node
        var deletedkeywords = $(classifierMgmtConstants.classConstant.treeClickClass).text().split('[');

        
        

        //display confirmation dialog
        bootbox.confirm({
            title: classifierMgmtConstants.keywords.alertBox,
            message: classifierMgmtConstants.keywords.deletion + " '  " + deletedkeywords[0].fontcolor("red") + "  ' " + classifierMgmtConstants.messages.OnDeletion,
            size: "small",
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-default'
                }
            },
            callback: function () {
                deleteid = deleteid + ',' + sel;
                if (Childrens !== undefined && Childrens.length !== 0) {
                    deleteid = deleteid + ',' + Childrens;
                }
                if (!sel.length) {
                    return false;
                }

                var currNode = ref.get_node(sel);
                //check whethe flag already exists and then only set appropriate value
                if (currNode.data.flag === undefined || currNode.data.flag > 0) {

                    //set the flag only when its existing node and the newly added node.
                    currNode.data = { "flag": classifierMgmtConstants.nodeStatus.removed };

                    // set class to hide tree node.
                    currNode.li_attr.class = classifierMgmtConstants.classConstant.hideTreeNode;
                    //hide only when its actual element otherwise remove                        
                    AddClassToElementById(sel, classifierMgmtConstants.classConstant.hideTreeNode);
                }
                else {
                    //remove the node as its newly added.
                    ref.delete_node(sel);
                }

                $(this).modal('hide');
            }
        })

    }
}

//Save Dimension, on click of save changes
$(classifierMgmtConstants.elementIDConstant.btnSaveID).click(function () {
    //get tree view data as json with hierarcy, if flat is set to true then it will be without hierarchy
    var treeViewData = $(classifierMgmtConstants.elementIDConstant.treeViewID)
                                .jstree(true).get_json(classifierMgmtConstants.jstreeConfiguration.parentnode, { flat: false });
    var strData = JSON.stringify(treeViewData).replace(/,"icon":true/g, '');
    treeViewData = JSON.parse(strData);
    //call to post the obtained json
    $.ajax({
        type: 'POST',
        url: classifierMgmtConstants.url.saveDimension,
        data: { dimensionFactCollection: treeViewData },
        success: function (result) {
            ////on successfully saving, set the confirmation dialog message and display the dialog.


            bootbox.alert({
                message: classifierMgmtConstants.messages.successfullySaved,
                title: classifierMgmtConstants.keywords.alertBox,
                size: "small",
                callback: function (result) {                   
                }
            });
        },
        //show the error message when data is failed to save.
        error: function () {
            TatvamAlert(classifierMgmtConstants.messages.failedToSave);
        }
    });
});










