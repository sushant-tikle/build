﻿var widgetCreator_CallURL = "../Home/WidgetCreator";
var sessionTimeout_CallURL = "../SessionTimeOut/SessionTimeOut";

$('.sidebar-toggler').click(function () {
    $('.search_input').val('');
    $('div ul li.start').css('display', 'block');
    if ($('.page-sidebar-closed').length) {
        $('.clear_searchinput').show();
    } else {
        $('.clear_searchinput').hide();
    }
});

$('.leftMenuOverlay').unbind('click').bind('click', function (e) {
    $('.sidebar-toggler')[0].click();
});


$('.clear_searchinput').click(function () {
    $('.search_input').val('');
    $('div ul li.start').css('display', 'block');
    $('.input-group').hide();
});


$('.input-group').hide();


$('.search_input').keyup(function () {
    $('ul .sub-menu').css('display', 'block');
    var searchText = $(this).val();
    $('#search_left ul > li').each(function () {
        var currentLiText = $(this).text(),
            showCurrentLi = currentLiText.toLowerCase().indexOf(searchText.toLowerCase()) !== -1;
        $(this).toggle(showCurrentLi);
    });
});


$('div ul li.start').click(function () {
    $(this).find('.sub-menu').slideToggle(300);
});

//* UI Sidebar window Ends Here *//

/* Height 100% for left menu Div */

var setElementHeight = function () {
    var height = $(window).height();
    $('.page-sidebar-menu').css('height', (height));
};

/* Height 100% for left menu Div Ends */

/**
 * Creating Span text
 * @param {} text 
 * @returns {} 
 */
var createTextNode = function (text) {
    var span = document.createElement("span");
    span.className = "title";
    var tx = document.createTextNode(text);
    span.appendChild(tx);
    return span;
};

var createFontAwesomeNode = function (text) {
    var i = document.createElement("i");
    i.className = text;
    return i;
};

var createliNode = function (text, icon, isarrow, id) {
    var nodeli = document.createElement("li");
    nodeli.setAttribute("id", "menu_" + id);
    var a = document.createElement("a");
    if (text === "Home Dashboard" || text === "Executive Summary") {
        a.setAttribute('onclick', 'OnMenuClick(' + id + ',"' + text + '");return false;');
        isarrow = false;
    }
    if (icon !== "") {
        a.appendChild(createFontAwesomeNode(icon));
    }
    a.appendChild(createTextNode(text)); //Append to li
    if (isarrow) {
        var span = document.createElement("span");
        span.className = "arrow";
        a.appendChild(span);
    }
    nodeli.appendChild(a);
    return nodeli;
};


/*Get User Menus*/

function buildleftmenu(models) {
    var rootUl = document.createElement("ul");
    rootUl.className = "page-sidebar-menu page-sidebar-menu-closed";
    rootUl.setAttribute('data-slide-speed', '200');
    /*Adding Menu Icon*/
    var rootNodeLi = document.createElement("li");
    rootNodeLi.className = "sidebar-toggler-wrapper customerLogoHolder";
    rootNodeLi.title = "Menu";
    //Customer Logo div
    var customerLogoDiv = document.createElement("div");
    customerLogoDiv.className = "customer_logo hiddenInitially";
    var customerLogoImage = document.createElement("img");
    customerLogoImage.src = '../content/Images/Customer/' + customerLogo;
    customerLogoImage.className = "cust_logo img-responsive center-block";
    customerLogoDiv.appendChild(customerLogoImage);
    rootNodeLi.appendChild(customerLogoDiv);
    //Sidebar toggler
    var div = document.createElement("div");
    div.className = "sidebar-toggler";
    rootNodeLi.appendChild(div);
    rootUl.appendChild(rootNodeLi); //Append to root ul

    BuildRecursiveDynamicMenu(models, rootUl);
    $("#leftmenu").html("").append(rootUl);
}

function BuildRecursiveDynamicMenu(models, rootUl) {
    $.each(models, function (i, item) {
        //if (item.UserReport.IsMenu) {
        var childNodeUl, childNodeLi;
        var a;
        if (item.ParentId === 0) {
            childNodeLi = createliNode(item.ReportCategory, item.Icon, true, item.ReportCategoryId);
            if (item.SubReportCollection.length > 0) {
                childNodeUl = document.createElement("ul");
                childNodeUl.className = "sub-menu SkrollThis";
                BuildRecursiveDynamicMenu(item.SubReportCollection, childNodeUl);
                childNodeLi.appendChild(childNodeUl); //Append to root ul
            }
            rootUl.appendChild(childNodeLi);
        } else if (item.ParentId !== 0 && item.SubReportCollection.length > 0) {
            childNodeLi = createliNode(item.ReportCategory, item.Icon, true, item.ReportCategoryId);
            if (item.SubReportCollection.length > 0) {
                childNodeUl = document.createElement("ul");
                childNodeUl.className = "sub-menu SkrollThis page-sidebar-fixed";
                BuildRecursiveDynamicMenu(item.SubReportCollection, childNodeUl);
                childNodeLi.appendChild(childNodeUl); //Append to root ul
            }
            rootUl.appendChild(childNodeLi);
        } else {
            var rootNodeLi = document.createElement("li");
            rootNodeLi.setAttribute("id", "menu_" + item.ReportCategoryId);
            a = document.createElement("a");
            a.setAttribute('onclick', 'OnMenuClick(' + item.ReportCategoryId + ',"' + item.ReportCategory + '");return false;');
            a.appendChild(createTextNode(item.ReportCategory)); //Append to li
            rootNodeLi.appendChild(a);
            rootUl.appendChild(rootNodeLi); //Append to root ul
        }

        if (item.ReportCategory == "Home Dashboard") {
            childNodeUl = document.createElement("ul");
            childNodeLi.className = "active";
            childNodeLi.appendChild(childNodeUl);

        }
        //}
    });
}


function OnMenuClick(reportCategoryId, reportName) {
    showLoadingCursor();
    var sidebar = $('.page-sidebar');
    var body = $('body');
    var sidebarMenu = $('.page-sidebar-menu');
    $(".sidebar-search", sidebar).removeClass("open");
    var height = $(".page-content-wrapper").height();
    $('.page-sidebar-menu').css('height', (height));
    body.addClass("page-sidebar-closed");
    sidebarMenu.addClass("page-sidebar-menu-closed");
    if (body.hasClass("page-sidebar-fixed")) {
        sidebarMenu.trigger("mouseleave");
    }
    if ($.cookie) {
        $.cookie('sidebar_closed', '1');
    }
    //$('.sidebar-toggler').click();
    document.title = reportName;
    $('#hdn_reportid_page').val(reportCategoryId);
    sessionStorage.setItem("ReportId", reportCategoryId);     //------value stored in the sessionstorage   
    sessionStorage.setItem("reportName", reportName);     //------value stored in the sessionstorage   
    if ($("#paintpage").length <= 0) {
        window.location.href = "../Home/Home";
        return false;
    }
    $.ajax({
        type: "POST",
        url: widgetCreator_CallURL,
        data: { ReportCategoryId: reportCategoryId },
        success: function (result) {
            if (result.indexOf("<title>SessionTimeOut</title>") > -1) {
                window.location.href = sessionTimeout_CallURL;
            }
            else {
                $("#paintpage").empty();
                $("#paintpage").html(result);
                $("li").removeClass("active");
                $("#menu_" + reportCategoryId).addClass("active");
                if ($("#menu_" + reportCategoryId).parent()[0].classList.contains("sub-menu")) {
                    $("#menu_" + reportCategoryId).parent().parent().addClass("active");
                }
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });


    if (!$('.customer_logo').hasClass('hiddenInitially')) {
        $('.customer_logo').addClass('hiddenInitially');
    }

    if ($('.sidebar-toggler').hasClass('active')) {
        $('.sidebar-toggler').removeClass('active');
    }

    return false;
}

