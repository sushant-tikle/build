﻿

var LogOffWindowLocationURL = "../Account/LogOff";
var UnreadMessageCountCallURL = "../TatvamNotification/TatvamNotificationMessageReadCount";
var AccountChangeCallURL = "../AccountChange/ChangeCurrentCustomerAccount";


// Click Drop-down-notification Starts Here 27/03/2015 //  		  
$('.dropdown-notification').click(function() {
    $(this).find('.dropdown-menu').css('display', 'block');
    $('.dropdown-admin .dropdown-menu').hide("slow");
});

$('.dropdown-admin').click(function() {
    $(this).find('.dropdown-menu').css('display', 'block');
    $('.dropdown-notification .dropdown-menu').hide("slow");
});

$('.page-container').click(function() {
    $('.dropdown-menu').css('display', 'none');
});
// Click Drop-down-notification Ends Here 27/03/2015 //


$(document).mouseup(function(e) {
    $('.dropdown-notification .dropdown-menu').hide();
    $('.dropdown-admin .dropdown-menu').hide();
});


function Logout() {
    bootbox.confirm({
        message: "Are you sure. You want to log out?",
        title: "Confirmation",
        size: "small",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                window.location = LogOffWindowLocationURL;
            } else {
                $(this).modal('hide');
            }
        }
    });
}

$.ajax(
{
    url: UnreadMessageCountCallURL,
    type: "Get",
    success: function (Result) {
        if (Result > 0) {
            $("#spanid").text(Result);
        }
        else {
            $("#spanid").attr("style", "visibility:hidden");
        }
    }
});


function ChangeCurrentCustomerAccount(newlySelectedCustomercode) {
    bootbox.confirm({
        size: "small",
        title: "Confirmation",
        message: "Are you sure, you want to change the property?",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                $(this).modal('hide');
                ChangeCurrentCustomerAccount_CallServer(newlySelectedCustomercode);
            }else{
                $(this).modal('hide');
        }
        }
    })
}


function ChangeCurrentCustomerAccount_CallServer(newlySelectedCustomercode) {
    $.ajax({
        type: "POST",
        url: AccountChangeCallURL,
        data: { inpNewCustomerCode: newlySelectedCustomercode },
        success: function(searchResults) {
            sessionStorage.setItem("ReportId", 1);
            sessionStorage.setItem("reportName", 'Dashboard');
            location.reload(true);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}