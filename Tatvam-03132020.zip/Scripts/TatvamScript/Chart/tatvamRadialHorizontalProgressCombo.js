﻿/*
 * Horizontal Plus Radial Progress Bar Plugin
 * Copyright (c) 2017
 * Depends:
 *   - jQuery v3.1.0+
 *   - bootstrap
 * @author Nithya Rani
 * @version 1.0.0
 * 
 */
(function ($) {
    'use strict';

    /**         
     * 
     * Provides the ability to manipulate the HTML template for each element of the Filter panel. 
     * These methods will be used only inside the plugin. 
     * Will not be exposed to the end user.
     * 
     * @param
     * 
     * @event
     * 
     * @return
     *      The DOM elemtns based on the type of Templates
     */
    var createHtmlTemplate = {
        /**         
         * 
         * Provides the ability to manipulate the HTML template for each progress bar. 
         * This also bind the progress bar to the widget control
         * These methods will be used only inside the plugin. 
         * Will not be exposed to the end user.
         * 
         * @param {$pluginId}
         *      Accept the plugin id
         * @param {data}
         *      Accept the one progress bar data
         * @event
         * 
         * @return
         *      The DOM elements using the plugin id
         */
        createProgress: function ($pluginId) {
            var containerHeight = $("#" + $pluginId).parent().height() - 40;
            var progressHTML = "";            
            progressHTML += "<div class='radialProgressContainer' style=''><div id='radialProgress" + $pluginId + "' class='leftDivision' style='width:" + containerHeight + "px !important; '></div></div>";
            progressHTML += "<div class='horizontalProgressContainer' style=''><div id='Horizontalprogress" + $pluginId + "' class='rightDivision'></div></div>";
            
            $("#" + $pluginId).append(progressHTML);
        }
    },
        /**         
         * 
         * Provides the ability to Read/Set/Get the Constant Details. 
         * These methods will be used only inside the plugin. 
         * Will not be exposed to the end user.
         * 
         * @param
         * 
         * @event
         * 
         * @return
         *      The DOM elemtns based on the type of Templates
         */
        exceptionHandling = {
            log: function (mesage) {
                console.log(mesage);
            },
            error: function (mesage) {
                console.error(mesage);
            }
        };


    function TatvamRadialHorizontalProgressBar($el, options) {
        var that = this,
            name = $el.attr('name') || options.name || '';
        this.pluginId = $el.attr("id");
        this.inpData = ""; // placeholder to keep the original clean input data
        this.curData = ""; // placeholder to keep the dirty data
        this.infoDetails = options.infoDetails;
        this.caption = options.caption;
        this.enableClose = options.enableClose;
        this.onClose = options.onClose !== "undefined" ? options.onClose : "";
        this.filterConstant = options.filterConstant;
        this.language = options.language;
        this['text-color'] = options['text-color'];
        this['font-family'] = options['font-family'];
        this['font-size'] = options['font-size'];
    }

    TatvamRadialHorizontalProgressBar.prototype = {
        init: function () {
            createHtmlTemplate.createProgress(this.pluginId);
            $(this.infoDetails.selector).append("<a style='position: absolute;z-index: 9;right: 10px;font-size: 20px;' href='#' class='pull-right' data-trigger='focus' data-placement='left' data-toggle='popover'  data-container='body'><i class='fa fa-info-circle' aria-hidden='true'></i></a>");
            $('[data-toggle="popover"]').popover({ title: this.infoDetails.title, content: "<div style='font-size:12px;'>" + this.infoDetails.description + "</div>", html: true, placement: "left" });
        },
        /**
         * Set the User input
         * 
         * @param {inpModel}
         *      set the Filter Data to the Input
         */
        setData: function (inpModel) {
            this.inpData = inpModel;
            this.curData = inpModel;
            this.createProgress();
        },
        /**
         * Create Progress for the input data
         */
        createProgress: function () {
            var pluginId = this.pluginId;
            var $this = this;
            $("#radialProgress" + pluginId).TatvamRadialProgressBar(layout);
            $("#radialProgress" + pluginId).TatvamRadialProgressBar("setData", this.inpData);

            $("#Horizontalprogress" + pluginId).TatvamHorizontalProgressBar(layout);
            $("#Horizontalprogress" + pluginId).TatvamHorizontalProgressBar("setData", this.inpData);
        },
    };

    // add the plugin to the jQuery.fn object
    $.fn.TatvamRadialHorizontalProgressBar = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData"];
        this.each(function () {
            var $this = $(this),
                data = $this.data('TatvamRadialHorizontalProgressBar'),
                options = $.extend({}, $.fn.TatvamRadialHorizontalProgressBar.defaults, $this.data(), typeof option === "object" && option);
            if (typeof option === 'string') {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw 'Method ' + option + ' does not exist on TatvamRadialHorizontalProgressBar';
                }
                //call the allowed methods
                value = data[option](args[1]);
            } else {
                data = new TatvamRadialHorizontalProgressBar($this, options);
                $this.data('TatvamRadialHorizontalProgressBar', data);
                data.init(this.id);
            }
        });
        return typeof value !== 'undefined' ? value : this;
    };
    $.fn.TatvamRadialHorizontalProgressBar.defaults = {
        // We define an empty function so that
        // we don't need to check its existence before calling it.
        caption: 'Widget Caption',
        enableClose: true,
        onClose: null,
        language: "en",
        'text-color': "#333",
        "font-family": "Helvetica, Arial, sans-serif",
        "font-size": 12
    };
})(jQuery);



function GetNPSData(reportId) {
    $.getJSON("../Data/GetNPSData", { reportId: reportId, isExecutiveSummary: false }, function (data) {          
        var reportname = data.Report.ReportCategory.replace(/ /g, '');      
        if (data.Result == null || data.Result.length <= 0) {
            $("#divid_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        } else {    
            $("#divid_" + reportId).empty();
            $("#divid_" + reportId).TatvamRadialHorizontalProgressBar(layout);
            $("#divid_" + reportId).TatvamRadialHorizontalProgressBar("setData", data.Result);
        }
        $('#chartloader_' + reportId).css('display', 'none');
    })
        .fail(function() {    
            $("#divid_" + reportId).css('display', 'block');
            $("#divid_" + reportId).empty();
            $("#divid_" + reportId).append("Something went wrong.");
        })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}