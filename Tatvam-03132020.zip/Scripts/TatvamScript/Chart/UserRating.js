﻿function CreateUserRating(score, reportID) {
    var userRatingImageBasePath = "../content/images/UserRating/";
    if (typeof (score) === "undefined")
        score = 0;
    var imagename = "";

    if (score <= 0) {
        imagename = "zero-stars_large.png";
    } else if (score > 0 && score <= 0.5) {
        imagename = "half-stars_large.png";
    } else if (score > 0.5 && score <= 1) {
        imagename = "one-stars_large.png";
    } else if (score > 1 && score <= 1.5) {
        imagename = "one-half-stars_large.png";
    } else if (score > 1.5 && score <= 2) {
        imagename = "two-stars_large.png";
    } else if (score > 2 && score <= 2.5) {
        imagename = "two-half-stars_large.png";
    } else if (score > 2.5 && score <= 3) {
        imagename = "three-stars_large.png";
    } else if (score > 3 && score <= 3.5) {
        imagename = "three-half-stars_large.png";
    } else if (score > 3.5 && score <= 4) {
        imagename = "four-stars_large.png";
    } else if (score > 4 && score <= 4.5) {
        imagename = "four-half-stars_large.png";
    } else if (score > 4.5 && score <= 5) {
        imagename = "five-stars_large.png";
    }


    var ratingimage = document.createElement("img");
    ratingimage.src = userRatingImageBasePath + imagename;
    $('#value_' + reportID).append(score.toPrecision(3));    
    $("#reviewimage_" + reportID).append(ratingimage);
    $('#userrating_' + reportID).css('display', 'block');
}


function GetUserRatingData(reportId) {  
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        if(data.Result === null){
            $("#userrating_" + reportId).css('display', 'block');
            $("#userrating_" + reportId).empty();
            $("#userrating_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if(data.Result.length === 0){
            $("#userrating_" + reportId).css('display', 'block');
            $("#userrating_" + reportId).empty();
            $("#userrating_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if ((typeof (data.Result.toFixed(2)) === "undefined") || data.Result.toFixed(2) === "0.00")
        {
            $("#userrating_" + reportId).css('display', 'block');
            $("#userrating_" + reportId).empty();
            $("#userrating_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else {
            $("#value_" + reportId).empty();
            $("#reviewimage_" + reportId).empty();
            CreateUserRating(data.Result, reportId);
        }
        $("#chartloader_" + reportId).css('display', 'none');       
    })
        .fail(function() {   $("#userrating_" + reportId).css('display', 'block');  $("#userrating_" + reportId).empty();  $("#userrating_" + reportId).append("Something went wrong."); })
        .always(function() { $("#chartloader_" + reportId).css('display', 'none'); });
}
