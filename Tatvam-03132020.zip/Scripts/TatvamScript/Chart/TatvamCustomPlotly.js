﻿function ChartRenderer(data) {
    var reportData, reportDetails, chartData, reportCategory
    reportDetails = data.Report;
    reportCategory = reportDetails.ReportCategory;
    var divname = "plotly_chart_" + reportDetails.ReportCategoryId;

    if (data.Result === null) {
        $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
        $('#' + divname).append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }

    if (data.Result.length === 0) {
        $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
        $('#' + divname).append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }
    var layout = jQuery.parseJSON(data.Report.ReportDefinition.layout); //reportDetails.layout;   

    var height = $('#report_' + reportDetails.ReportCategoryId).height() - 10;
    var width = $('#report_' + reportDetails.ReportCategoryId).width();
    if (height) {
        layout.height = height;
    } else {
        layout.height = 355;
    }
    layout.width = width;
    var maxValue = 0;
    data.Result.forEach(function (trace) {
        trace.y.forEach(function (yValue) {
            if (maxValue < yValue)
                maxValue = yValue;
        });    
        trace.text = trace.y.map(function (v, i) {
            var convertedValue = v;
            var hoverValue = v;
            if (trace.yaxis === 'y1') {
                convertedValue = ConvertTatvamDataFormat(v, layout.yaxis.tickformat);
            }
            else if (trace.yaxis === 'y2') {
                convertedValue = ConvertTatvamDataFormat(v, layout.yaxis2.tickformat);
            }

            if (v !== 0)
                hoverValue = trace.name + "<br>(" + trace.x[i] + "," + convertedValue + ")";
            return hoverValue || null;
        });
        trace.hoverinfo = 'text';
    });

    var tickvals = [];
    var ticktext = [];
    /*Check tickvals exist in array*/
    data.Result[0].x.forEach(function (XAxisValues) {
        if (tickvals.indexOf(XAxisValues) === -1) {
            tickvals.push(XAxisValues);
            if (XAxisValues.length > 12)
                ticktext.push(XAxisValues.substr(0, 12) + '...');
            else
                ticktext.push(XAxisValues);
        }
    });

    var value = GetYaxisMaxValue(maxValue);   


    var y0Max = value[0].max;
    var dtick = value[0].dtick;

    if (layout.yaxis.range == undefined) {
        layout.yaxis.range = [0, y0Max];
        layout.yaxis.dtick = dtick;
    }
    layout.xaxis.tickvals = tickvals;
    layout.xaxis.ticktext = ticktext;
    
    Plotly.newPlot(divname, data.Result, layout, {
        modeBarButtons: [[
            {
                name: "Download as PNG",
                icon: Plotly.Icons.camera,
                click: function (gd) {
                    Plotly.downloadImage(gd, {
                        filename: reportCategory,
                        format: 'png',
                        width: gd._fullLayout.width,
                        height: gd._fullLayout.height
                    })
                }
            },  //-- for export or image downloading. Download plot as a png
            'hoverClosestCartesian',//show the respective values for the selected category on hovering on the point.
            'hoverCompareCartesian'//compare the values of all the categories on hovering on the point.
        ]], displaylogo: false, displayModeBar: true
    });


    $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
}


function GetPlotlyChartData(reportId) {
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        ChartRenderer(data);
    })
        .fail(function () { $("#plotly_chart_" + reportId).append("Something went wrong."); })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}