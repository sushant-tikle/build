﻿var GetReviewList_CallURL = "../Review/ReviewList";
var GetClassifierList_CallURL = "../Review/GetClassifierListbyFactId";

/*
currently this is made as global variable
TO-DO: Need to add appropriate fix to the same.
*/
var selectedFilters = null;
var availableReivew = "";


function onMoreLinkClick() {
    // Configure/customize these variables. Show more/less text
    var showChar = 300;  // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "Read More";
    var lesstext = "Read Less";


    $(".morelink").click(function () {
        if ($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
}

function CallReviewListonWordCloudClick(ReportId, selectedText, selectedValue, searchbyText, searchbyValue) {    
    var mainClassifier = $.trim($("#wordCloudWithClickSelectedVal").text());
    var subClassifier = $.trim($("#StackedBarChartSelectedSubClassifier").text());
    var array = GetSearchFilters();
    //var inputFilters = {
    //    "SearchbyText": searchbyText,
    //    "SearchbyValue": searchbyValue,
    //    "OperatorName": "Equal To",
    //    "OperatorValue": "in",
    //    "SelectedText": selectedText,
    //    "SelectedValue": selectedValue,
    //    "ConditionName": "or",
    //    "ConditionValue": "or"
    //}

    var inputFilters = {
        "Condition": "AND",
        "ParentType": "CLASSIFIER",
        "KeyType": "CLASSIFIER",
        ParentValues: [mainClassifier],
        KeyWordValues: selectedText
    };
    array.unshift(inputFilters);
    var displayValue = "";

    var selectedRating = "0";
    if ($(".reviewListFilterSmile li.selectedli")[0] !== undefined) {
        selectedRating = $(".reviewListFilterSmile li.selectedli")[0].className.split(' ')[0];
    }
    var  rating = 0;
    if (selectedRating !== "0") {
        rating = selectedRating;
    }

    $.ajax({
        type: 'POST',
        async: false,
        url: GetReviewList_CallURL,
        data: { reportId: ReportId, TatvamReportFilterTo: JSON.stringify(array), rating: rating },
        success: function (result) {
            var reportCategoryIdIndex = result.indexOf("data-id");
            if (reportCategoryIdIndex !== -1) {
                var reportCategoryId = result.substr(reportCategoryIdIndex + 9).split('"')[0];
                $("#report_" + reportCategoryId).html(result);                
                $("#ReviewListSelectedMani").empty();
                $("#ReviewListSelectedMani").append(mainClassifier);

                $("#ReviewListSelectedSub").empty();
                $("#ReviewListSelectedSub").append(subClassifier);


                selectedFilters = inputFilters;
                if (selectedRating != "") {
                    $(".reviewListFilterSmile li").removeClass("selectedli");
                    var scoreclass = $('.' + Math.round(parseFloat(selectedRating)))
                    scoreclass.addClass("selectedli");
                }
                $("ul.bgheight").css({ display: "block" })
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error, "Error");
        }
    });
}

//method to get the search filters.
function GetSearchFilters() {
    var searchFilters = [];
    $('.searchpanel').each(function () {
        var searchbyText = $(this).find("#ddl_searchby option:selected").text();
        var searchbyValue = $(this).find("#ddl_searchby option:selected").val();

        var operatorName = $(this).find("#ddl_operator option:selected").text();
        var operatorValue = $(this).find("#ddl_operator option:selected").val();

        var valueId = $(this).find("[id^='ddl_value']").attr('id');

        var SelectedText = [];
        var SelectedValue = [];

        $(this).find("#" + valueId + " option:selected").each(function () {
            SelectedText.push({ Name: this.text });
            SelectedValue.push({ Name: this.value });
        });

        if (SelectedText.length === 0) {
            var val = $(this).find("#" + valueId).val();
            if (val) {
                SelectedValue = [];
                SelectedText.push({ Name: '%' + $(this).find("#" + valueId).val() + '%' });
                SelectedValue.push({ Name: '%' + $(this).find("#" + valueId).val() + '%' });
            }
        }


        if (SelectedValue.length > 0) {
            searchFilters.push({
                "SearchbyText": searchbyText,
                "SearchbyValue": searchbyValue,
                "OperatorName": operatorName,
                "OperatorValue": operatorValue,
                "SelectedText": SelectedText,
                "SelectedValue": SelectedValue,
                "ConditionName": "and",
                "ConditionValue": "and"
            });
        }
    });

    return searchFilters;
}

//method to obtain configured review details as JSON.
function GetReviewDetailsConfiguration(reportdetails) {
    if (reportdetails && reportdetails.length > 0) {
        return JSON.parse(reportdetails);
    }
}


function updateWidgetHeight(ReportCategoryId) {
    var gridster = $('.gridster ul#widgets').gridster().data('gridster');
    var widgetObj = gridster.$widgets.closest("#widget_" + ReportCategoryId);
    var height = $("#" + ReportCategoryId + " table").height();
    var sizey = Math.round(height / 100);
    var margin = sizey * 5
    sizey = (sizey == 1) ? sizey + 1 : sizey;
    gridster.resize_widget(widgetObj, 10, sizey, function (obj1, obj2) { });
}


// Tatvam 2.8 Implementation

function onRatingSmileClick(val, reportId) {
    $(".reviewListFilterSmile li").removeClass("selectedli");
    var scoreclass = $('.' + val);
    scoreclass.addClass("selectedli");

    $.ajax({
        type: "POST",
        url: "../Data/GetReviewData",
        data: { reportId: reportId, tatvamReportFilterTo: JSON.stringify([model[0]]), rating: val },
        async: false,
        success: function (data) {
            $("#feedback_" + reportId).empty();
            bindReviewData(data.Result, reportId);
        },
        error: function (xhr, status, p3, p4) {

        }
    });
}

function bindReviewData(data, reportId) {
    if (data.length === 0) {
        $("#feedback_@Model.ReportId").append("<div class=\'nodata\'>No Data Available.</div>");
    }
    $("#reviewTemplate").tmpl(data, {
        dataArrayIndex: function (item) {
            return $.inArray(item, data);
        }
    }).appendTo("#feedback_" + reportId);

    if (loadAllReviews) {
        setTimeout(function () {
            $(".materialTabContent").css({ "height": "95%", "overflow-y": "auto" });
            var height = $(".materialTabContent").height();
            $('#widgets').css({ "height": height + "px" });
            $('.page-footer-fixed').css({ "top": height + 500 + "px" });
        }, 2000);
    }
    if (!reviewsExpandAll) {
        onMoreLinkClick();
    } else {
        $("#feedback_" + reportId).find(".moreellipses").remove();
        $("#feedback_" + reportId).find(".morelink").remove();
        $("#feedback_" + reportId).find(".morecontent span").css({ display: "inline" });
    }
    if (reportId === 1075) {
        var gridster = $('.gridster ul#widgets').gridster().data('gridster');
        var widgetObj = gridster.$widgets.closest("#widget_" + reportId);
        var reviewListContainerHeight = $("#feedback_" + reportId).height() + 1000;
        var sizex = widgetObj.attr("data-sizex");
        if (sizex !== undefined) {
            var sizey = Math.ceil(reviewListContainerHeight / 128);
            sizey = (sizey == 1) ? sizey + 2 : sizey + 1;
            gridster.resize_widget(widgetObj, sizex, sizey, function (obj1, obj2) { });
        }
    }
    hideLoadingCursor();
}

/*******Pagination for review reports implementation - start ********/

function PaginationReviewList(reportID, skip) {
    $.getJSON("../Data/GetReviewData", { reportId: reportID, tatvamReportFilterTo: JSON.stringify([reviewModel[0]]), isExecutiveSummary: false, skip: skip }, function (data) {
        bindReviewData(data.Result, reportID);
    });
}


//binding scroll event handler to allreviews tab
function BindScrollEventHandler(reportID) {
    var element = $('#feedback_' + reportID);
    element.scroll(function () {
        if (element.scrollTop() + element.height() > this.scrollHeight - 100) {
        }
    });
    var element = $('#feedback_' + reportID);
    //var element = $('.materialTabContent');
    element.scrollTop(0);
    //binding scroll event handler to allreviews tab
    element.unbind("scroll").on("scroll", function (evt) {
        if (element.scrollTop() + element.height() > this.scrollHeight - 100) {
            showLoadingCursor();
            var skip = $(".materialCard").length;
            PaginationReviewList(reportID, skip);
        }
    });
}
/*******Pagination for review reports implementation - end ********/

function GetDate(jsonDate) {
    var tempData = jsonDate.split('-');
    var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var monthShort = month[tempData[1] - 1];
    return tempData[2] + "-" + monthShort + "-" + tempData[0];
}


function GetReviewText(startIndex, endIndex, comment) {
    var res = comment.substr(startIndex, endIndex);
    return res;
}


function GetReviewData(reportId , rating) {
    $.getJSON("../Data/GetReviewData", { reportId: reportId, tatvamReportFilterTo: JSON.stringify([reviewModel[0]]), isExecutiveSummary: false, rating: rating }, function (data) {
        $("#feedback_" + reportId).empty();
        enableRatingFilter = data.Report.ReportDefinition.reviewdisplay.enableRatingFilter;
        if(enableRatingFilter){
            $(".selectedText").css('display', 'block');
        }
        if(data.Result == null){
            if(data.Message !== "" ){
                $("#feedback_" + reportId).empty();
                $("#feedback_" + reportId).append("<div class=\'nodata\'>" + data.Message + "</div>");
            }
        }
        else if(data.Result.length === 0 ){
            $("#feedback_" + reportId).empty();
            $("#feedback_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        } else {
            reviewsExpandAll = data.Report.ReportDefinition.reviewdisplay.reviewsExpandAll;
            onScrollLoad = data.Report.ReportDefinition.reviewdisplay.onScrollLoad;
            loadAllReviews = data.Report.ReportDefinition.reviewdisplay.loadAllReviewsWarning;


            if(data.Report.ReportDefinition.reviewdisplay.loadAllReviewsWarning) {
                bootbox.confirm({
                    message: "The All Reviews is meant to display all the reviews for the currently selected time range. This report works best when you have a short date range selected. If you have a large date range selected this report may have extremely long load times and may fail to load at all. Do you wish to proceed?",
                    title: "Warning",
                    size: "small",
                    buttons: {
                        confirm: {
                            label: 'Proceed',
                            className: 'btn-primary'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-default'
                        }
                    },
                    callback: function (result) {
                        $(this).modal('hide');
                        if (result) {
                            bindReviewData(data.Result, reportId);
                        } else {
                            sessionStorage.setItem("ReportId", 1);
                            sessionStorage.setItem("reportName", 'Dashboard');
                            location.reload(true);
                        }
                    }
                });
            } else {
                bindReviewData(data.Result, reportId);
            }

            if(onScrollLoad){
                BindScrollEventHandler(reportId);
            }
        }

    })
        .fail(function() { 
            $("#feedback_" + reportId).append("Something went wrong.");  
        })
        .always(function() { 
            $('#chartloader_' + reportId).css('display', 'none'); 
        });   
}