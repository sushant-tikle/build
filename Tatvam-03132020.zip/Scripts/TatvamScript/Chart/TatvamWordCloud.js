﻿/*Get all data*/
function GetWorldCloudData(reportId){
    $.getJSON("../Data/GetWordCloudData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        if (data.Result == null || data.Result.length <= 0) {
            $("#myDiv4").empty();  
            $("#myDiv4").append("<div class=\'nodata\'>No Data Available.</div>");
        } else {              
            BindWorldCloud(data.Result);
        }
        $("#chartloader_" + reportId).css('display', 'none');
    })
        .fail(function () {
            $("#chartloader_" + reportId).css('display', 'none');
            $('#myDiv4').css('display', 'block');
            $("myDiv4").empty(); $("#myDiv4").append("Something went wrong.");
        });

}
var tags = [];

var fill = d3.scale.category20b();
var wordScale;

var w = Math.round($('#myDiv4').parent().width() - 20),
h = Math.round($('#myDiv4').parent().height());
h = 350;
var max,
    fontSize;

//var layout = d3.layout.cloud()
//    .timeInterval(Infinity)
//    .size([w, h])
//    .padding(4)
//    .rotate(function () {
//        return ~(Math.random() * 2) * 0;
//    })
//    .font("Lato")
//    .fontSize(function (d) {
//        return wordScale(+d.value);
//    })
//    .text(function (d) {
//        return d.key;
//    })
//    .on("end", draw);

var svg = d3.select("#myDiv4")
    .append("svg")
    .attr("width", w)
    .attr("height", h);

var vis = svg.append("g").attr("transform", "translate(" + [w >> 1, h >> 1] + ")");

function BindWorldCloud(data) {
    $(data).each(function (index, element) {
        tags.push({
            "key": element.ParentWord,
            "value": element.Count,
            "Avg": element.Avg
        })
    });
    wordScale = d3.scale.linear().domain([1, d3.max(tags, function (d) {
        return d.value;
    })]).range([14, 30]).clamp(true);
    update();
    $('#myDiv4').css('display', 'block');
}

function draw(data, bounds) {
    //var w = 700,
    //    h = 400;
    var w = Math.round($('#myDiv4').width() - 20),
    h = 350;
    svg.attr("width", w).attr("height", h);

    scale = bounds ? Math.min(
        w / Math.abs(bounds[1].x - w / 2),
        w / Math.abs(bounds[0].x - w / 2),
        h / Math.abs(bounds[1].y - h / 2),
        h / Math.abs(bounds[0].y - h / 2)) / 2 : 1;

    var text = vis.selectAll("text")
        .data(data, function (d) {
            return d.text.toLowerCase();
        });

    text.transition()
        .duration(1000)
        .attr("transform", function (d) {
            return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .style("font-size", function (d) {
            return d.size + "px";
        });

    text.enter().append("text")
        .attr("text-anchor", "middle")
        .attr("transform", function (d) {
            return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .style("font-size", function (d) {
            return d.size + "px";
        })
        .style("opacity", 1e-6)
        .transition()
        .duration(1000)
        .style("opacity", 1);

    text.style("font-family", function (d) {
        return d.font;
    })
        .style("fill", function (d, i) {
            rating = data[i].Avg;
            if (rating < 1) {
                return '#4286f4';
            }
            else if (rating < 1.5) {
                return '#f34443';
            }
            else if (rating >= 1.5 && rating < 2.5) {
                return '#e66e0b';
            }
            else if (rating >= 2.5 && rating < 3.5) {
                return '#f3b81a';
            }
            else if (rating >= 3.5 && rating < 4.5) {
                return '#2dac07';
            }
            else if (rating >= 4.5) {
                return '#196004';
            } else {
                return myColors[i];
            }
        })
        .text(function (d) {
            return d.text;
        });

    vis.transition().attr("transform", "translate(" + [w >> 1, h >> 1] + ")scale(" + scale + ")");
}

function update() {
    var layout = d3.layout.cloud().timeInterval(Infinity).size([w, h]).padding(4)
    .rotate(function () {
        return ~(Math.random() * 2) * 0;
    })
    .font("lato").spiral('archimedean')
    .fontSize(function (d) {
        return wordScale(+d.value);
    })
    .text(function (d) {
        return d.key;
    })
    .on("end", draw);

    fontSize = d3.scale['sqrt']().range([10, 100]);
    if (tags.length) {
        fontSize.domain([+tags[tags.length - 1].value || 1, +tags[0].value]);
    }
    layout.stop().words(tags).start();
}