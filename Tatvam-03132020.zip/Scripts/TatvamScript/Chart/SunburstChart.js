﻿var SunBurstChartCallURL = "../Chart/SunburstChart";


function CreateTatvamSunBrustChartWidget(ReportId, reportname, subds) {
    if (subds.length <= 0) {
        $("#Sunburst_SVG").empty();
        $("#sunbrusttooltip").empty();

        $("#sunbrusttooltip").append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }
    else {
        $("#sunburstSelected").empty();
        $("#ReviewListSelected").empty();
        var sunbrustDisplayValue = $('#LinePlusBarSelected').text();
        if (sunbrustDisplayValue === "") {
            sunbrustDisplayValue = $('#selectedValue .classifier .heading').text();
        }
        $("#sunburstSelected").append(sunbrustDisplayValue);
        $("#ReviewListSelected").append(sunbrustDisplayValue);


        $("#Sunburst_Heading").empty();
        $("#Sunburst_Heading_score").empty();

        $("#Sunburst_Heading").append(subds.name);
        $("#Sunburst_Heading_score").append("44");
        var jsonData;
        jsonData = subds;
        readJson = function (text, callback) { callback(text ? JSON.parse(text) : null); }

        var width = 290,
		height = width,
		radius = width / 2,
		duration = 1000,
		fontSize = 12;

        // Mapping of step names to colors.
        var colors = {
            "1": "#f34443",
            "2": "#e66e0b",
            "3": "#f3b81a",
            "4": "#2dac07",
            "5": "#196004"
        };

        function draw() {
            d3.select("#Sunburst_SVG").html("");
            drawStarburst(width, height, radius, duration, fontSize);
        }

        function drawStarburst(width, height, radius, duration, fontSize) {

            var colorNum = 0;

            var x = d3.scale.linear().range([0, 2 * Math.PI]),
			y = d3.scale.pow().exponent(1.3).domain([0, 1]).range([0, radius]),
			padding = 5;

            var div = d3.select("#Sunburst_SVG");

            div.select("img").remove();

            var vis = div.append("svg")
			.attr("width", width + padding * 2)
			.attr("height", height + padding * 2)
			.append("g")
			.attr("transform", "translate(" + [radius + padding, radius + padding] + ")");

            var partition = d3.layout.partition()
			.sort(null)
			.value(function (d) { return 5.8 - d.depth; });

            var arc = d3.svg.arc()
			.startAngle(function (d) { return Math.max(0, Math.min(2 * Math.PI, x(d.x))); })
			.endAngle(function (d) { return Math.max(0, Math.min(2 * Math.PI, x(d.x + d.dx))); })
			.innerRadius(function (d) { return Math.max(0, d.y ? y(d.y) : d.y); })
			.outerRadius(function (d) { return Math.max(0, y(d.y + d.dy)); });
            readJson(JSON.stringify(jsonData), function (json) {
                var nodes = partition.nodes({ children: json });

                var path = vis.selectAll("path").data(nodes);
                path.enter().append("path")
					.attr("id", function (d, i) { return "path-" + i; })
					.attr("d", arc)
					.attr("fill-rule", "evenodd")
					.attr("fill", "#fff")
					//.attr("display", function (d) { return d.depth ? null : "none"; }) // hide inner ring
					.style("stroke", "#fff")
					.style("fill", function (d) {
					    var rtnColor = colors[d.name];
					    if (typeof rtnColor === "undefined") {
					        rtnColor = d.parent;
					        if (typeof rtnColor === "undefined")
					            rtnColor = "#fff";
					        else
					            rtnColor = colors[d.parent.name];
					    }
					    if (typeof rtnColor === "undefined")
					        rtnColor = "#fff";
					    return rtnColor;
					})
					.style("fill-rule", "evenodd")
					.on("click", click);

                var text = vis.selectAll("text").data(nodes);
                var textEnter = text.enter().append("text")
                                    .style("fill-opacity", 1)
                                    .style("fill", function (d) {
                                        return "#fff";
                                    })
                                    .attr("text-anchor", function (d) {
                                        return x(d.x + d.dx / 2) > Math.PI ? "end" : "start";
                                    })
                                    .attr("dy", ".2em")
                                    .attr("transform", function (d) {
                                        var multiline = (d.name || "").split(" ").length > 1,
                                        angle = x(d.x + d.dx / 2) * 180 / Math.PI - 90,
                                        rotate = angle + (multiline ? -.5 : 0);
                                        return "rotate(" + rotate + ")translate(" + (y(d.y) + padding) + ")rotate(" + (angle > 90 ? -180 : 0) + ")";
                                    })
                                    .on("click", click);

                textEnter.append("tspan")
                        .attr("x", 0)
                        .attr("font-size", fontSize)
                        .text(function (d) {
                            return d.depth ? d.name.split(" ")[0] : "";
                        });

                function click(d) {                    
                    showLoadingCursor();
                    $("#sunburstSelected").empty();
                    $("#ReviewListSelected").empty();
                    var sunbrustDisplayValue;
                    if (typeof d.name == "undefined") {
                        sunbrustDisplayValue = $('#LinePlusBarSelected').text();
                    } else {
                        if (d.name !== "")
                            sunbrustDisplayValue = $('#LinePlusBarSelected').text() + "  ||  " + d.name;
                        else
                            sunbrustDisplayValue = $('#LinePlusBarSelected').text();
                    }

                    $("#sunburstSelected").append(sunbrustDisplayValue);
                    $("#ReviewListSelected").append(sunbrustDisplayValue);

                    var SelectedText = [];
                    var SelectedValue = [];
                    if (typeof d.children == "undefined") {
                        SelectedText.push({ Name: d.size });
                        SelectedValue.push({ Name: d.size });
                    }
                    else {
                        for (var i = 0; i < d.children.length; i += 1) {
                            if (typeof d.children[i].children != "undefined") {
                                for (var j = 0; j < d.children[i].children.length; j += 1) {
                                    SelectedText.push({ Name: d.children[i].children[j].size });
                                    SelectedValue.push({ Name: d.children[i].children[j].size });
                                }
                            }
                            else {
                                SelectedText.push({ Name: d.children[i].size });
                                SelectedValue.push({ Name: d.children[i].size });
                            }
                        }
                    }

                    CallReviewListonWordCloudClick(ReportId, SelectedText, SelectedValue, 'factid', 'fpr.FACT_ID in (@factid)');

                    path.transition()
                        .duration(duration)
                        .attrTween("d", arcTween(d));

                    // Somewhat of a hack as we rely on arcTween updating the scales.
                    text.style("visibility", function (e) {
                        return isParentOf(d, e) ? null : d3.select(this).style("visibility");
                    })
                        .transition()
                        .duration(duration)
                        .attrTween("text-anchor", function (d) {
                            return function () {
                                return x(d.x + d.dx / 2) > Math.PI ? "end" : "start";
                            };
                        })
                        .attrTween("transform", function (d) {

                            var multiline = (d.name || "").split(" ").length > 1;
                            return function () {
                                var angle = x(d.x + d.dx / 2) * 180 / Math.PI - 90,
								rotate = angle + (multiline ? -.5 : 0);
                                return "rotate(" + rotate + ")translate(" + (y(d.y) + padding) + ")rotate(" + (angle > 90 ? -180 : 0) + ")";
                            };
                        })
                .style("fill-opacity", function (e) { return isParentOf(d, e) ? 1 : 1e-6; })
                .each("end", function (e) {
                    d3.select(this).style("visibility", isParentOf(d, e) ? null : "hidden");
                });
                }
            });

            function isParentOf(p, c) {
                if (p === c) return true;
                if (p.children) {
                    return p.children.some(function (d) {
                        return isParentOf(d, c);
                    });
                }
                return false;
            }


            // Interpolate the scales!
            function arcTween(d) {
                var my = maxY(d),
				xd = d3.interpolate(x.domain(), [d.x, d.x + d.dx]),
				yd = d3.interpolate(y.domain(), [d.y, my]),
				yr = d3.interpolate(y.range(), [d.y ? 20 : 0, radius]);
                return function (d) {
                    return function (t) {
                        x.domain(xd(t));
                        y.domain(yd(t)).range(yr(t));
                        return arc(d);
                    };
                };
            }

            function maxY(d) {
                return d.children ? Math.max.apply(Math, d.children.map(maxY)) : d.y + d.dy;
            }

            // http://www.w3.org/WAI/ER/WD-AERT/#color-contrast
            function brightness(rgb) {
                return rgb.r * .299 + rgb.g * .587 + rgb.b * .114;
            }
        }

        draw();
    }
}


function CallSunbrustonWordCloudClick(reportId, selectedText, selectedValue, searchbyText, searchbyValue) {    
    showLoadingCursor();
    var array = [];
    $('.searchpanel').each(function () {
        showLoadingCursor();
        var searchbyText = $(this).find("#ddl_searchby option:selected").text();
        var searchbyValue = $(this).find("#ddl_searchby option:selected").val();

        var operatorName = $(this).find("#ddl_operator option:selected").text();
        var operatorValue = $(this).find("#ddl_operator option:selected").val();

        var valueId, selectedText = "", selectedValue = "";
        valueId = $(this).find("[id^='ddl_value']").attr("id");

        var SelectedText = [];
        var SelectedValue = [];

        $(this).find("#" + valueId + " option:selected").each(function () {
            SelectedText.push({ Name: this.text });
            SelectedValue.push({ Name: this.value });
        });

        if (SelectedText.length === 0) {
            var val = $(this).find("#" + valueId).val();
            if (val !== "") {
                SelectedValue = [];
                SelectedText.push({ Name: '%' + val + '%' });
                SelectedValue.push({ Name: '%' + val + '%' });
            }
        }

        var conditionName = $(this).find("#ddl_whereclause option:selected").text();
        var conditionValue = $(this).find("#ddl_whereclause option:selected").val();


        if (SelectedValue.length > 0) {
            array.push({
                "SearchbyText": searchbyText,
                "SearchbyValue": searchbyValue,
                "OperatorName": operatorName,
                "OperatorValue": operatorValue,
                "SelectedText": SelectedText,
                "SelectedValue": SelectedValue,
                "ConditionName": "and",
                "ConditionValue": "and"
            });
        }
    });

    array.push({
        "SearchbyText": searchbyText,
        "SearchbyValue": searchbyValue,
        "OperatorName": "Equal To",
        "OperatorValue": "=",
        "SelectedText": selectedText,
        "SelectedValue": selectedValue,
        "ConditionName": "or",
        "ConditionValue": "or"
    });

    $.ajax({
        type: 'POST',
        async: true,
        //dataType: 'json',
        url: SunBurstChartCallURL,
        data: { reportId: reportId, tatvamReportFilterTo: JSON.stringify(array) },
        success: function (result) {
            var reportCategoryId = result.substr(result.indexOf("ReportCategoryId") + 18).split(',')[0]
            $("#report_" + reportCategoryId).empty();
            $("#report_" + reportCategoryId).html(result);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error, "Error");
        }
    });
}
