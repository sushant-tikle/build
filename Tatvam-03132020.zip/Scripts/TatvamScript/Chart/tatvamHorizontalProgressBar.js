/*
 * Horizontal Progress Bar Plugin
 * Copyright (c) 2017
 * Depends:
 *   - jQuery v3.1.0+
 *   - bootstrap
 * @author Nithya Rani
 * @version 1.0.0
 * 
 */

(function ($) {
    'use strict';

    /**         
     * 
     * Provides the ability to manipulate the HTML template for each element of the Filter panel. 
     * These methods will be used only inside the plugin. 
     * Will not be exposed to the end user.
     * 
     * @param
     * 
     * @event
     * 
     * @return
     *      The DOM elemtns based on the type of Templates
     */
    var createHtmlTemplate = {          
            /**         
             * 
             * Provides the ability to manipulate the HTML template for each progress bar. 
             * This also bind the progress bar to the widget control
             * These methods will be used only inside the plugin. 
             * Will not be exposed to the end user.
             * 
             * @param {$pluginId}
             *      Accept the plugin id
             * @param {data}
             *      Accept the one progress bar data
             * @event
             * 
             * @return
             *      The DOM elements using the plugin id
             */
            createProgress: function ($pluginId, data, $this) {
                var progressHtml = "";
                progressHtml += "<div class='horizontalProgressRow'>";

                progressHtml += "<div class='progressBarLabel progressBar' style='text-align: left;padding-right: 0px !important;padding-left: 0px !important;color: " + $this['text-color'] + "; font-size : " + $this['font-size'] + "px; font-family : " + $this['font-family'] + ";margin-top: 0.5% !important;'>" + data.label + " (" + data.value + ")</div>";

                progressHtml += "<div class='horizontalProgressBar progressBar' style='padding-right: 0px !important;padding-left: 0px !important;'>";

                progressHtml += "<div style='overflow: hidden;background-color: #f5f5f5;border-radius: 4px;box-shadow: inset 0 1px 2px rgba(0, 0, 0, .1);height: 10px !important;margin-bottom: 7px !important;position: relative;display: block;width: 100%;margin: 0.5rem 0 1rem 0;'>";
                progressHtml += "<div class='determinate' style=' border-radius: 10px;position: absolute;top: 0;left: 0; bottom: 0;transition: width .3s linear; width: " + data.percentage.toFixed(2) + "% !important;background-color:" + data.color + ";'></div>";
                progressHtml += "</div>";
                progressHtml += "</div>";

                progressHtml += "<div class='horizontalProgressBarPercentage progressBar'  style='padding-right: 10px !important;padding-left: 0px !important;color: " + $this['text-color'] + "; font-size : " + $this['font-size'] + "px; font-family : " + $this['font-family'] + ";margin-top: 0.5% !important;'>" + data.percentage.toFixed(2) + " % </div>";

                progressHtml += "</div>";

                $("#" + $pluginId).append(progressHtml);
            }
        },
        /**         
         * 
         * Provides the ability to Read/Set/Get the Constant Details. 
         * These methods will be used only inside the plugin. 
         * Will not be exposed to the end user.
         * 
         * @param
         * 
         * @event
         * 
         * @return
         *      The DOM elemtns based on the type of Templates
         */
        exceptionHandling = {
            log: function (mesage) {
                console.log(mesage);
            },
            error: function (mesage) {
                console.error(mesage);
            }
        };


    function TatvamHorizontalProgressBar($el, options) {
        var that = this,
            name = $el.attr('name') || options.name || '';
        this.pluginId = $el.attr("id");
        this.inpData = ""; // placeholder to keep the original clean input data
        this.curData = ""; // placeholder to keep the dirty data
        this.caption = options.caption;
        this.enableClose = options.enableClose;
        this.onClose = options.onClose !== "undefined" ? options.onClose : "";
        this.filterConstant = options.filterConstant;
        this.language = options.language;
        this['text-color'] = options['text-color'];
        this['font-family'] = options['font-family'];
        this['font-size'] = options['font-size'];
    }

    TatvamHorizontalProgressBar.prototype = {
        init: function () {
          
        },       
        /**
         * Set the User input
         * 
         * @param {inpModel}
         *      set the Filter Data to the Input
         */
        setData: function (inpModel) {
            this.inpData = inpModel;
            this.curData = inpModel;
            this.createProgress();
        },      
        /**
         * Create Progress for the input data
         */
        createProgress: function () {
            var pluginId = this.pluginId;
            var $this = this;
            $.each(this.inpData, function (i, obj) {
                createHtmlTemplate.createProgress(pluginId, obj, $this);
            });
        },
    };

    // add the plugin to the jQuery.fn object
    $.fn.TatvamHorizontalProgressBar = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData"];
        this.each(function () {
            var $this = $(this),
                data = $this.data('TatvamHorizontalProgressBar'),
                options = $.extend({}, $.fn.TatvamHorizontalProgressBar.defaults, $this.data(), typeof option === "object" && option);
            if (typeof option === 'string') {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw 'Method ' + option + ' does not exist on TatvamHorizontalProgressBar';
                }
                //call the allowed methods
                value = data[option](args[1]);
            } else {
                data = new TatvamHorizontalProgressBar($this, options);
                $this.data('TatvamHorizontalProgressBar', data);
                data.init(this.id);
            }
        });
        return typeof value !== 'undefined' ? value : this;
    };
    $.fn.TatvamHorizontalProgressBar.defaults = {
        // We define an empty function so that
        // we don't need to check its existence before calling it.
        caption: 'Widget Caption',
        enableClose: true,
        onClose: null,
        language: "en",
        'text-color': "#333",
        "font-family": "Helvetica, Arial, sans-serif",
        "font-size": 12,
    };
})(jQuery);
