﻿function LoadAllReviews(reviewdata, reportname, reportid, reportdetails) {


}


function onMoreLinkClick() {
    // Configure/customize these variables. Show more/less text
    var showChar = 300;  // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "Read More";
    var lesstext = "Read Less";


    $(".morelink").click(function () {
        if ($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
}


function DisplayWarningMessageThenLoadReview(reviewdata, reportname, reportid, reportdetails) {
    bootbox.confirm({
        message: "The All Reviews is meant to display all the reviews for the currently selected time range. This report works best when you have a short date range selected. If you have a large date range selected this report may have extremely long load times and may fail to load at all. Do you wish to proceed?",
        title: "Warning",
        size: "small",
        buttons: {
            confirm: {
                label: 'Proceed',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                bindReviewList(reviewdata, reportname, reportid, reportdetails);
            } else {
                sessionStorage.setItem("ReportId", 1);
                sessionStorage.setItem("reportName", 'Dashboard');
                location.reload(true);
            }
            $(this).modal('hide');
        }
    });
}


function onRatingSmileClick(val, reportId) {
    $(".reviewListFilterSmile li").removeClass("selectedli");
    var scoreclass = $('.' + val);
    scoreclass.addClass("selectedli");

    var selectedText = [];
    var selectedValue = [];

    selectedText.push({ Name: val });
    selectedValue.push({ Name: val });
    var reportFilter = [];
    reportFilter.push({
        "SearchbyText": "fpr.RATING = @rating",
        "SearchbyValue": "fpr.RATING = @rating",
        "OperatorName": "Equal To",
        "OperatorValue": "=",
        "SelectedText": selectedText,
        "SelectedValue": selectedValue,
        "ConditionName": "or",
        "ConditionValue": "or"
    });

    $.ajax({
        type: "POST",
        url: "../Review/GetReviewData",
        data: { reportId: reportId, TatvamReportFilterTo: JSON.stringify(reportFilter), isExecutiveSummary: false, rowNumber: 0 },
        async: false,
        success: function (result) {
            var reportname = result.ObjReportDo.ReportCategory.replace(/ /g, '');
            var reportid = result.ObjReportDo.ReportCategoryId;
            var reportdetails = result.ObjReportDo.ReportDetail.ReportDetails;
            $('#feedback_' + reportname).empty();
            bindReviewList(result.DisplayText, reportname, reportid, reportdetails);
        },
        error: function (xhr, status, p3, p4) {

        }
    });
}

function bindReviewList(reviewdata, reportname, reportid, reportdetails) {
	var reportdetailsjson = GetReviewDetailsConfiguration(reportdetails);
	if (!reportdetailsjson.enableRatingFilter) {
        $("#ratingFilter-" + reportname).remove();
    }
    var reportDOMID = "feedback_" + reportname;
    if (reviewdata.length === 0) {
        var usercomment = document.createElement('div');
        usercomment.className = "nodata";
        usercomment.innerText = "No Data Available";
        document.getElementById(reportDOMID).innerHTML = '';
        document.getElementById(reportDOMID).appendChild(usercomment);
        return;
    }
    document.getElementById(reportDOMID).innerHTML += reviewdata;

    $("#report_" + reportid).find(".moreellipses").remove();
    $("#report_" + reportid).find(".morecontent span").css({ display: "inline" });
    $("#report_" + reportid).find(".morelink").remove();

    setTimeout(function () {
        $(".materialTabContent").css({ "height": "95%", "overflow-y": "auto" });
        var height = $(".materialTabContent").height();
        $('#widgets').css({ "height": height + "px" });
        $('.page-footer-fixed').css({ "top": height + 500 + "px" });
    }, 2000);
    onMoreLinkClick();
}