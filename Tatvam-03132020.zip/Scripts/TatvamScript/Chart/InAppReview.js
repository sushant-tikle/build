﻿function __onCheckAll(inpThis) {  
    $(".oneReviewCheckbox").prop('checked', inpThis.checked);
    $(".panelHedding").prop('checked', inpThis.checked);

    var all, checked;
    all = $(".oneReviewCheckbox").filter(":checked");
    checked = all.filter(":checked");
    var checkedIds = checked.map(function () {
        return this.id;
    });


    var tempStatus = $("#sideStatusPanel .active").data().status;

    if (checkedIds.length > 0 && tempStatus !== "RESPONDED" && tempStatus !== "FAILED" && tempStatus !== "DRAFT") {
        $("#bulkStatusChange_chosen").show();
        $("#lblStatus").show();
    } else {
        $("#bulkStatusChange_chosen").hide();
        $("#lblStatus").hide();
    }
}

function __selectAllReviewByDate(inpThis) {
    $("#" + inpThis.dataset.id + " .oneReviewCheckbox").prop('checked', inpThis.checked);
    var all, checked;
    all = $(".oneReviewCheckbox").filter(":checked");
    checked = all.filter(":checked");
    var checkedIds = checked.map(function () {
        return this.id;
    });

    var tempStatus = $("#sideStatusPanel .active").data().status;

    if (checkedIds.length > 0 && tempStatus !== "RESPONDED" && tempStatus !== "FAILED" && tempStatus !== "DRAFT") {
        $("#bulkStatusChange_chosen").show();
        $("#lblStatus").show();
    } else {
        $("#bulkStatusChange_chosen").hide();
        $("#lblStatus").hide();
    }
}

function __oneReview(inpThis) {
    $("#" + inpThis.dataset.id + " .oneReviewCheckbox").prop('checked', inpThis.checked);

    var all, checked;
    all = $(".oneReviewCheckbox").filter(":checked");
    checked = all.filter(":checked");
    var checkedIds = checked.map(function () {
        return this.id;
    });

    var tempStatus = $("#sideStatusPanel .active").data().status;

    if (checkedIds.length > 0 && tempStatus !== "RESPONDED" && tempStatus !== "FAILED" && tempStatus !== "DRAFT") {
        $("#bulkStatusChange_chosen").show();
        $("#lblStatus").show();
    } else {
        $("#bulkStatusChange_chosen").hide();
        $("#lblStatus").hide();
    }
}

function refreshFeeds() {    
    displayReviewList();
    updateStatusPanel();
}

function updateManyReviewStatus(inpReviewId, tempstatus) {
    $.getJSON("../Review/updateStatus", { reviewId: JSON.stringify(inpReviewId), inpStatus: tempstatus }, function (data) {
        var statusList = JSON.parse(data);        
        updateStatusPanel();
        displayReviewList();
    });
}


function updateOneReviewStatus(inpReviewId, tempstatus) {
    $.getJSON("../Review/updateStatus", { reviewId: JSON.stringify(inpReviewId), inpStatus: tempstatus }, function (data) {
        var statusList = JSON.parse(data);        
        enableReviewStatus(tempstatus);
        updateStatusPanel();
    });
}

function enableReviewStatus(tempstatus) {
    $("#reviewStatus li").removeClass('active');
    if (reviewStatus === "NEW") {
        $('#reviewStatus li[data-reviewstatus = READ]').addClass('active');
    } else {
        $('#reviewStatus li[data-reviewstatus = ' + tempstatus + ']').addClass('active');
    }
    if (tempstatus === "RESPONDED" || tempstatus === "CLOSED") {
        $("#reviewStatus li a").attr('disabled', 'disabled');
        $("#reviewStatus li a").addClass('statusDisabled');
    } else {
        $("#reviewStatus li a").removeAttr('disabled');
        $("#reviewStatus li a").removeClass('statusDisabled');
    }
}

function onStatusChange(inpStatus) {
    var all, checked;
    all = $(".oneReviewCheckbox").filter(":checked");
    checked = all.filter(":checked");
    var checkedIds = checked.map(function () {
        return this.id;
    });
    if (checkedIds.length > 0) {
        var changeStatusto = inpStatus.value;
        updateManyReviewStatus(checkedIds.toArray(), inpStatus.value);
    } else {
        TatvamAlert("Please select review to change the status.", "Error");
    }
}

$('#widgets').css('width', '100%');
$('#widgets').css('height', '');
$("#widgetContainer").removeClass('gridster');
$("#widget_1107").removeClass('gs-w');
var el = document.querySelector('#widget_1107');
el.removeAttribute('data-row');
el.removeAttribute('data-col');
el.removeAttribute('data-sizex');
el.removeAttribute('data-sizey');
$(".universal_filters").hide();
$(".tatvamcontent").css('margin-top', 0);

var Status = 'NEW';
var Source = 'All';
var SearchText = '';
var GET_SOURCE_MASTER_URL = "../RealTimeData/GetListOfSources";


displayReviewList();
updateStatusPanel();

function getReviewResponse(reviewId) {
    $.get("../Review/ReviewResponse?reviewId=" + reviewId, function (data) {
        $("#reviewContainer").empty();
        $("#reviewContainer").append(data);
        updateStatusPanel();
    });

}

function displayReviewList() {
    $.get("../Review/InAppReviewTemplate", function (data) {
        $("#reviewContainer").empty();
        $("#reviewContainer").append(data);
        $('#txtSearch').val(SearchText);
    });
}

function replyReview() {
    $("#responseEditorBlock").show();
}

function sendResponce() {
    //var responce = $("#txt_responceEditor").Editor("getText");
    //var encodedStr = responce.replace(/[\u00A0-\u9999<>\&]/gim,
    //           function (i) {
    //               return '&#' + i.charCodeAt(0) + ';';
    //           });



    var responce = $("#txt_responceEditor").val();
    var reviewId = $("#oneReview")[0].dataset.id;

    $.ajax({
        type: 'POST',
        url: '../Review/postResponse',
        data: {
            inpResponce: responce,
            reviewId: reviewId
        },
        success: function (data) {
            getReviewResponse(reviewId);
        },
        error: function (xhr, status, p3, p4) {
            if (xhr.statusText === "OK") {
                getReviewResponse(reviewId);
            }
            var error = JSON.parse(xhr.responseText);
            TatvamAlert('Error While Posting the review. Please try after some time.');
        },
        complete: function () {
        }
    });
}

function updateStatusPanel() {
    $.getJSON("../Review/getStatusList", "", function (data) {
        var statusList = JSON.parse(data);        
        $.each(statusList, function (index, value) {
            var text = "(" + value.Count + ")";
            if (value.Status === "NEW") {
                $("#newCount").empty();
                $("#newCount").text(text);
            } else if (value.Status === "INPROGRESS") {
                $("#inProgressCount").empty();
                $("#inProgressCount").text(text);
                
            } else if (value.Status === "ONHOLD") {
                $("#onHoldCount").empty();
                $("#onHoldCount").text(text);
                
            } else if (value.Status === "DRAFT") {
                $("#draftCount").empty();
                $("#draftCount").text(text);
                
            } else if (value.Status === "RESPONDED") {
                $("#respondedCount").empty();
                $("#respondedCount").text(text);
                
            } else if (value.Status === "FAILED") {
                $("#failedCount").empty();
                $("#failedCount").text(text);
                
            } else if (value.Status === "CLOSED") {
                $("#closedCount").empty();
                $("#closedCount").text(text);
                
            }
        });
    enableStatus();
});
}

function getReviewListByStatus(tempstatus) {
    Status = tempstatus;
    displayReviewList();
    enableStatus();
}

function enableStatus() {    
    $("#sideStatusPanel li").removeClass('active');
    $('#sideStatusPanel li[data-status = ' + Status + ']').addClass('active');
}

function convertOriginalText() {
    $("#originaltext").show();
    $("#englishtext").hide();
    $("#originaltextIcon").show();
    $("#englishtextIcon").hide();
}

function convertEnglishText() {
    $("#originaltext").hide();
    $("#englishtext").show();
    $("#englishtextIcon").show();
    $("#originaltextIcon").hide();
}



function searchReviewByText() {
    SearchText = $("#txtSearch").val();
    displayReviewList();
}


function addNewFolder() {
    var folderName = $("#txt_folderName").val();
    if (folderName.trim() !== "") {
        // Check Folder exist 
        // If folder exist 
        //     alert (Folder already exist)
        // else
        //     Call the API to create the new Folder
        //     Upon Success create the new Folder   

        var tempDOM = "<li href='#' class='list-group-item' data-status='" + folderName + "' ondrop='onStatusdrop(event)' ondragover='allowDrop(event)' ><i class='fa fa-folder-o' aria-hidden='true'></i>&nbsp;&nbsp;&nbsp;&nbsp;" + folderName;
        //if (value.Count > 0) {
        //    tempDOM += "  (" + value.Count + ")";
        //}
        tempDOM += "</li>";
        $("#folderList").append(tempDOM);
        $("#txt_folderName").val("");
        $('#createNewFolder').modal('toggle');
    } else {
        TatvamAlert("Folder name cannot be blank.", "Error");
    }
}


function GetSourceData() {
    TatvamAjaxCalls("GET", GET_SOURCE_MASTER_URL, null, BindSourceDropDown, {});
}

function BindSourceDropDown(data) {
    var sourceData = JSON.parse(data.response);
    var sourceControl = $('#ddl_source');
    sourceControl.empty();
    $('#ddl_source').append('<option value="All">All</option>');
    if (sourceData !== null) {
		if(sourceData.source !== undefined){
			sourceData.source.forEach(function (element) {
				$('#ddl_source').append('<option value="' + element.name + '">' + element.name + '</option>');
			});
		}
    }

    sourceControl.chosen({ no_results_text: "Oops, nothing found!" });
    $('#ddl_source').find('option[Value="' + Source + '"]').prop('selected', true).trigger('chosen:updated');
}

function onSourceChange() {
    Source = $("#ddl_source option:selected").text();
    displayReviewList();
    updateStatusPanel();
    $('#ddl_source').find('option[Value="' + Source+'"]').prop('selected', true).trigger('chosen:updated');
}
